<template>
  <router-view/>
</template>

<style lang="scss">
@import "./style.css"
</style>
