<template>
  <div class="header">
    <div class="user">
      <div v-show="mark===1">
        <el-popover
        placement="top-start"
        :width="200"
        trigger="hover"
        popper-style="inset:48px 400px auto auto;"
        >
          <div>
            <el-avatar :size="100" src="http://localhost:9000/images/logo.png" crossorigin="anonymous" @error="errorHandler" style="margin:auto">
              <img crossorigin="anonymous" :src="user.avatar"/>
            </el-avatar>
            <el-button class="button" style="height:50px;width:100%" @click="loginOut">退出</el-button>
          </div>
          <template #reference>
            {{ user.username }}
          </template>
        </el-popover>
      </div>
      <div v-show="mark === 0" @click="loginIn">请您先登录</div>
      <div @click="shopCart">购物车</div>
      <div @click="order">您的订单</div>
    </div>
    <div class="layout" @click="router.push('/')">
      <img src="@/assets/images/logo.png" alt="">
      <div class="fz">
        <p>好农物</p>
      </div>
      <div class="search">
        <el-input v-model="searchKey" style="width: 450px;height:50px;font-size:1.2rem" placeholder="搜索您想要的商品" />
        <el-button style="width: 100px;height:50px;font-size:1.2rem" @click="searchOne">搜索</el-button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import router from '@/router';
import { onMounted, reactive, ref } from 'vue';
import { ElMessage, ElMessageBox } from 'element-plus'
import type { Action } from 'element-plus'
import productSearch from '@/store/product/productSearch'
import mainPageControl from '@/store/mainPage/mainPageControl'

const productSearchStore = productSearch()
const mainPageStore = mainPageControl()

const user = reactive<Record<string, any>>({});
const mark = ref(0)
const searchKey = ref('')

const errorHandler = () => true
const loginIn = ()=>{
  router.push({name:'login'})
}
const loginOut = ()=>{
  localStorage.removeItem('tokn')
  localStorage.removeItem('user')
  mark.value=0
  router.push({name:'login'})
}

const shopCart = ()=>{
  router.push('/personal/shopCart')
}

const order = ()=>{
  router.push('/personal/order')
}

const searchOne = async () =>{
  try{
    productSearchStore.load = true
    productSearchStore.searchInfo1.name = searchKey.value
    await productSearchStore.productSearch().then((res)=>{
      if(res.statusCode === 200){
        productSearchStore.searchMark = 1
        productSearchStore.searchInfo1Group = res.data
        productSearchStore.pagination = res.pagination
        setTimeout(() => {
          productSearchStore.load = false
          router.push('/search')
        }, 1000);
      }else{
        searchKey.value = ''
        ElMessageBox.alert('搜索失败，请重试', 'Title', {
          confirmButtonText: 'OK',
          callback: (action: Action) => {
            ElMessage({
              type: 'info',
              message: `action: ${action}`,
            })
          },
        })
      }
    })
  }catch(err){
    searchKey.value = ''
    ElMessageBox.alert('搜索失败，请重试', 'Title', {
      confirmButtonText: 'OK',
      callback: (action: Action) => {
        ElMessage({
          type: 'info',
          message: `action: ${action}`,
        })
      },
    })
  }
}

onMounted(()=>{
  const userString = localStorage.getItem('user');
  if (userString) {
    const userObject = JSON.parse(userString);
    // 将userObject的所有属性复制到user响应式对象中
    for (const key in userObject) {
      user[key] = userObject[key];
    }
    mark.value = 1
  }
})
</script>

<style scoped lang="scss">
.header{
  height: 100%;

  .user{
    display: flex;
    justify-content: flex-end;
    height: 20%;
    background-color: grey;
    padding-right: 150px;

    div{
      height: 100%;
      width: 100px;
      padding: 0 10px;
      border-left: 2px solid rgba(165, 165, 165, 0.5);
      border-right: 2px solid rgba(165, 165, 165, 0.5);
      font-size: 1.5rem;
      display: flex;
      justify-content: center;

      &:hover{
        background-color: rgba(255, 255, 255, 0.8);
        border-left: 2px solid rgba(255, 255, 255, 0.5);
        border-right: 2px solid rgba(165, 165, 165, 0.5);
        color: red;
      }
    }
    
  }

  .layout{
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    align-content: center;
    background-color: #fff;
    height: 80%;
    border-bottom: 2px solid rgba(128, 128, 128, 0.5);

    img{
      height: 100%;
    }

    .fz{
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      align-content: center;
      margin-left: 10px;
      margin-right: 300px;

      p{
        font-size: 3rem;
        font-family: 'KaiTi', '楷体', 'STKaiti', '华文楷体', serif;
      }
    }

    .search{
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      align-content: center;

      padding-left: 300px;
    }
  }
}
</style>