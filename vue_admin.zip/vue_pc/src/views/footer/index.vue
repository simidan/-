<template>
  <div class="footer">
    <p>仅用于毕业设计</p>
  </div>
</template>

<script setup lang="ts"></script>

<style scoped lang="scss">
.footer{
  height: 100%;
  background-color: rgb(60, 60, 60);
  
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-content: center;

  p{
    font-size: 5rem;
    color: white;
  }
}
</style>