<template>
  <div class="main">
    <div class="block text-center banner">
      <el-carousel height="300px">
        <el-carousel-item v-for="item in imgOption" :key="item">
          <div class="banner_img">
            <img crossorigin="anonymous" :src="item" alt="">
          </div>
        </el-carousel-item>
      </el-carousel>
    </div>
    <div class="categories">
      <div class="title">
        <el-icon><DArrowLeft /></el-icon>
        <el-icon><DArrowLeft /></el-icon>
        <el-icon><DArrowLeft /></el-icon>
        <p>分类</p>
        <el-icon><DArrowRight /></el-icon>
        <el-icon><DArrowRight /></el-icon>
        <el-icon><DArrowRight /></el-icon>
      </div>
      <div class="categories_main">
        <div class="main_item" v-for="(item, index) in categories" :key="index" @click="searchOther(index+1)">
          <div class="item_img">
            <img crossorigin="anonymous" :src="item.imageUrl" alt="">
          </div>
          <div class="item_name">
            {{ item.name }}
          </div>
        </div>
      </div>
    </div>
    <div class="product">
      <div class="title">
        <p>应季好物</p>
      </div>
      <div class="bySeason">
        <div class="season">
          <p>{{season}}</p>
        </div>
        <div class="item" v-for="(item, index) in productSeason" :key="index" @click="proDetail(item.product_id)">
          <productItemVue :item="item"></productItemVue>
        </div>
      </div>
    </div>
    <div class="product-show">
      <!-- <ul v-infinite-scroll="load"> -->
      <ul>
        <li v-for="item in productShows" :key="item.product_id" @click="proDetail(item.product_id)">
          <productPageVue :item="item"></productPageVue>
        </li>
      </ul>
    </div>
  </div>
</template>

<script setup lang="ts">
import { onBeforeUnmount, onMounted, reactive, ref } from "vue";
import productBySeason from '@/store/product/productSeason'
import productShow from '@/store/product/productShow'
import productSearch from '@/store/product/productSearch'
import productItemVue from '@/components/productItem.vue'
import productPageVue from '@/components/productPage.vue'
import {createHandleScroll} from '@/utils/handleScroll'
import { Search } from "@element-plus/icons-vue/dist/types";
import router from "@/router";
import { ElMessage, ElMessageBox } from 'element-plus'
import type { Action } from 'element-plus'

import proDetail from '@/utils/productDetailShow'

const productBySeasonStore = productBySeason()
const productShowStore = productShow()
const productSearchStore = productSearch()

// 使用ref来跟踪数组数据
let productSeason = ref([])
let pageLimit = reactive({
  'page':1,
  'limit':10
})
let productShows = ref([])
const totalPages = ref(0)
const season = ref('')

const imgOption = ref([
  'http://localhost:9000/images/bgI-1.jpeg',
  'http://localhost:9000/images/bgI-2.jpeg',
  'http://localhost:9000/images/bgI-3.jpeg',
])

const categories = ref([
  { name: '新鲜农产品', imageUrl: 'http://localhost:9000/images/categories1.jpeg' },
  { name: '粮油副食', imageUrl: 'http://localhost:9000/images/categories2.jpeg' },
  { name: '冷冻冷藏食品', imageUrl: 'http://localhost:9000/images/categories3.jpeg' },
  { name: '休闲食品', imageUrl: 'http://localhost:9000/images/categories4.jpeg' }
]);


const load = async (): Promise<void> => {
  // 检查是否已加载所有页面
  if (pageLimit.page >= totalPages.value) {
    return; // 如果所有页面已加载，直接返回，不执行更多的加载操作
  }
  pageLimit.page++;
  
  const info = {...pageLimit}
  const showRes = await productShowStore.productShow(info);
  if (Array.isArray(productShows.value) && Array.isArray(showRes.data)) {
    productShows.value = [...productShows.value, ...showRes.data];
  } else {
    console.error('productShows.value is not an array');
    productShows.value = showRes.data;
  }
}

const debouncedHandleScroll = createHandleScroll(load);

const searchOther = async (category_id:number) =>{
  try{
    productSearchStore.load = true
    productSearchStore.searchInfo0.category_id=category_id
    await productSearchStore.productSearchOther().then((res)=>{
      if(res.statusCode === 200){
        productSearchStore.searchMark = 0
        productSearchStore.searchInfo0Group = res.data
        productSearchStore.pagination = res.pagination
        setTimeout(() => {
          productSearchStore.load = false
          router.push('/search')
        }, 1000);
      }else{
        ElMessageBox.alert('搜索失败，请重试', 'Title', {
          confirmButtonText: 'OK',
          callback: (action: Action) => {
            ElMessage({
              type: 'info',
              message: `action: ${action}`,
            })
          },
        })
      }
    })
  }catch(err){
    ElMessageBox.alert('搜索失败，请重试', 'Title', {
      confirmButtonText: 'OK',
      callback: (action: Action) => {
        ElMessage({
          type: 'info',
          message: `action: ${action}`,
        })
      },
    })
  }
}

onMounted(async () => {
  setTimeout(async () => {
      const now = new Date();
      const month = now.getMonth() + 1;
      if (month >= 1 && month <= 3) {
        season.value = '春季';
      } else if (month >= 4 && month <= 6) {
        season.value = '夏季';
      } else if (month >= 7 && month <= 9) {
        season.value = '秋季';
      } else {
        season.value = '冬季';
      }
    try {
      await productBySeasonStore.productSeason(month).then((res) => {
        const products = res.data;
        productSeason.value = products.slice(0, 4);
        setTimeout(async () => {
          await productShowStore.productShow(pageLimit).then((res) => {
            productShows.value = res.data;
            totalPages.value = res.pagination.totalPages;
          }).catch(async (error) => {
            console.error("First attempt to fetch product shows failed, retrying...", error);
            // Retry the request after a short delay
            setTimeout(async () => {
              await productShowStore.productShow(pageLimit).then((res) => {
                productShows.value = res.data;
                totalPages.value = res.pagination.totalPages;
              }).catch(error => {
                console.error("Second attempt to fetch product shows also failed", error);
                // Handle further errors or set default values
                productShows.value = []; // Ensure productShows has a default value
                totalPages.value = 0;
              });
            }, 1000); // Retry after 1 second
          });
        }, 1000);
      })
    } catch (error) {
      console.error("Failed to fetch product seasons", error);
      productSeason.value = []; // Ensure productSeason has a default value
    }
  }, 1000);
  window.addEventListener('scroll', debouncedHandleScroll);
});


onBeforeUnmount(() => {
  window.removeEventListener('scroll', debouncedHandleScroll);
});
</script>


<style scoped lang="scss">
.main{
  height: 100%;

  .banner{
    background-color: rgba(160, 160, 160, 0.5);
    margin-top: 10px;

    .banner_img{
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      align-content: center;
    }
  }

  .categories{
    display: flex;
    flex-wrap: wrap;
    flex-direction: column;
    justify-content: center;
    align-content: center;
    height: 200px;
    margin-top: 50px;
    
    .title{
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      align-content: center;
      height: 20%;

      .el-icon{
        height: 2.5em;
        width: 1em;
      }

      p{
        font-size: 2rem;
        font-weight: 600;
        opacity: .8;
        letter-spacing: 2px;
      }
    }

    .categories_main{
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      align-content: center;
      height: 70%;
      width: 95%;
      background-color: #fff;

      .main_item{
        display: flex;
        flex-wrap: wrap;
        flex-direction: column;
        justify-content: center;
        align-content: center;
        width: 20%;
        height: 100%;

        .item_img{
          display: flex;
          flex-wrap: wrap;
          justify-content: center;
          align-content: center;

          img{
            width: 80px;
            height: 80px;
          }
        }

        .item_name{
          display: flex;
          flex-wrap: wrap;
          justify-content: center;
          align-content: center;

          font-size: 1.5rem;
        }

        &:hover{
          background-color: #afafaf;
          transition: all .5s;
        }
      }
    }
  }

  .product{
    display: flex;
    flex-wrap: wrap;
    flex-direction: column;
    justify-content: center;
    align-content: center;
    margin-top: 50px;

    .title{
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      align-content: center;
      height: 20%;

      .el-icon{
        height: 2.5em;
        width: 1em;
      }

      p{
        font-size: 2rem;
        font-weight: 600;
        opacity: .8;
        letter-spacing: 2px;
      }
    }

    .bySeason{
      display: flex;
      flex-wrap: wrap;
      align-content: center;
      justify-content: space-between;
      height: 70%;
      width: 95%;
      background-color: #fff;
      padding: 10px 0;

      .season{
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        align-content: center;
        width: 100px;
        border-right: 3px solid rgba(128, 128, 128, 0.5);

        p{
          font-size: 2rem;
          line-height: 2rem;
          writing-mode: vertical-lr;
        }
      }

      .item{
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        align-content: center;
        width: 20%;
        border-right: 1px solid rgba(128, 128, 128, 0.5);

        &:hover{
          filter: brightness(120%);
          transition: filter .5s;
        }
      }
    }
  }

  .product-show{
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    align-content: center;
    margin-top: 50px;
    
    ul{
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      align-content: space-around;
    
      width: 95%;
    
      li{
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        align-content: space-around;

        width: calc(20% - 10px); 
        height: 320px;
        margin: 5px;
        margin-bottom: 50px; // 每一行相距上一行50px
        background-color: white;

        padding: auto;

        &:hover{
          filter: brightness(120%);
          transition: filter .5s;
        }
      }
    }
  }
}
</style>