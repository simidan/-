<template>
  <div class="main" v-loading="load">
    <div class="page">
      <div class="image">
        <img crossorigin="anonymous" :src="productInfo?.image" alt="">
      </div>
      <div class="message">
        <el-descriptions :column="1" border>
          <el-descriptions-item
            v-for="(item, index) in productInfoArray"
            :key="index"
            :label="item.label"
            label-align="center"
            align="center"
            label-class-name="my-label"
            class-name="my-content"
          >
            {{ item.value }}
          </el-descriptions-item>
        </el-descriptions>
        <el-input-number v-model="quantity" :min="1" size="large" class="numberCount" style="width:250px;height:80px;"/>
      </div>
    </div>
    <div class="button">
      <el-button style="width:15%;height:100px;font-size: 1.5rem;" type="primary" plain @click="addCart">
        <el-icon style="margin-right: 20px;
        font-size: 2rem;"><ShoppingCartFull /></el-icon>加入购物车</el-button>
      <el-button style="width:15%;height:100px;font-size: 1.5rem;" type="success" plain @click="pay">
        <el-icon style="margin-right: 20px;
        font-size: 2rem;"><Coin /></el-icon>支付</el-button>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { computed, onMounted, ref } from "vue";
import { useRoute } from 'vue-router';

import productDetailControl from '@/store/product/productDetail'
import updateCartControl from '@/store/shopCart/updateCart'

import { productMessage } from "@/utils/interface";
import { transformProductInfo } from '@/utils/transformProductInfo';
import router from "@/router";
import { messageBox } from '@/utils/messageBox'

const route = useRoute();
const productDetailStore = productDetailControl()
const updateCartStore =  updateCartControl()

const product_id = Number(route.query.product_id)
const productInfo = ref<productMessage | undefined>(undefined);
const quantity = ref<number>(1)

const productInfoArray = computed(() => transformProductInfo(productInfo));

const load = ref(true)

const pay = ()=>{
  const quantitys:any = quantity.value
  router.replace({ path: '/pay',query: { product_id, quantitys  } })
}

const addCart = async()=>{
  const info = {
    productId:product_id,
    quantity:quantity.value
  }
  await updateCartStore.updateCart(info).then((res)=>{
    messageBox(res.message)
  }).catch(()=>{
    messageBox('购物车添加失败')
  })
}

onMounted(async()=>{
  setTimeout(async() => {
    await productDetailStore.productDetail(product_id).then((res)=>{
    productInfo.value = res.data
    load.value = false
  })
  }, 1000);
})
</script>

<style lang="scss" scoped>
.main{
  height: 100%;
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-content: center;
  
  .page{
    width: 80%;
    margin:10px 0;
    padding-bottom: 10px;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    align-content: center;
    border-bottom: 3px solid var(--el-border-color);

    .image{
      width: 40%;
      aspect-ratio: 1 / 1;
      border-radius: 10px;
      
      img{
        width: 100%;
        aspect-ratio: 1 / 1;
        border-radius: 10px;
      }
    }
  
    .message{
      width: 55%;
      font-size: 1.5rem;

      .numberCount{
        margin-top: 20px ;
        margin-left: 60%;

        :deep(.el-input--large){
          font-size: 1.5rem;
        }
      }

      :deep(.el-descriptions__body){
        border-radius: 16px;
      }

      :deep(el-descriptions__label){
        width: 30%;
        margin: auto;
      }

      :deep(.el-descriptions__cell){
        box-sizing: border-box;
        font-size: 1.5rem;
        width: 150px;
      }
    }
  }

  .button{
    display: flex;
    flex-wrap: wrap;
    justify-content: flex-end;

    width: 80%;
    margin:10px 0;
  }
}
</style>