<template>
  <div class="search">
    <selectVue></selectVue>
    <div class="show_none" v-if=" products.length === 0 ">
      十分抱歉，找不到符合您要求的商品
      {{ products }}
    </div>
    <div class="show" v-loading="productSearchStore.load" v-else>
      <ul>
        <li v-for="item in products" :key="item.product_id" @click="proDetail(item.product_id)">
          <productPageVue :item="item"></productPageVue>
        </li>
      </ul>
      <el-pagination layout="prev, pager, next" :total="totalpage*10" v-model:current-page="pageLimit.page" @current-change="currentChange"/>
    </div>
  </div>
</template>

<script setup lang="ts">
import { onMounted, reactive, ref, watch } from "vue";

import selectVue from '@/components/searchMain/select.vue'
import productPageVue from '@/components/productPage.vue'
import productSearch from '@/store/product/productSearch'

import { ElMessage, ElMessageBox } from 'element-plus'
import type { Action } from 'element-plus'

import proDetail from '@/utils/productDetailShow'

const productSearchStore = productSearch()

const products = ref<any[]>([]);

const pageLimit = ref({
  'page':1,
  'limit':10
})

const totalpage = ref(0)

const currentChange = async()=>{
  if(productSearchStore.searchMark === 1){
    productSearchStore.searchInfo1.page = pageLimit.value.page
    try{
      productSearchStore.load = true
      await productSearchStore.productSearch().then((res)=>{
        if(res.statusCode === 200){
          productSearchStore.searchMark = 1
          productSearchStore.searchInfo1Group = res.data
          productSearchStore.pagination = res.pagination
          productSearchStore.load = false
        }else{
          ElMessageBox.alert('搜索失败，请重试', 'Title', {
            confirmButtonText: 'OK',
            callback: (action: Action) => {
              ElMessage({
                type: 'info',
                message: `action: ${action}`,
              })
            },
          })
        }
      })
    }catch(err){
      ElMessageBox.alert('搜索失败，请重试', 'Title', {
        confirmButtonText: 'OK',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `action: ${action}`,
          })
        },
      })
    }
  }else if(productSearchStore.searchMark === 0){
    productSearchStore.searchInfo0.page = pageLimit.value.page
    try{
      productSearchStore.load = true
      await productSearchStore.productSearchOther().then((res)=>{
        if(res.statusCode === 200){
          productSearchStore.searchMark = 0
          productSearchStore.searchInfo0Group = res.data
          productSearchStore.pagination = res.pagination
          productSearchStore.load = false
        }else{
          ElMessageBox.alert('搜索失败，请重试', 'Title', {
            confirmButtonText: 'OK',
            callback: (action: Action) => {
              ElMessage({
                type: 'info',
                message: `action: ${action}`,
              })
            },
          })
        }
      })
    }catch(err){
      ElMessageBox.alert('搜索失败，请重试', 'Title', {
        confirmButtonText: 'OK',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `action: ${action}`,
          })
        },
      })
    }
  }
}

watch(() => productSearchStore.searchInfo1Group, (newVal) => {
  if(productSearchStore.searchMark === 1){
    products.value = [...newVal]; // 通过创建一个新数组确保响应性
    pageLimit.value.page = productSearchStore.pagination.page
    pageLimit.value.limit = productSearchStore.pagination.limit
    totalpage.value = productSearchStore.pagination.totalPages
  }
}, { deep: true });

watch(() => productSearchStore.searchInfo0Group, (newVal) => {
  if(productSearchStore.searchMark === 0){
    products.value = [...newVal]; // 通过创建一个新数组确保响应性
    pageLimit.value.page = productSearchStore.pagination.page
    pageLimit.value.limit = productSearchStore.pagination.limit
    totalpage.value = productSearchStore.pagination.totalPages
  }
}, { deep: true });

onMounted(()=>{
  if(productSearchStore.searchMark === 1){
    products.value = productSearchStore.searchInfo1Group
    pageLimit.value.page = productSearchStore.pagination.page
    pageLimit.value.limit = productSearchStore.pagination.limit
    totalpage.value = productSearchStore.pagination.totalPages
  }else if(productSearchStore.searchMark === 0){
    products.value = productSearchStore.searchInfo0Group
    pageLimit.value.page = productSearchStore.pagination.page
    pageLimit.value.limit = productSearchStore.pagination.limit
    totalpage.value = productSearchStore.pagination.totalPages
  }
})
</script>

<style scoped lang="scss">
.search{
  height: 100%;
  display: flex;
  flex-wrap: wrap;
  align-content: center;
  justify-content: center;

  .show{
    width: 90%;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    align-content: center;
    margin-top: 50px;
    
    ul{
      display: flex;
      flex-wrap: wrap;
      align-content: space-around;
    
      width: 100%;
    
      li{
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        align-content: space-around;

        width: calc(20% - 10px); 
        height: 320px;
        margin: 5px;
        margin-bottom: 50px; // 每一行相距上一行50px
        background-color: white;

        padding: auto;

        &:hover{
          filter: brightness(120%);
          transition: filter .5s;
        }
      }
    }
  }

  .show_none{
    width: 95%;
    height: 200px;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    align-content: center;
    margin-top: 50px;
    font-size: 2rem;
    color: grey;
  }
}
</style>