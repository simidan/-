<template>
  <div class="main">
    <div class="title">
      <p>支付页</p>
    </div>
    <div class="from" v-loading="load">
      <div class="userInfo">
        <p>收货人信息</p>
        <div class="from_main">
          <p>用户名：{{userInfo.username}}</p>
          <p>电话：{{ userInfo.phone }}</p>
          <P v-if="userInfo.default_address&&adressChange">收货地址：{{ userInfo.default_address }} </P>
          <div v-else>
            <elui-china-area-dht @change="onChange" style="width:300px"></elui-china-area-dht>
          </div>
          <el-button type="primary" plain @click="adressChange = false" v-if="adressChange">修改地址</el-button>
          <el-button type="primary" plain @click="adressChange = true" v-else style="margin:auto 20px">取消</el-button>
        </div>
      </div>
      <div class="payment_method">
        <p>支付方式</p>
        <el-radio-group v-model="newOrder.payment_method">
          <el-radio value="credit_card" border>信用卡</el-radio>
          <el-radio value="alipay" border>支付宝</el-radio>
          <el-radio value="wechat" border>微信支付</el-radio>
          <el-radio value="paypal" border>贝宝</el-radio>
        </el-radio-group>
      </div>
      <div class="productInfo">
        <p>货物清单</p>
        <div class="from_main" v-if="product_id">
          <img crossorigin="anonymous" :src="productInfo.image" alt="">
          <div class="productInfo_name">
            {{ productInfo.name }}
          </div>
          <div class="quantity">
            x{{ quantity }}
          </div>
          <div class="price">
            ￥{{ productInfo.price }}
          </div>
        </div>
        <div class="from_main" v-if="order_id">
          <img crossorigin="anonymous" :src="orderInfo.product_image" alt="">
          <div class="productInfo_name">
            {{ orderInfo.product_name }}
          </div>
          <div class="quantity">
            x{{ orderInfo.quantity }}
          </div>
          <div class="price">
            ￥{{ orderInfo.total_amount / orderInfo.quantity }}
          </div>
        </div>
      </div>
      <div class="sub">
        <div class="total_amount">
          应付总额：
        </div>
        <div class="total_amount" v-if="product_id">
          ￥{{ (productInfo.price * quantity).toFixed(2) }}
        </div>
        <div class="total_amount" v-if="order_id">
          ￥{{ (orderInfo.total_amount).toFixed(2) }}
        </div>
        <el-button plain style="width: 20%;height:80%;" @click="open">支付</el-button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from "vue";
import { useRoute } from 'vue-router';

import goBack from "@/utils/routerBack";

import { ElMessage, ElMessageBox } from 'element-plus'
import type { Action } from 'element-plus'
import { getData } from "@/api/lineCity";
import { EluiChinaAreaDht } from 'elui-china-area-dht'

import getOrderControl from '@/store/order/getOrder'
import mainPageControl from '@/store/mainPage/mainPageControl'
import orderDetailControl from '@/store/order/orderDetail'
import orderUpdateControl from '@/store/order/orderUpdate'
import productDetailControl from '@/store/product/productDetail'
import orderCreateControl from '@/store/order/orderCreate'

import { orderMessage, productMessage } from "@/utils/interface";
import { messageBox } from '@/utils/messageBox'

const getOrderStore = getOrderControl()
const mainPageStore = mainPageControl()
const orderDetailStore = orderDetailControl()
const orderUpdateStore = orderUpdateControl()
const productDetailStore = productDetailControl()
const orderCreateStore = orderCreateControl()

const route = useRoute();

const order_id = Number(route.query.order_id)
const product_id = Number(route.query.product_id)
const quantity = Number(route.query.quantitys)

interface orderInfo extends orderMessage {
  created_at:string,
  update_at:string,
  product_image:string,
  product_name:string,
}

const orderInfo = ref<orderInfo>({
  created_at: "",
  update_at: "",
  product_image: "",
  product_name: "",
  order_id: 0,
  user_id: 0,
  business_id: 0,
  product_id: 0,
  quantity: 0,
  total_amount: 0,
  status: "pending",
  payment_method: "credit_card",
  payment_status: "success",
  shipping_name: "",
  shipping_phone: "",
  shipping_address: ""
})
const userInfo = ref<any>({})
const productInfo = ref<productMessage>({
  business_id: 0,
  certification: '',
  description: '',
  grade: '',
  harvest_date: '',
  image: '',
  name: '',
  origin: '',
  price: 0,
  product_id: 0,
  safety_standards: '',
  season: '',
  shelf_life: 0,
  stock_quantity: 0,
  storage_conditions: '',
  sub_category_id: 0,
  unit: '',
});
const load = ref(true)

const newOrder = ref({
  productId:0,
  payment_method:'',
  shippingAddress:'',
  quantity:0
})

//获取order信息
const getOrder = async(order_id:number)=>{
  try{
    await orderDetailStore.orderDetail(order_id).then((res)=>{
      orderInfo.value = res.data
      newOrder.value.productId = orderInfo.value.product_id
      newOrder.value.payment_method = orderInfo.value.payment_method
      newOrder.value.shippingAddress = orderInfo.value.shipping_address
      newOrder.value.quantity = orderInfo.value.quantity
      load.value = false
    })
  }catch(err){
    ElMessageBox.alert('获取订单数据失败', 'Title', {
          confirmButtonText: 'OK',
          callback: (action: Action) => {
            ElMessage({
              type: 'info',
              message: `action: ${action}`,
            });
          },
        });
  }
}

//orderUpdate
const orderUpdate = async()=>{
  try{
    const info = {'orderId':order_id,'paymentStatus':'success'}
    await orderUpdateStore.orderUpdate(info).then((res)=>{
      if(res.statusCode){
        ElMessageBox.alert('支付成功', 'Title', {
          confirmButtonText: 'OK',
          callback: (action: Action) => {
            ElMessage({
              type: 'info',
              message: `action: ${action}`,
            });
          },
        });
        goBack()
      }
    })
  }catch(err){
    ElMessageBox.alert('支付失败', 'Title', {
          confirmButtonText: 'OK',
          callback: (action: Action) => {
            ElMessage({
              type: 'info',
              message: `action: ${action}`,
            });
          },
        });
  }
}

//获取商品信息
const productGet = async(product_id:number)=>{
  try{
    const res =  await productDetailStore.productDetail(product_id)
    if(res.statusCode === 200){
      productInfo.value = res.data
      load.value = false
    }
    else{
      messageBox(res.message)
      load.value = false
    }
  }
  catch{
    messageBox('信息获取失败，请刷新')
  }
}

//orderCreate
const orderCreate = async () => {
  try {
    if(userInfo.value.default_address){
      newOrder.value.shippingAddress = userInfo.value.default_address
    }
    const info = {
      userId: userInfo.value.user_id,
      productId: productInfo.value.product_id,
      payment_method: newOrder.value.payment_method,
      shippingAddress: newOrder.value.shippingAddress,
      quantity: quantity,
    };

    // 检查info对象中的每个字段是否有有效值
    for (const [key, value] of Object.entries(info)) {
      if (value === undefined || value === null || value === '') {
        messageBox(`订单创建失败：${key} 是必填项`);
        return; // 停止执行函数
      }
    }

    await orderCreateStore.orderCreate(info).then((res) => {
      if (res.statusCode) {
        messageBox(res.message);
        goBack();
      }
    });
  } catch (err) {
    messageBox('支付失败');
  }
};

//最后确认
const open = () => {
  ElMessageBox.confirm(
    '你确认支付吗？',
    '最后确认',
    {
      confirmButtonText: '支付',
      cancelButtonText: '取消',
    }
  )
    .then(() => {
      if(order_id){
        orderUpdate()
      }else if(product_id){
        orderCreate()
      }
      ElMessage({
        type: 'success',
        message: 'Delete completed',
      })
    })
    .catch(() => {
      ElMessage({
        type: 'info',
        message: 'Delete canceled',
      })
    })
}

//地址相关
let chinaData = new EluiChinaAreaDht.ChinaArea().chinaAreaflat
const adressChange = ref(true)
 
const onChange = (e:any) => {
    const province = chinaData[e[0]]
    const city = chinaData[e[1]]
    const area = chinaData[e[2]]
    const adress =`${province.label}-${city.label}-${area.label}`
    newOrder.value.shippingAddress = adress
}


onMounted(()=>{
  userInfo.value = JSON.parse(localStorage.getItem('user') || '{}');
  if(order_id){
    setTimeout(() => {
      getOrder(order_id)
    }, 1000);
  }
  if(product_id){
    setTimeout(() => {
      productGet(product_id)
    }, 1000);
  }
})
</script>


<style scoped lang="scss">
.main{
  height: 100%;
  display: flex;
  flex-wrap: wrap;
  flex-direction: column;
  justify-content: center;
  align-content: center;

  .title{
    width: 70%;
    height: 50px;
    font-size: 2rem;
    color: rgba(75, 75, 75, 0.8);
    border-bottom: 3px solid var(--el-border-color);
    margin: 0 auto;
    margin-top: 30px;
    margin-bottom: 20px;
  }

  .from{
    width: 70%;
    display: flex;
    flex-wrap: wrap;
    margin-bottom: 30px;

    padding: 10px 0;

    border: 1px solid var(--el-border-color);
    border-radius: 10px;
    box-shadow: var(--el-box-shadow-light);
    background-color: #fff;

    .userInfo{
      width: 95%;
      height: 150px;
      margin: 10px auto;
      padding: 10px;

      border-bottom: 1px solid var(--el-border-color);
      border-radius: 10px;

      p{
        font-size: 1.5rem;
        font-weight: 800;
      }

      .from_main{
        display: flex;
        flex-wrap: wrap;
        align-content: center;

        height: 80%;

        p{
          display: flex;
          flex-wrap: wrap;
          align-content: center;
          font-size: 1.5rem;
          font-weight: 400;
          margin: 0 30px;
          color: rgba(99, 99, 99, 0.8);
        }

        :deep(.el-input){
          height: 60px;
          font-size: 1rem;
        }
      }
    }

    .payment_method{
      width: 95%;
      height: 100px;
      margin: 10px auto;
      padding: 10px;

      border-bottom: 1px solid var(--el-border-color);
      border-radius: 10px;

      p{
        font-size: 1.5rem;
        font-weight: 800;
        margin-bottom: 30px;
      }
    }

    .productInfo{
      width: 95%;
      height: 300px;
      margin: 10px auto;
      padding: 10px;

      border-bottom: 1px solid var(--el-border-color);
      border-radius: 10px;

      p{
        font-size: 1.5rem;
        font-weight: 800;
      }

      .from_main{
        display: flex;
        flex-wrap: wrap;
        align-content: center;

        height: 80%;

        img{
          height: 80%;
          aspect-ratio: 1 / 1;
          border-radius: 10px;
        }

        .productInfo_name{
          display: flex;
          flex-wrap: wrap;
          justify-content: center;

          height: 80%;
          width: 10%;
          font-size: 2rem;
          color: rgba(99, 99, 99, 0.8);

          margin-left: 10%;
        }

        .quantity{
          display: flex;
          flex-wrap: wrap;
          justify-content: center;

          height: 80%;
          width: 10%;
          font-size: 2rem;
          color: rgba(99, 99, 99, 0.8);

          margin-left: 10%;
        }

        .price{
          display: flex;
          flex-wrap: wrap;
          justify-content: center;

          height: 80%;
          width: 10%;
          font-size: 2rem;
          color: rgb(255, 0, 0);

          margin-left: 10%;
        }
      }
    }

    .sub{
      display: flex;
      flex-wrap: wrap;
      justify-content: flex-end;
      align-content: center;

      width: 95%;
      height: 100px;
      margin: 10px auto;
      padding: 10px;

      border-bottom: 1px solid var(--el-border-color);
      border-radius: 10px;

      .total_amount{
        display: flex;
        flex-wrap: wrap;
        align-content: center;
        font-size: 1.5rem;
        margin-right: 5%;
      }

      .total_amount:nth-child(2){
        display: flex;
        flex-wrap: wrap;
        align-content: center;
        font-size: 1.5rem;
        margin-right: 10%;
        color: red;
      }
    }
  }
}

:deep(.el-radio__label){
  font-size: 1.2rem;
}
</style>