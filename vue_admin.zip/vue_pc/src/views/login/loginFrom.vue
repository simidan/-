<template>
  <div class="main_from">
    <p>密码登录</p>
    <el-input v-model.number="loginInfo.phone" style="width: 80%;height:50px;font-size:1.5rem" placeholder="请输入电话" class="username"/>
    <el-input v-model="loginInfo.password" style="width: 80%;height:50px;font-size:1.5rem" type="password" placeholder="请输入密码" show-password class="password"
    />
    <div class="main_from_button">
      <el-button type="primary" @click="login" style="width: 120px;height:50px;font-size:1.5rem">登录</el-button>
      <el-button @click="changeMark" style="width: 120px;height:50px;font-size:1.5rem">前往注册</el-button>
      <!-- <button @click="pageStore.fromChange()">注册</button> -->
    </div>
  </div>
</template>

<script lang="ts" setup>
import loginPageControl from '@/store/loginPage/pageControl'
import { reactive } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import type { Action } from 'element-plus'
import router from '@/router'
import {validateLoginInfo} from '@/utils/messageCheck'

const pageControl = loginPageControl()

const loginInfo = reactive({
  phone:'13610095104',
  password:'testUser8'
})

const changeMark = ()=>{
  pageControl.pageChangeMark = 1
}

const login = async () => {
  try {
    const validationResult = validateLoginInfo(loginInfo);
    if (!validationResult.isValid) {
      ElMessageBox.alert(validationResult.errorMessage, '提示', {
        confirmButtonText: '确定',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `操作: ${action}`,
          });
        },
      });
    } else {
      const res = await pageControl.login(loginInfo);
      
      if (res.statusCode === 200) {
        localStorage.setItem('token', res.data.token);
        localStorage.setItem('user', JSON.stringify(res.data.userMessage));
        ElMessageBox.alert('登陆成功', '提示', {
          confirmButtonText: '确定',
          callback: (action: Action) => {
            ElMessage({
              type: 'info',
              message: `操作: ${action}`,
            });
          },
        });
        router.push('/');
      } else {
        ElMessageBox.alert(res.message, '提示', {
          confirmButtonText: '确定',
          callback: (action: Action) => {
            ElMessage({
              type: 'info',
              message: `操作: ${action}`,
            });
          },
        });
      }
    }
  } catch (error) {
    console.error(error); // 记录或适当处理错误
  }
};

</script>

<style scoped lang="scss">
.main_from{
  display: flex;
  flex-direction: column;
  flex-wrap: wrap;
  align-content: center;

  width: 450px;
  height: 400px;
  background-color: white;

  margin-left: 300px;

  border-radius: 2%;
  border: 1px solid rgb(194, 194, 194);
  box-shadow: 0px 4px 8px rgba(64, 158, 255, 0.2);

  &:focus-within {
    border: 1px solid;
    border-color: rgb(64, 158, 255); /* 当子元素聚焦时，父元素边框变蓝 */
  }

  p{
    margin-top: 2rem;
    font-size: 2rem;
    text-align: center;
    padding-bottom: 10px;
    font-weight: 800;

    border-bottom: 2px solid rgb(194, 194, 194);
  }

  .username{
    margin-top: 2rem;
  }

  .password{
    margin-top: 2rem;
  }
  
  .main_from_button{
    display: flex;
    justify-content: space-around;
    margin-top: 2rem;
  }
}

</style>

function validateLoginInfo() {
  throw new Error('Function not implemented.')
}
