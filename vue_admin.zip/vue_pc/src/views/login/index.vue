<template>
  <div class="common-layout page">
    <el-container>
      <el-header style="height:140px">
        <div class="header">
          <img src="@/assets/images/logo.png" mode="" class="logo"/>
          <p>好农物</p>
        </div>
      </el-header>
      <el-main class="login_main">
        <div class="main_item">
          <transition name="fade" mode="out-in">
            <LoginVue v-if="pageControl.pageChangeMark === 0" key="login"></LoginVue>
            <RegisterVue v-else key="register"></RegisterVue>
          </transition>
        </div>
      </el-main>
    </el-container>
  </div>
</template>

<script setup>
import LoginVue from './loginFrom.vue'
import RegisterVue from './registerFrom.vue'
import loginPageControl from '@/store/loginPage/pageControl'

const pageControl = loginPageControl()
</script>

<style lang="scss" scoped>
.page{
  min-width: 1000px;
  min-height: 600px;
}

.header{
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
  height: 95%;
  border-bottom: 10px solid rgba(0, 200, 0, 0.5);

  .logo{
    display: block;
    height: 100%;
    object-fit: contain; /* 保持长宽比例 */
    margin-right: 2%;
    margin-bottom: 10px;
  }
  p{
    margin-right: 48%;
    margin-bottom: 10px;
    font-size: 4rem;
    font-family: 'KaiTi', '楷体', 'STKaiti', '华文楷体', serif;
    color: green;
    font-weight: 600;
  }
}

.login_main {
  position: relative;
  background-color: #dfdddd;
  background-image: url('@/assets/images/login-bg.png');
  
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  border-bottom: 10px solid rgba(0, 200, 0, 0.5);

  .main_item{
    display: flex;
    justify-content: center;
    align-items: center;
    width: 80%;
    
    height: 33.25rem;
    margin-left: 18rem;

    .fade-enter-active, .fade-leave-active {
      transition: opacity 0.5s;
    }
    .fade-enter, .fade-leave-to /* .fade-leave-active in <2.1.8 */ {
      opacity: 0;
    }
  }
}
</style>