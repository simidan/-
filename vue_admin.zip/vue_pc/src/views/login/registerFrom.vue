<template>
  <div class="main_from">
    <p>用户注册</p>
    <div class="total">
      <div class="left">
        <el-input v-model="registerInfo.username" style="width: 80%;height:50px;font-size:1.2rem" placeholder="请输入姓名" class="username"/>
        <el-input v-model="passwordA" style="width: 80%;height:50px;font-size:1.2rem" type="password" placeholder="请输入密码" show-password class="password" maxlength="15"/>
        <el-input v-model="registerInfo.password" style="width: 80%;height:50px;font-size:1.2rem" placeholder="再次输入密码" show-password class="password" maxlength="15"/>
        <el-input v-model="registerInfo.phone" style="width: 80%;height:50px;font-size:1.2rem" placeholder="请输入手机号" class="password"/>
      </div>
      <div class="right">
        <el-input v-model="registerInfo.email" style="width: 80%;height:50px;font-size:1.2rem" placeholder="请输入邮箱" class="password"/>
        <el-radio-group v-model="registerInfo.gender" class="gender" style="font-size:1.2rem" size="large">
          <el-radio value="0" style="font-size:1.2rem" size="large">男</el-radio>
          <el-radio value="1" size="large">女</el-radio>
        </el-radio-group>
        <div class="demo-datetime-picker">
          <div class="block">
            <span class="demonstration">生日</span>
            <el-date-picker
              v-model="registerInfo.birthday"
              type="datetime"
              placeholder="Select date and time"
              style="width: 80%;height:50px;margin-right: 80px;font-size:1.2rem"
              :default-time="defaultTime"
            />
          </div>
        </div>
      </div>
    </div>
    <div class="main_from_button">
      <el-button size="large" @click="changeMark"  style="width: 120px;height:50px;font-size:1.2rem">返回登录</el-button>
      <el-button type="primary" size="large" @click="register"  style="width: 120px;height:50px;font-size:1.2rem">确认</el-button>
      <!-- <button @click="pageStore.fromChange()">注册</button> -->
    </div>
  </div>
</template>

<script lang="ts" setup>
import loginPageControl from '@/store/loginPage/pageControl'
import { reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import type { Action } from 'element-plus'
import router from '@/router'
import {validateRegisterInfo} from '@/utils/messageCheck'
import dateChange from '@/utils/dateChange'

const pageControl = loginPageControl()

const passwordA = ref('')

const registerInfo = reactive({
  username:'',
  password:'',
  phone:'',
  email:'',
  gender:'',
  birthday:'',
})

const register = async () => {
  try {
    if(registerInfo.password!==passwordA.value){
      return ElMessageBox.alert('两次密码不同', '提示', {
        confirmButtonText: '确定',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `操作: ${action}`,
          });
        },
      });
    }
    registerInfo.birthday = dateChange(registerInfo.birthday)
    const validationResult = validateRegisterInfo(registerInfo);
    if (!validationResult.isValid) {
      ElMessageBox.alert(validationResult.errorMessage, '提示', {
        confirmButtonText: '确定',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `操作: ${action}`,
          });
        },
      });
    } else {
      const res = await pageControl.register(registerInfo);
      if (res.statusCode === 200) {
        ElMessageBox.alert('注册成功', '提示', {
          confirmButtonText: '确定',
          callback: (action: Action) => {
            ElMessage({
              type: 'info',
              message: `操作: ${action}`,
            });
          },
        });
        pageControl.pageChangeMark = 0
      } else {
        ElMessageBox.alert(res.message, '提示', {
          confirmButtonText: '确定',
          callback: (action: Action) => {
            ElMessage({
              type: 'info',
              message: `操作: ${action}`,
            });
          },
        });
      }
    }
  } catch (error) {
    console.error(error); // 记录或适当处理错误
  }
};

const changeMark = ()=>{
  pageControl.pageChangeMark = 0
}
</script>

<style scoped lang="scss">
.main_from{
  display: flex;
  flex-direction: column;
  flex-wrap: wrap;
  align-content: center;

  width: 800px;
  height: 500px;
  background-color: white;

  margin-left: 300px;

  border-radius: 2%;
  border: 1px solid rgb(194, 194, 194);
  box-shadow: 0px 4px 8px rgba(64, 158, 255, 0.2);

  &:focus-within {
    border: 1px solid;
    border-color: rgb(64, 158, 255); /* 当子元素聚焦时，父元素边框变蓝 */
  }

  p{
    margin-top: 2rem;
    font-size: 2rem;
    text-align: center;
    padding-bottom: 10px;
    font-weight: 800;

    border-bottom: 2px solid rgb(194, 194, 194);
  }

  .total{
    display: flex;
    width: 100%;
    height: 60%;
    
    .left{
      display: flex;
      flex-direction: column;
      flex-wrap: wrap;
      align-content: center;
      width: 50%;

      .username{
        margin-top: 1.5rem;
      }
    
      .password{
        margin-top: 1.5rem;
      }
    
      .password_woring:focus{
        margin-top: 1.5rem;
        border: 1px solid;
        border-color: rgb(255, 0, 0);
        border-radius: 2%;
      }
    }

    .right{
      display: flex;
      flex-direction: column;
      flex-wrap: wrap;
      align-content: center;

      width: 50%;

      .gender{
        margin-top: .8rem;

        .el-radio__label{
          font-size: 1.5rem;
        }
      }

      .password{
        margin-top: 1.5rem;
      }
    
      .password_woring:focus{
        margin-top: 1.5rem;
        border: 1px solid;
        border-color: rgb(255, 0, 0);
        border-radius: 2%;
      }

      .demo-datetime-picker {
        display: flex;
        width: 100%;
        padding: 0;
        flex-wrap: wrap;

        .block {
          padding: 30px 0;
          border-right: solid 1px var(--el-border-color);
          flex: 1;

          .demonstration {
            display: block;
            color: var(--el-text-color-secondary);
            font-size: 14px;
            margin-bottom: 30px;
          }
        }
      }
      
    }
  }
  
  .main_from_button{
    display: flex;
    justify-content: space-around;
    margin-top: 2rem;
  }
}
</style>
