<template>
  <div class="common-layout page">
    <el-affix :offset="580" class="owner" style="height:0">
      <el-button class="button" @click="personal">
        <el-icon><House /></el-icon>
        个人空间
      </el-button>
    </el-affix>
    <el-container>
      <el-header class="header">
        <headerVue></headerVue>
      </el-header>
      <el-affix :offset="0">
        <div class=""></div>
      </el-affix>
      <el-main class="main" >
        <mainVue></mainVue>
      </el-main>
      <el-footer class="footer">
        <footerVue></footerVue>
      </el-footer>
    </el-container>
    <el-backtop :right="25" :bottom="50" />
  </div>
</template>


<script lang="ts" setup>
import headerVue from '@/views/header/index.vue';
import footerVue from '@/views/footer/index.vue';
import mainVue from '@/views/main/payMain.vue'
import { onBeforeMount, onBeforeUnmount, onMounted, ref } from 'vue'
import router from '@/router'

import mainPageControl from '@/store/mainPage/mainPageControl'

const mainPageStore = mainPageControl()

const isAffixVisible = ref(false)

function handleScroll() {
  const scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;
  isAffixVisible.value = scrollTop > 180;
}

const personal = ()=>{
  router.push('/personal')
}

const goback = ()=>{
  mainPageStore.payPage = false
  const previousPath = sessionStorage.getItem('previousPath');
  if (previousPath) {
    router.push(previousPath);
  } else {
    // 默认回退到首页
    router.push('/');
  }
}

onMounted(()=>{
window.addEventListener('scroll', handleScroll);
})
onBeforeUnmount(()=>{
window.removeEventListener('scroll', handleScroll);
})
</script>

<style scoped lang="scss">
.page{
  min-width: 1000px;
  min-height: 600px;

  .owner{
    display: flex;
    flex-direction: row;
    margin-left: 1800px;
    font-size: 1.5rem;

    .button{
      height: 200px;
      width: 80px;
      writing-mode: vertical-rl;
      font-size: 1.5rem;

      i{
        margin-bottom: 10px;
        color: var(--el-color-primary);
        --el-button-hover-bg-color: ;
      }
    }
  }

  .layout{
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    align-content: center;
    background-color: #fff;
    height: 180px;
    border-bottom: 2px solid rgba(128, 128, 128, 0.5);

    img{
      height: 100%;
    }

    .fz{
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      align-content: center;
      margin-left: 10px;
      margin-right: 300px;

      p{
        font-size: 3rem;
        font-family: 'KaiTi', '楷体', 'STKaiti', '华文楷体', serif;
      }
    }
  }

  .header{
    height: 180px;
    padding: 0;
  }

  .main{
    padding: 0px 40px;
  }

  .footer{
    height: 300px;
    padding: 0;
  }

  .el-backtop{
    width: 60px;
    height: 60px;
  }
}
</style>