<template>
    <div class="common-layout page">
      <el-affix :offset="580" class="owner" style="height:0">
        <el-button class="button" @click="personal">
          <el-icon><House /></el-icon>
          个人空间
        </el-button>
      </el-affix>
      <el-container>
        <el-header class="header" v-show="isAffixVisible">
          <div>
            <el-affix :offset="0">
              <div class="layout">
                <img src="@/assets/images/logo.png" alt="">
                <div class="fz">
                  <p>好农物</p>
                </div>
                <div class="search">
                  <el-input v-model="searchKey" style="width: 450px;height:50px;font-size:1.2rem" placeholder="搜索您想要的商品" />
                  <el-button style="width: 100px;height:50px;font-size:1.2rem" @click="searchOne">搜索</el-button>
                </div>
              </div>
            </el-affix>  
          </div>
        </el-header>
        <el-header class="header">
          <headerVue></headerVue>
        </el-header>
        <el-affix :offset="0">
          <div class=""></div>
        </el-affix>
        <el-main class="main" >
          <!-- <mainVue></mainVue> -->
          <router-view/>
        </el-main>
        <el-footer class="footer">
          <footerVue></footerVue>
        </el-footer>
      </el-container>
      <el-backtop :right="25" :bottom="50" />
    </div>
</template>

<script setup lang="ts">
import headerVue from './header/index.vue'
import mainVue from './main/index.vue'
import footerVue from './footer/index.vue'
import { onBeforeMount, onBeforeUnmount, onBeforeUpdate, onMounted, ref } from 'vue'

import { ElMessage, ElMessageBox } from 'element-plus'
import type { Action } from 'element-plus'
import productSearch from '@/store/product/productSearch'
import router from '@/router'
import { useRoute } from 'vue-router'

const productSearchStore = productSearch()

const searchKey = ref('')
const isAffixVisible = ref(false)

function handleScroll() {
    // 获取滚动距离
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;
    // 根据滚动距离更新isAffixVisible的值
    isAffixVisible.value = scrollTop > 180;
}

const searchOne = async () =>{
  try{
    productSearchStore.load = true
    productSearchStore.searchInfo1.name = searchKey.value
    await productSearchStore.productSearch().then((res)=>{
      if(res.statusCode === 200){
        productSearchStore.searchMark = 1
        productSearchStore.searchInfo1Group = res.data
        productSearchStore.pagination = res.pagination
        setTimeout(() => {
          productSearchStore.load = false
          router.push('/search')
        }, 1000);
      }else{
        searchKey.value = ''
        ElMessageBox.alert('搜索失败，请重试', 'Title', {
          confirmButtonText: 'OK',
          callback: (action: Action) => {
            ElMessage({
              type: 'info',
              message: `action: ${action}`,
            })
          },
        })
      }
    })
  }catch(err){
    searchKey.value = ''
    ElMessageBox.alert('搜索失败，请重试', 'Title', {
      confirmButtonText: 'OK',
      callback: (action: Action) => {
        ElMessage({
          type: 'info',
          message: `action: ${action}`,
        })
      },
    })
  }
}

const personal = ()=>{
  router.push('/personal')
}

onMounted(()=>{
  window.addEventListener('scroll', handleScroll);
})
onBeforeUnmount(()=>{
  window.removeEventListener('scroll', handleScroll);
})
</script>

<style scoped lang="scss">
.page{
  min-width: 1400px;
  min-height: 800px;

  .owner{
    display: flex;
    flex-direction: row;
    margin-left: 1800px;
    font-size: 1.5rem;

    .button{
      height: 200px;
      width: 80px;
      writing-mode: vertical-rl;
      font-size: 1.5rem;

      i{
        margin-bottom: 10px;
        color: var(--el-color-primary);
        --el-button-hover-bg-color: ;
      }
    }
  }

  .header{
    height: 180px;
    padding: 0;

    .layout{
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      align-content: center;
      background-color: #fff;
      height: 180px;
      border-bottom: 2px solid rgba(128, 128, 128, 0.5);
  
      img{
        height: 100%;
      }
  
      .fz{
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        align-content: center;
        margin-left: 10px;
        margin-right: 300px;
  
        p{
          font-size: 3rem;
          font-family: 'KaiTi', '楷体', 'STKaiti', '华文楷体', serif;
        }
      }
  
      .search{
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        align-content: center;
  
        padding-left: 300px;
      }
    }
  }

  .main{
    padding: 0px 40px;
  }

  .footer{
    height: 300px;
    padding: 0;
  }

  .el-backtop{
    width: 60px;
    height: 60px;
  }
}
</style>