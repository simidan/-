<template>
  <div class="personal">
    <div class="main">
      <asideVue></asideVue>
      <router-view></router-view>
    </div>
  </div>
</template>

<script setup lang="ts">
import asideVue from '@/components/personal/aside.vue'
</script>

<style scoped lang="scss">
.personal{
  height: 100%;
  width: 95%;
  display: flex;
  flex-wrap: wrap;
  align-content: center;
  justify-content: center;
  margin: 20px 0;
  
  .main{
    display: flex;
    flex-wrap: wrap;
    align-content: center;
    justify-content: center;
    width: 90%;
  }
}

</style>