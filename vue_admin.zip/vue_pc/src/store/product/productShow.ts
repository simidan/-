import { productShowApi } from "@/api";
import { defineStore } from "pinia";

interface pageLimit{
  page:number,
  limit:number
}

const productShow = defineStore('productShow',()=>{
  
  const productShow = async(info:pageLimit)=>{
    const res = await productShowApi(info)
    const result = res.data
    return result
  }

  return { productShow }
})

export default productShow