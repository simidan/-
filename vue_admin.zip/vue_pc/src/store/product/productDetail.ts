import { productDetailApi } from "@/api";
import { defineStore } from "pinia";

const productDetailControl = defineStore('productDetail',()=>{
  const productDetail = async(product_id:number)=>{
    const res = await productDetailApi(product_id)
    const result = res.data
    return result
  }

  return { productDetail }
})

export default productDetailControl