import { productSearchApi, productSearchOtherApi } from "@/api";
import { defineStore } from "pinia";

interface SearchInfo0 {
  name: string;
  limit: number;
  page: number;
  sortBy: string;
  order: string;
  origin: string;
  harvestDateStart: string;
  harvestDateEnd: string;
}

interface SearchInfo1 {
  category_id: number;
  sub_category_id: number;
  limit: number;
  page: number;
  sortBy: string;
  order: string;
  origin: string;
  harvestDateStart: string;
  harvestDateEnd: string;
}

const productSearch = defineStore('searchMainPage',()=>{
  //0是首页分类进入，1是搜索框进入
  let searchMark = 0

  let load = false

  let pagination = {
    "total": 0,
    "page": 0,
    "limit": 0,
    "totalPages": 0
}

  const searchInfo1 = {
    'name':'', 
    'limit' : 10, 
    'page' : 1,
    'sortBy':'',
    'order':'',
    'origin':'',
    'harvestDateStart':'',
    'harvestDateEnd':''
  }

  const searchInfo0 = {
    'category_id':0,
    'sub_category_id':0,
    'limit':10,
    'page':1,
    'sortBy':'',
    'order':'',
    'origin':'',
    'harvestDateStart':'',
    'harvestDateEnd':''
  }

  const searchInfo0Group: any[] = [];
  const searchInfo1Group: any[] = [];

  const productSearch = async()=>{
    const res = await productSearchApi(searchInfo1)
    const result = res.data
    return result
  }

  const productSearchOther = async()=>{
    const res = await productSearchOtherApi(searchInfo0)
    const result = res.data
    return result
  }

  return { searchMark, searchInfo0, searchInfo0Group, searchInfo1, searchInfo1Group, load, pagination, productSearch, productSearchOther, }
})

export default productSearch