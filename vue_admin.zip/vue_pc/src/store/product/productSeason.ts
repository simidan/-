import { productSeasonApi } from "@/api";
import { defineStore } from "pinia";

const productBySeason = defineStore('productSeason',()=>{
  const productSeason = async(month:number)=>{
    const res = await productSeasonApi(month)
    const result = res.data
    return result
  }

  return { productSeason }
})

export default productBySeason