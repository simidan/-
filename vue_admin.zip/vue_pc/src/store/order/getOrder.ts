import { orderGetApi } from "@/api";
import { defineStore } from "pinia";

interface pageLimit{
  page:number,
  limit:number
}

const getOrderControl = defineStore('getOrder',()=>{
  const getOrder = async (info:pageLimit)=>{
    const res = await orderGetApi(info)
    const result = res.data
    return result
  }
  
  return { getOrder, }
})

export default getOrderControl