import { orderDetailApi, orderGetApi } from "@/api";
import { defineStore } from "pinia";

const orderDetailControl = defineStore('orderDetail',()=>{
  const orderDetail = async (order_id:number)=>{
    const res = await orderDetailApi(order_id)
    const result = res.data
    return result
  }
  
  return { orderDetail, }
})

export default orderDetailControl