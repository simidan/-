import { defineStore } from "pinia";

const mainPageControl = defineStore('mainPage',()=>{
  //0是首页，1是search，2是
  const pageChangeMark = 0

  const payPage = false

  return { pageChangeMark, payPage }
})

export default mainPageControl