import { updateCartApi } from "@/api";
import { defineStore } from "pinia";

interface Cart {
  productId:number,
  quantity:number
}

const updateCartControl = defineStore('cartQuantity',()=>{
  const updateCart = async(info:Cart)=>{
    const res = await updateCartApi(info)
    const result = res.data
    return result
  }
  
  return { updateCart }
})

export default updateCartControl