import { manageCartApi } from "@/api";
import { defineStore } from "pinia";

interface manageCart {
  productId:number,
  action:string,
}

const manageCartControl = defineStore('manageCart',()=>{
  const manageCart = async (info:manageCart)=>{
    const res = await manageCartApi(info)
    const result = res.data
    return result
  }
  
  return { manageCart, }
})

export default manageCartControl