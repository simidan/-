import { loginApi, registerApi } from "@/api";
import { userMessage } from "@/utils/interface";
import { defineStore } from "pinia";

const loginPageControl = defineStore('loginPage',()=>{
  //0是登录表格，1是注册表格
  const pageChangeMark = 0

  interface loginInfo {
    phone: string;
    password: string;
  }
  const login = async(loginInfo:loginInfo)=>{
    const res = await loginApi(loginInfo)
    const result = res.data
    return result
  }

  interface registerInfo extends Omit<userMessage, 'avatar'|'full_name'|'default_address'> {}
  const register = async(registerInfo:registerInfo)=>{
    const res = await registerApi(registerInfo)
    const result = res.data
    return result
  }

  return { pageChangeMark, login, register, }
})

export default loginPageControl