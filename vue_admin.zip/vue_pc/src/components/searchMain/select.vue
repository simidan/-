<template>
  <div class="select">
    <div class="categories" v-if="productSearchStore.searchMark === 0">
      <div class="categories_text">
        分类
      </div>
      <div class="categories_item">
        <ul>
          <li v-for="(item,index) in categoriesGroup" :key="index" @click="selectedCategoryIndex(index)" :style="categoryIndex === index ? { backgroundColor: 'grey', color: '#fff' } : {}">
            {{item}}
          </li>
        </ul>
      </div>
    </div>
    <div class="categories">
      <div class="categories_text" v-if="categoryIndex!==null && productSearchStore.searchMark === 0">
        分类
      </div>
      <div class="categories_item" v-if="categoryIndex!==null && productSearchStore.searchMark === 0">
        <ul>
          <li v-for="(subItem, subIndex) in currentSubCategories" :key="subIndex" @click="selectedSubCategoryIndex(subIndex)" :style="subCategoryIndex === subIndex ? { backgroundColor: 'grey', color: '#fff' } : {}">
            {{ subItem }}
          </li>
        </ul>
      </div>
    </div>
    <div class="select_line">
      <div class="select_item">
        <p>价格</p>
        <el-select v-model="value" placeholder="Select" style="width: 240px;margin-left: 20px;">
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
      </div>
      <div class="select_item">
        <p>产地</p>
        <elui-china-area-dht @change="onChange" style="width: 240px;margin-left: 20px;"></elui-china-area-dht>
      </div>
      <div class="select_item">
        <p>采摘时间</p>
        <el-date-picker
          v-model="harvestDateStart"
          type="date"
          placeholder="Pick a day"
          style="width: 240px;height: 40px;margin-left: 20px;margin-right: 20px"
          value-format="YYYY-MM-DD"
        />
        ------
        <el-date-picker
          v-model="harvestDateEnd"
          type="date"
          placeholder="Pick a day"
          style="width: 240px;height: 40px;margin-left: 20px;"
          value-format="YYYY-MM-DD"
        />
      </div>
      <div class="select_item">
        <el-button type="success" plain style="font-size:1.3rem;width:100px;height:40px;margin-left: 20px;margin-right: 20px" @click="spiltSearch">确认</el-button>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { onMounted, reactive, ref, watch } from "vue";
import { getData } from "@/api/lineCity";
import { EluiChinaAreaDht } from 'elui-china-area-dht'

import { format, addMonths } from 'date-fns';

import { ElMessage, ElMessageBox } from 'element-plus'
import type { Action } from 'element-plus'

import productSearch from '@/store/product/productSearch'


const productSearchStore = productSearch()

type SubCategoriesMap = {
  [key: string]: string[];
};

const categoriesGroup = ref([
  '新鲜农产品',
  '粮油副食',
  '冷冻冷藏食品',
  '休闲食品'
])

const sub_categoriesGroup: SubCategoriesMap = reactive({
  '新鲜农产品': ['蔬菜', '水果', '肉类'],
  '粮油副食': ['谷类', '食用油'],
  '冷冻冷藏食品': ['冷冻肉类'],
  '休闲食品': ['干果坚果']
});

//价格排序
const value = ref('')

const options = [
  {
    value: 'asc',
    label: '从低到高',
  },
  {
    value: 'desc',
    label: '从高到低',
  }
]

//产地选择
const orgin = ref('')

let chinaData = new EluiChinaAreaDht.ChinaArea().chinaAreaflat
 
const onChange = (e:any) => {
  console.log(e);
    const province = chinaData[e[0]]
    const city = chinaData[e[1]]
    const area = chinaData[e[2]]
    const adress =`${province.label}-${city.label}-${area.label}`
    orgin.value = adress
}

//采摘日期
const harvestDateStart = ref('')
const harvestDateEnd = ref<string | null>(null)


//一级分类和二级分类
const categoryIndex = ref<number | null>(null)
const subCategoryIndex = ref<number | null>(null)
const currentSubCategories = ref<string[]>([]);

const selectedCategoryIndex = (index: number) => {
  categoryIndex.value = index;
  console.log(categoryIndex.value);
  
  subCategoryIndex.value = null
  productSearchStore.searchInfo0.sub_category_id = 0
  const selectedCategory = categoriesGroup.value[index];
  currentSubCategories.value = sub_categoriesGroup[selectedCategory] || [];
};

const selectedSubCategoryIndex = (index: number) => {
  subCategoryIndex.value = index;
};

//筛选搜索
const spiltSearch = async()=>{
  if(productSearchStore.searchMark===1){
    if(value.value){
      productSearchStore.searchInfo1.sortBy = 'price'
      productSearchStore.searchInfo1.order = value.value
    }
    if(orgin.value){
      productSearchStore.searchInfo1.origin = orgin.value
    }
    if(harvestDateStart.value && harvestDateEnd.value){
      productSearchStore.searchInfo1.harvestDateStart = harvestDateStart.value
      productSearchStore.searchInfo1.harvestDateEnd = harvestDateEnd.value
    }
    productSearchStore.searchInfo1.page = 1
    try{
      productSearchStore.load = true
      await productSearchStore.productSearch().then((res)=>{
        if(res.statusCode === 200){
          productSearchStore.searchMark = 1
          productSearchStore.searchInfo1Group = res.data
          productSearchStore.pagination = res.pagination
          productSearchStore.load = false
        }else{
          ElMessageBox.alert('搜索失败，请重试', 'Title', {
            confirmButtonText: 'OK',
            callback: (action: Action) => {
              ElMessage({
                type: 'info',
                message: `action: ${action}`,
              })
            },
          })
        }
      })
    }catch(err){
      ElMessageBox.alert('搜索失败，请重试', 'Title', {
      confirmButtonText: 'OK',
      callback: (action: Action) => {
        ElMessage({
          type: 'info',
          message: `action: ${action}`,
        })
      },
    })
    }
  }else if(productSearchStore.searchMark===0){
    if(value.value){
      productSearchStore.searchInfo0.sortBy = 'price'
      productSearchStore.searchInfo0.order = value.value
    }
    if(orgin.value){
      productSearchStore.searchInfo0.origin = orgin.value
    }
    if(harvestDateStart.value && harvestDateEnd.value){
      productSearchStore.searchInfo0.harvestDateStart = harvestDateStart.value
      productSearchStore.searchInfo0.harvestDateEnd = harvestDateEnd.value
    }
    if(subCategoryIndex.value!==null){
      if(categoryIndex.value===0){
        productSearchStore.searchInfo0.sub_category_id=subCategoryIndex.value+1
      }else if(categoryIndex.value===1){
        productSearchStore.searchInfo0.sub_category_id=subCategoryIndex.value+4
      }else if(categoryIndex.value===2){
        productSearchStore.searchInfo0.sub_category_id=subCategoryIndex.value+6
      }else if(categoryIndex.value===3){
        productSearchStore.searchInfo0.sub_category_id=subCategoryIndex.value+7
      }
    }
    if(categoryIndex.value!==null){
      productSearchStore.searchInfo0.category_id=categoryIndex.value +1
    }
    productSearchStore.searchInfo0.page = 1
    try{
      productSearchStore.load = true
      await productSearchStore.productSearchOther().then((res)=>{
        if(res.statusCode === 200){
          productSearchStore.searchMark = 0
          productSearchStore.searchInfo0Group = res.data
          productSearchStore.pagination = res.pagination
          productSearchStore.load = false
        }else{
          ElMessageBox.alert('搜索失败，请重试', 'Title', {
            confirmButtonText: 'OK',
            callback: (action: Action) => {
              ElMessage({
                type: 'info',
                message: `action: ${action}`,
              })
            },
          })
        }
      })
    }catch(err){
      ElMessageBox.alert('搜索失败，请重试', 'Title', {
      confirmButtonText: 'OK',
      callback: (action: Action) => {
        ElMessage({
          type: 'info',
          message: `action: ${action}`,
        })
      },
    })
    }
  }
}

watch(harvestDateStart, (newValue, oldValue) => {
  // 当harvestDateStart有值而harvestDateEnd没有值时
  if (newValue && !harvestDateEnd.value) {
    const newEndDate = addMonths(new Date(newValue), 1);
    harvestDateEnd.value = format(newEndDate, 'yyyy-MM-dd'); // 更新harvestDateEnd为一个月后
  }
}, { immediate: true });

watch([harvestDateStart, harvestDateEnd], ([newStart, newEnd], [oldStart, oldEnd]) => {
  // 检查日期是否合理：结束日期不应早于开始日期
  if (newStart && newEnd && new Date(newEnd) < new Date(newStart)) {
    harvestDateEnd.value = oldEnd; // 如果不合理，则重置结束日期
  }
});

onMounted(()=>{
  if(productSearchStore.searchMark === 0){
    categoryIndex.value = productSearchStore.searchInfo0.category_id-1
    const selectedCategory = categoriesGroup.value[productSearchStore.searchInfo0.category_id-1];
  currentSubCategories.value = sub_categoriesGroup[selectedCategory] || [];
  }
})
</script>


<style lang="scss" scoped>
.select{
  margin-top: 10px;
  width: 100%;
  background-color: #fff;
  border-radius: 10px;
  box-shadow: 0px 0px 10px 2px rgba(137, 136, 136, 0.5);
  padding: 10px 20px;

  .categories{
    display: flex;
    flex-wrap: wrap;
    align-content: center;
    width: 100%;

    .categories_text{
      font-size: 1.4rem;
      color: grey;
      width: 10%;
      height: 100%;
      border-right: 1px solid rgba(128, 128, 128, 0.5);
      border-bottom: 1px solid rgba(128, 128, 128, 0.5);
      text-align: center;
      padding-bottom: 5px;
    }

    .categories_item{
      width: 89%;
      margin-bottom: 10px;

      ul{
        display: flex;
        border-bottom: 1px solid rgba(128, 128, 128, 0.5);

        li{
          display: block;
          font-size: 1.4rem;
          color: grey;
          padding: 0 10px;
          margin-left: 20px;
          margin-bottom: 5px;
          border-radius: 10px;

          &:hover{
            background-color: grey;
            color: #fff;
          }
          
        }
      }
    }
  }

  .select_line{
    display: flex;
    flex-wrap: wrap;
    align-content: center;

    .select_item{
      display: flex;
      flex-wrap: wrap;
      align-content: center;
      border-left: 1px solid rgba(128, 128, 128, 0.5);
      margin-right: 20px;

      p{
        font-size: 1.4rem;
        color: grey;
        margin-left: 20px;
      }

      .el-cascader{
        height: 60px;
      }
      .el-input__wrapper{
        min-height: 60px;
      }
    }
  }
}
</style>