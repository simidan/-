<template>
  <div class="personal-main" v-loading="loading">
    <div class="header">
      <img crossorigin="anonymous" :src="userInfo.avatar" alt="">
      <el-button class="update" type="success" plain @click="userUpdate" v-show="!update">修改信息</el-button>
      <el-button class="update_sure" type="success" plain @click="userUpdateSure" v-show="update">保存</el-button>
      <el-button class="update_back" type="success" plain @click="userUpdate" v-show="update">返回</el-button>
    </div>
    <div class="userTr">
      <div class="label">
        <el-icon><User /></el-icon>
        姓名
      </div>
      <div class="info" v-if="!update">
        {{ userInfo.username }}
      </div>
      <div class="info_update" v-else>
        <el-input v-model="userInfo.username" style="width: 100%;height:80px;font-size:1.5rem" placeholder="Please input"/>
      </div>
    </div>
    <div class="userTr">
      <div class="label">
        <el-icon v-if="userInfo.gender==='0'"><Male /></el-icon>
        <el-icon v-else><Female /></el-icon>
        性别
      </div>
      <div class="info" v-if="!update">
        {{ userInfo.gender==='0'?'男':'女' }}
      </div>
      <div class="info" v-else>
        <el-radio-group v-model="userInfo.gender" class="ml-4">
          <el-radio value="0" size="large">男</el-radio>
          <el-radio value="1" size="large">女</el-radio>
        </el-radio-group>
      </div>
    </div>
    <div class="userTr">
      <div class="label">
        <el-icon><Iphone /></el-icon>
        电话
      </div>
      <div class="info" v-if="!update">
        {{ userInfo.phone }}
      </div>
      <div class="info_update" v-else>
        <el-input v-model="userInfo.phone" style="width: 100%;height:80px;font-size:1.5rem" placeholder="Please input"/>
      </div>
    </div>
    <div class="userTr">
      <div class="label">
        <el-icon><Message /></el-icon>
        邮箱
      </div>
      <div class="info" v-if="!update">
        {{ userInfo.email }}
      </div>
      <div class="info_update" v-else>
        <el-input v-model="userInfo.email" style="width: 100%;height:80px;font-size:1.5rem" placeholder="Please input"/>
      </div>
    </div>
    <div class="userTr">
      <div class="label">
        <el-icon><IceCream /></el-icon>
        出生日期
      </div>
      <div class="info" v-if="!update">
        {{ userInfo.birthday }}
      </div>
      <div class="info_update" v-else>
        <el-input v-model="userInfo.birthday" style="width: 100%;height:80px;font-size:1.5rem" placeholder="Please input"/>
      </div>
    </div>
    <div class="userTr">
      <div class="label">
        <el-icon><IceCream /></el-icon>
        收货地址
      </div>
      <div class="info" v-if="!update">
        {{ userInfo.default_address }}
      </div>
      <div class="info_update" v-else>
        <elui-china-area-dht @change="onChange" style="width: 100%;height:80px;font-size:1.5rem"></elui-china-area-dht>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from "vue";

import userUpdateControl from '@/store/user/userUpdate'

import { getData } from "@/api/lineCity";
import { EluiChinaAreaDht } from 'elui-china-area-dht'
import { ElMessage, ElMessageBox } from 'element-plus'
import type { Action } from 'element-plus'

import { userMessage } from "@/utils/interface";

interface userUpdate extends Omit<userMessage, 'password'>{
  user_id:number
}
const userUpdateStore = userUpdateControl()

const userInfo = ref({
  avatar: "",
  birthday: "",
  default_address: "",
  email: "",
  full_name: "",
  gender: "",
  phone: "",
  status: '',
  user_id: 0,
  username: ""
});
const update = ref(false)
const loading = ref(true)

const userUpdate = ()=>{
  const userString = localStorage.getItem('user');
  if(userString){
    userInfo.value=JSON.parse(userString)
    userInfo.value.birthday = userInfo.value.birthday.substring(0, 10)
  }
  update.value = !update.value
}

const userUpdateSure = async ()=>{
  loading.value = true
  const formattedData: userUpdate = {
    avatar: userInfo.value.avatar,
    birthday: userInfo.value.birthday,
    default_address: userInfo.value.default_address,
    email: userInfo.value.email,
    full_name: userInfo.value.full_name,
    gender: userInfo.value.gender,
    phone: userInfo.value.phone,
    user_id: Number(userInfo.value.user_id),
    username: userInfo.value.username,
  };

  try {
    await userUpdateStore.userUpdate(formattedData).then((res)=>
      {
        if(res.statusCode === 200){
          localStorage.setItem('user',JSON.stringify(formattedData))
          update.value = false
          ElMessageBox.alert('信息更新成功', 'Title', {
              confirmButtonText: 'OK',
              callback: (action: Action) => {
                ElMessage({
                type: 'info',
                message: `action: ${action}`,
              })
            },
          })
          loading.value = false
        }else{
          ElMessageBox.alert('信息更新失败，请重试', 'Title', {
              confirmButtonText: 'OK',
              callback: (action: Action) => {
                ElMessage({
                type: 'info',
                message: `action: ${action}`,
              })
            },
          })
        }
      }
    )
  } catch (error) {
    // 处理调用过程中可能出现的异常
    console.error("更新过程中出现错误：", error);
  }
}

let chinaData = new EluiChinaAreaDht.ChinaArea().chinaAreaflat
 
const onChange = (e:any) => {
    const province = chinaData[e[0]]
    const city = chinaData[e[1]]
    const area = chinaData[e[2]]
    const adress =`${province.label}-${city.label}-${area.label}`
    userInfo.value.default_address = adress
}

onMounted(()=>{
  const userString = localStorage.getItem('user');
  if(userString){
    userInfo.value=JSON.parse(userString)
    userInfo.value.birthday = userInfo.value.birthday.substring(0, 10)
    loading.value = false
  }
})
</script>

<style scoped lang="scss">
.personal-main{
  width: 80%;
  margin-left: 4%;

  display: flex;
  flex-wrap: wrap;

  border: 1px solid var(--el-border-color);
  border-radius: 10px;
  box-shadow: var(--el-box-shadow-light);

  font-size: 2rem;
  padding: 0 0 10px 0;

  .header{
    display: flex;
    flex-wrap: wrap;
    align-content: center;

    width: 100%;
    margin: 10px;

    img{
      height: 200px;
      width: 200px;
      border-radius: 10px;
    }

    .update{
      width: 150px;
      height: 80px;
      margin: auto 0 auto 70%;
      font-size: 1.5rem;
    }
    .update_sure{
      width: 150px;
      height: 80px;
      margin: auto 0 auto 57%;
      font-size: 1.5rem;
    }
    .update_back{
      width: 150px;
      height: 80px;
      margin: auto 0 auto 20px;
      font-size: 1.5rem;
    }
  }

  .userTr{
    display: flex;
    flex-wrap: wrap;
    align-content: center;

    height: 80px;
    width: 100%;
    border: 1px solid var(--el-border-color);
    background-color: #fff;
    
    .label{
      width: 15%;
      background-color: rgba(168, 168, 168, 0.5);
      font-size: 1.5rem;
      line-height: 80px;
      padding: 0 0 0 50px
    }

    .info{
      flex-grow: 1;
      display: flex;
      flex-wrap: wrap;
      align-content: center;
      font-size: 1.5rem;
      color: rgba(75, 75, 75, 0.8);
      padding: 0 0 0 10px;
    }

    .info_update{
      flex-grow: 1;
      display: flex;
      flex-wrap: wrap;
      align-content: center;
      font-size: 1.5rem;
      color: rgba(75, 75, 75, 0.8);
    }
  }

  :deep(.el-cascader .el-input){
    height: 100%;
  }
}
</style>