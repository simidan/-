<template>
  <div class="personal_aside">
      <el-col style="height:100%" class="main">
        <el-menu
          :default-active="index"
          class="el-menu-vertical-demo"
        >
          <el-menu-item index="1" @click="goRouter('/personal')">
            <span>个人信息</span>
          </el-menu-item>
          <el-menu-item index="2" @click="goRouter('/personal/shopCart')">
            <span>购物车</span>
          </el-menu-item>
          <el-menu-item index="3" @click="goRouter('/personal/order')">
            <span>订单</span>
          </el-menu-item>
          <el-menu-item index="4" @click="loginOut">
            <span>退出</span>
          </el-menu-item>
        </el-menu>
      </el-col>
  </div>
</template>

<script setup lang="ts">
import router from "@/router"
import { onMounted, ref } from "vue"

import { useRoute } from 'vue-router'

const route = useRoute()

const index = ref(0)

const loginOut=()=>{
  localStorage.removeItem('tokn')
  localStorage.removeItem('user')
  router.push({name:'login'})
}

const goRouter = (path:string)=>{
  router.push(path)
}

onMounted(()=>{
  const path = route.path
  if(path == '/personal'){
    index.value = 1
  }else if(path == '/personal/shopCart'){
    index.value = 2
  }else if(path == '/personal/order'){
    index.value = 3
  }
})
</script>

<style scoped lang="scss">
.personal_aside{
  width: 15%;
  height: 400px;

  border: 1px solid var(--el-border-color);
  border-radius: 8px;
  box-shadow: var(--el-box-shadow-light);

  .main{
    border-radius: 8px;

    ul{
      height: 100%;
      border-radius: 8px;
      padding:  10px 20px;
  
      li{
        height: 24%;
        font-size: 1.3rem;
        font-weight: 600;
  
        display: flex;
        flex-wrap: wrap;
        align-content: center;
        justify-content: center;
        border-bottom: 1px solid var(--el-border-color);
      }
    }
  }
}

</style>