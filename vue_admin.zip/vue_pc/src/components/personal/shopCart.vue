<template>
  <div class="personal-shopCart" v-loading="loading">
    <ul>
      <li v-for="item in cartInfo" :key="item.productId" @click="pay(item.productId,item.quantity)">
        <img crossorigin="anonymous" :src="item.image">
        <div class="name">
          {{ item.name }}
        </div>
        <div class="price">
          {{ item.price }}
        </div>
        <div class="quantity">
          <el-input-number v-model="item.quantity" :min="1" @change="handleChangeDebounced(item.quantity,item.productId)" style="height: 40px;font-size: 1.5rem;"/>
        </div>
        <div class="total">
           {{ (item.price * item.quantity).toFixed(2) }}
        </div>
        <div class="remove">
          <el-text class="mx-1" @click="manageCart('delete', item.productId)">移除</el-text>
        </div>
      </li>
    </ul>
    <el-pagination layout="prev, pager, next" :total="totalpage*10" v-model:current-page="pageLimit.page" @current-change="currentChange"/>
  </div>
</template>

<script setup lang="ts">
import getCartControl from '@/store/shopCart/getCart'
import updateCartControl from '@/store/shopCart/updateCart'
import manageCartControl from '@/store/shopCart/manageCart'
import { onMounted, ref } from 'vue'

import { ElMessage, ElMessageBox } from 'element-plus'
import type { Action } from 'element-plus'
import router from '@/router'

const getCartStore = getCartControl()
const updateCartStore = updateCartControl()
const manageCartStore = manageCartControl()

interface CartItem {
  productId: number;
  quantity: number;
  name: string;
  price: number;
  image: string;
}
interface pageLimit{
  page:number,
  limit:number
}

const cartInfo = ref<CartItem[]>([])
const pageLimit = ref({
  "page":1,
  "limit":10,
})
const loading = ref(true)
const totalpage = ref(0)

const getCart = async (info:pageLimit) => {
  loading.value = true
  try {
    await getCartStore.getCart(info).then((res)=>{
      cartInfo.value = res.data as CartItem[]
      pageLimit.value.page = res.pagination.page
      totalpage.value = res.pagination.totalPages
      loading.value = false
    })
  } catch (error) {
    ElMessageBox.alert('获取购物车数据失败', 'Title', {
          confirmButtonText: 'OK',
          callback: (action: Action) => {
            ElMessage({
              type: 'info',
              message: `action: ${action}`,
            });
          },
        });
  }
}

const manageCart = async (action:string, productId:number)=>{
  const info = {action,productId}
  loading.value = true
  
  try {
    await manageCartStore.manageCart(info).then(async(res)=>{
      cartInfo.value = res.data as CartItem[]
      loading.value = false
      setTimeout(() => {
        getCart(pageLimit.value)
      }, 2000);
    })
  } catch (error) {
    ElMessageBox.alert('移除商品数据失败', 'Title', {
          confirmButtonText: 'OK',
          callback: (action: Action) => {
            ElMessage({
              type: 'info',
              message: `action: ${action}`,
            });
          },
        });
  }
}

const currentChange = async()=>{
  try {
    getCart(pageLimit.value)
  } catch (error) {
    ElMessageBox.alert('获取购物车数据失败', 'Title', {
          confirmButtonText: 'OK',
          callback: (action: Action) => {
            ElMessage({
              type: 'info',
              message: `action: ${action}`,
            });
          },
        });
  }
}

const pay = (product_id:number,quantitys:number)=>{
  router.replace({ path: '/pay',query: { product_id, quantitys  } })
}

function debounce<T extends (...args: any[]) => void>(func: T, wait: number): (...args: Parameters<T>) => void {
  let timeout: number | null = null;
  return (...args: Parameters<T>) => {
    clearTimeout(timeout as number);
    timeout = window.setTimeout(() => {
      func(...args);
    }, wait);
  };
}

const handleChangeDebounced = debounce(async (quantity:number, productId:number) => {
  try {
    const info = { 'productId': productId, 'quantity': quantity };
    await updateCartStore.updateCart(info).then((res) => {
      if (res.statusCode === 200) {
        ElMessageBox.alert('数量更新成功', 'Title', {
          confirmButtonText: 'OK',
          callback: (action: Action) => {
            ElMessage({
              type: 'info',
              message: `action: ${action}`,
            });
          },
        });
      }
    });
  } catch (error) {
    console.error("购物车数据更新失败：", error);
  }
}, 1000);

onMounted(() => {
  setTimeout(() => {
    getCart(pageLimit.value)
  }, 1000);
})
</script>


<style scoped lang="scss">
.personal-shopCart{
  width: 80%;
  margin-left: 4%;

  display: flex;
  flex-wrap: wrap;

  border: 1px solid var(--el-border-color);
  border-radius: 10px;
  box-shadow: var(--el-box-shadow-light);

  font-size: 2rem;
  padding: 10px 0 10px 0;

  ul{
    width: 100%;

    li{
      display: flex;

      height: 80px;
      width: 100%;
      padding:  10px 0;
      margin-bottom: 5px;
      border: 1px solid var(--el-border-color);
      background-color: #fff;

      font-size: 1.5rem;
      color: rgba(75, 75, 75, 0.8);

      img{
        aspect-ratio: 1 / 1;
        height: 100%;
        margin-left: 5px;
        border-radius: 10px;
      }

      .name {
        display: flex;
        justify-content: center;
        width: 20%;
        height: 100%;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .price{
        display: flex;
        justify-content: center;
        width: 15%;
        height: 100%;
      }

      .quantity{
        display: flex;
        justify-content: center;
        width: 15%;
        height: 100%;
      }

      .total{
        display: flex;
        justify-content: center;
        width: 15%;
        height: 100%;
      }

      .remove{
        margin-left: 20%;
        
        .el-text{
          font-size: 1.3rem;

          &:hover{
            color: red;
            filter: brightness(120%);
            transition: filter .5s;
          }
        }
      }
    }
  }
}

</style>