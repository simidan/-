<template>
  <div class="personal-order" v-loading="loading">
    <ul>
      <li v-for="item in orderInfo" :key="item.order_id">
        <div class="title">
          <p>{{ item.created_at }}</p>
          <P> 订单号：{{ item.order_id }} </P>
        </div>
        <div class="main">
          <img crossorigin="anonymous" :src="item.product_image" alt="">
          <div class="name">
            {{ item.product_name }}
          </div>
          <div class="quantity">
            x {{ item.quantity }}
          </div>
          <div class="total_amount">
            ￥{{ item.total_amount }}
          </div>
          <div class="total_amount">
            支付方式:{{ getPaymentMethodInChinese(item.payment_method) }}
          </div>
          <div class="total_amount">
            支付状态: {{ getPaymentStatusInChinese(item.payment_status) }}
            <el-button v-if="item.payment_status==='unpaid'" style="margin-top:10px;" @click="goPay(item.order_id)">
              去结算
            </el-button>
          </div>
          <div class="total_amount">
            订单状态: {{ getOrderStatusInChinese(item.status) }}
          </div>
        </div>
      </li>
      <el-pagination layout="prev, pager, next" :total="totalpage*10" v-model:current-page="pageLimit.page" @current-change="currentChange"/>
    </ul>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from "vue";

import { ElMessage, ElMessageBox } from 'element-plus'
import type { Action } from 'element-plus'

import getOrderControl from '@/store/order/getOrder'
import mainPageControl from '@/store/mainPage/mainPageControl'
import { orderMessage } from "@/utils/interface";

import { OrderItem, getPaymentMethodInChinese, getPaymentStatusInChinese, getOrderStatusInChinese } from '@/utils/orderMappings';
import router from "@/router";

interface pageLimit{
  page:number,
  limit:number
}

interface orderInfo extends orderMessage {
  created_at:string,
  product_image:string,
  product_name:string,
}

const getOrderStore = getOrderControl()
const mainPageStore = mainPageControl()

const pageLimit = ref<pageLimit>({
  'page':1,
  'limit':10,
})
const orderInfo = ref<orderInfo[]>([])
const loading = ref(true)
const totalpage = ref(0)

const getOrder = async(info:pageLimit)=>{
  try{
    await getOrderStore.getOrder(info).then((res)=>{
      orderInfo.value = res.data as orderInfo[]
      loading.value=false
    })
  }catch(err){
    ElMessageBox.alert('获取订单数据失败', 'Title', {
          confirmButtonText: 'OK',
          callback: (action: Action) => {
            ElMessage({
              type: 'info',
              message: `action: ${action}`,
            });
          },
        });
  }
}

const currentChange = async()=>{
  try {
    getOrder(pageLimit.value)
  } catch (error) {
    ElMessageBox.alert('获取购物车数据失败', 'Title', {
          confirmButtonText: 'OK',
          callback: (action: Action) => {
            ElMessage({
              type: 'info',
              message: `action: ${action}`,
            });
          },
        });
  }
}

const goPay = (order_id:number)=>{
  mainPageStore.payPage = true
  router.replace({ path: '/pay',query: { order_id } })
}

onMounted(()=>{
  setTimeout(() => {
    getOrder(pageLimit.value)
  }, 1000);
})
</script>

<style scoped lang="scss">
.personal-order{
  width: 80%;
  margin-left: 4%;

  display: flex;
  flex-wrap: wrap;
  justify-content: center;

  border: 1px solid var(--el-border-color);
  border-radius: 10px;
  box-shadow: var(--el-box-shadow-light);

  ul{
    width: 100%;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;

    li{
      display: flex;
      flex-direction: column;

      height: 180px;
      width: 95%;
      margin-top: 5px;
      border: 1px solid var(--el-border-color);
      background-color: #fff;
      border-radius: 10px;

      font-size: 1.5rem;
      color: rgba(75, 75, 75, 0.8);

      .title{
        display: flex;
        flex-wrap: wrap;
        align-content: center;

        height: 20%;
        width: 100%;
        background-color: rgba(171, 171, 171, 0.6);
        border-radius: 10px 10px 0 0;

        p{
          margin-left: 10px;
          font-size: 1rem;
        }
        
        p:nth-of-type(2){
          margin-left: 50px;
          font-size: 1rem;
        }
      }

      .main{
        display: flex;
        flex-wrap: wrap;
        align-content: center;
        
        height: 66%;
        width: 100%;
        padding: 1% 10px 1% 10px;

        border-radius: 0 0 10px 10px;

        img{
          aspect-ratio: 1 / 1;
          height: 100%;
          border-radius: 10px;
        }

        .name{
          display: flex;
          flex-wrap: wrap;
          justify-content: center;
          align-content: center;
          margin-left: 50px;
          width: 10%;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          padding: 0 10px;
        }

        .quantity{
          display: flex;
          flex-wrap: wrap;
          justify-content: center;
          align-content: center;
          margin-left: 10px;
          width: 10%;
          border-right: 1px solid var(--el-border-color);
          padding: 0 10px;
        }
        .total_amount{
          display: flex;
          flex-wrap: wrap;
          justify-content: center;
          align-content: center;

          width: 13%;
          font-size: 1rem;
          border-right: 1px solid var(--el-border-color);
          padding: 0 10px;
        }
      }
    }
  }
}

</style>