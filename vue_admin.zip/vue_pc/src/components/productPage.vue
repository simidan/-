<template>
  <div class="product_item">
    <div class="product_item_img">
      <img crossorigin="anonymous" :src="item.image" alt="">
    </div>
    <div class="product_item_name">
      {{ item.name }}
    </div>
    <div class="product_item_price">
      <p>￥</p>
      <p>{{item.price}}</p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { defineProps, onMounted } from 'vue';

// 定义接收的props，这里假设每个 item 包含 name, imageUrl, 和 price
const props = defineProps({
  item: {
    type: Object,
    required: true
  }
});

</script>

<style lang="scss" scoped>
.product_item{
  display: flex;
  flex-direction: column;
  flex-wrap: wrap;
  align-content: center;
  justify-content: center;

  height: 300px;
  width: 180px;
  margin: 0 5px;

  .product_item_img{
    width: 100%;
    aspect-ratio: 1 / 1;
    display: flex;
    flex-wrap: wrap;
    align-content: center;
    justify-content: center;

    img{
     width: 100%;
     aspect-ratio: 1 / 1;
    }
  }

  .product_item_name{
    width: 90%;
    height: 20%; /* 或者设置一个固定的高度，但确保足够容纳两行文本 */
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2; /* 定义显示的行数 */
    margin: auto;
    margin-top: 20px;
    color: rgba(90, 90, 90, 0.9);
  }

  .product_item_price{
    width: 100%;
    display: flex;
    flex-wrap: wrap;
    align-content: center;
    
    p{
      color: red;
      font-size: 1.5rem;
    }
  }
}
</style>