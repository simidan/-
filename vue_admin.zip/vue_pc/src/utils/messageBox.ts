import { ElMessage, ElMessageBox } from 'element-plus'
import type { Action } from 'element-plus'

export function messageBox (message:string) {
  ElMessageBox.alert(`${message}`, 'Title', {
    // if you want to disable its autofocus
    // autofocus: false,
    confirmButtonText: 'OK',
    callback: (action: Action) => {
      ElMessage({
        type: 'info',
        message: `action: ${action}`,
      })
    },
  })
}