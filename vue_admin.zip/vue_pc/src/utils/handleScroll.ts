// 定义一个类型为接收异步函数的类型
type AsyncFunction = () => Promise<void>;

function debounce(func: (...args: any[]) => void, wait: number, immediate: boolean = false): () => void {
  let timeout: ReturnType<typeof setTimeout> | null = null;
  return function(this: any, ...args: any[]): void {
    const context = this;
    const later = () => {
      timeout = null;
      if (!immediate) func.apply(context, args);
    };
    const callNow = immediate && !timeout;
    if (timeout) clearTimeout(timeout);
    timeout = setTimeout(later, wait);
    if (callNow) func.apply(context, args);
  };
}

// 改造后的 handleScroll 函数，它现在可以接受一个传入的函数
const createHandleScroll = (loadFunction: AsyncFunction, debounceWait: number = 200): (() => void) => {
  return debounce(() => {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;
    const windowHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
    const fullHeight = document.documentElement.scrollHeight;

    // 当用户接近页面底部150px时，调用传入的函数
    if (fullHeight - (scrollTop + windowHeight) <= 150) {
      loadFunction();
    }
  }, debounceWait);
};

export { createHandleScroll };