import router from "@/router";

const proDetail = (product_id:number) => {
  setTimeout(() => {
    router.push({ path: '/product',query: { product_id } });
  }, 1000);
};

export default proDetail;