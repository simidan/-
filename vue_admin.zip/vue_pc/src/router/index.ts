import { createRouter, createWebHashHistory, RouteRecordRaw } from 'vue-router'
import indexVue from '../views/index.vue'
import loginVue from '../views/login/index.vue'
import SearchVue from '../views/searchIndex.vue'

import mainVue from '@/views/main/index.vue'
import personalVue from '@/views/personal/index.vue'
import payVue from '@/views/pay/index.vue'
import productVue from '@/views/product.vue'

import personalMainVue from '@/components/personal/main.vue'
import personalOrderVue from '@/components/personal/order.vue'
import personalShopCartVue from '@/components/personal/shopCart.vue'

import { tokenCheckApi } from '@/api'

const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    name: 'index',
    component: indexVue,
    children: [
      {
        path: '',
        name: 'main',
        component: mainVue,
      },
      {
        path: 'personal',
        name: 'personal',
        component: personalVue,
        children:[
          {
            path: '',
            name: 'personalMain',
            component: personalMainVue,
          },
          {
            path: 'order',
            name: 'personalOrder',
            component: personalOrderVue,
          },
          {
            path: 'shopCart',
            name: 'personalShopCart',
            component: personalShopCartVue,
          },
        ]
      },
    ]
  },
  {
    path: '/login',
    name: 'login',
    component: loginVue
  },
  {
    path: '/search',
    name: 'search',
    component: SearchVue
  },
  {
    path: '/pay',
    name: 'pay',
    component: payVue
  },
  {
    path: '/product',
    name: 'product',
    component: productVue
  }
]

const router = createRouter({
  history: createWebHashHistory(),
  routes,
  scrollBehavior(to, from, savedPosition) {
    return { top: 0 };
  },
})

router.beforeEach(async (to, from, next) => {
  if (from.path && !['/', '/login'].includes(from.path)) {
    sessionStorage.setItem('previousPath', from.fullPath);
  }
  if (!['/', '/login'].includes(to.path)) {
    const token = localStorage.getItem('token');
    if (!token) {
      next('/login');
    } else {
      try {
        const res = await tokenCheckApi(token);
        if (res.data.statusCode === 200) {
          localStorage.setItem('user', JSON.stringify(res.data.data));
          next();
        } else {
          throw new Error('Authentication failed');
        }
      } catch (error) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        next('/login');
      }
    }
  } else {
    next();
  }
});

export default router