const { defineConfig } = require('@vue/cli-service')
const path = require('path');

module.exports = defineConfig({
    lintOnSave: false,
    devServer: {
        open: true,
        // host: 'localhost',
        // port: 8080,
        https: false,
        proxy: {
            "/api": {
                target: "http://localhost:9000",
                changeOrigin: true,
                pathRewrite: { '^/api': '' }
            },
        },
    },
    chainWebpack: config => {
        config.resolve.alias
            .set('@', path.resolve(__dirname, 'src'));

        config.plugin('define').tap(args => {
            const { 'process.env': env } = args[0];
            args[0]['process.env'] = {
                ...env,
                __VUE_PROD_HYDRATION_MISMATCH_DETAILS__: JSON.stringify(true)
            };
            return args;
        });
    }
})