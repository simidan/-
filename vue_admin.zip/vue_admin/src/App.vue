<template>
  <routerView></routerView>
</template>

<script setup>
</script>

<style lang="scss" scoped>
@import "./style.css"
</style>
