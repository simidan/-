import { createRouter, createWebHashHistory, RouteRecordRaw } from 'vue-router'
import Login from '../views/LoginAndRegister/login.vue'
import IndexPage from '../views/index/index.vue'
import { checkTokenApi } from '@/api'

const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    name: 'login',
    component: Login,
    meta: { requiresAuth: false } // 明确指定登录页不需要授权
  },
  {
    path: '/index',
    name: 'index',
    component: IndexPage,
    meta: { requiresAuth: true } // 明确指定此页面需要授权
  }
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

// 添加路由守卫
router.beforeEach((to, from, next) => {
  // 检查目标路由是否需要授权
  if (to.meta.requiresAuth) {
    const token = localStorage.getItem('token');
    if (token) {
      // 存在token，继续路由
      next();
    } else {
      // 未找到token，重定向到登录页面
      next({ name: 'login' });
    }
  } else {
    // 如果路由不需要授权，直接继续
    next();
  }
});

export default router;
