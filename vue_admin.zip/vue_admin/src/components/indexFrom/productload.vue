<template>
  <div class="load">
    <el-upload
    class="avatar-uploader"
    :action="`http://127.0.0.1:9000/GAPshop/admin/productControl/avatarUpdate/${productStore.newProductId}`"
    :headers="{ 'Authorization': `Bearer ${authToken}` }"
    :show-file-list="false"
    :on-success="handleAvatarSuccess"
  >
    <img v-if="imageUrl" :src="imageUrl" class="avatar" />
    <el-icon v-else class="avatar-uploader-icon"><Plus /></el-icon>
  </el-upload>
  <p>请选择用户头像</p>
  </div>
</template>

<script lang="ts" setup>
import { onMounted, ref } from 'vue'
import { ElMessage, uploadBaseProps } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'
import type { UploadProps } from 'element-plus'
import indexProductPageStore from '@/store/idnex/productControl'

const productStore = indexProductPageStore()

const imageUrl = ref('')
const authToken = ref('')
const uploadUrl = ref('')
const fileList = ref([])

const handleAvatarSuccess: UploadProps['onSuccess'] = (
  response,
  uploadFile
) => {
  imageUrl.value = URL.createObjectURL(uploadFile.raw!)
  productStore.newProductId = 0
  productStore.mark = 0
}

const beforeAvatarUpload: UploadProps['beforeUpload'] = (rawFile) => {
  if (rawFile.type !== 'image/jpeg') {
    ElMessage.error('Avatar picture must be JPG format!')
    return false
  } else if (rawFile.size / 1024 / 1024 > 2) {
    ElMessage.error('Avatar picture size can not exceed 2MB!')
    return false
  }
  return true
}
onMounted(() => {
  authToken.value = localStorage.getItem('token') || '';
})
</script>

<style scoped>
.avatar-uploader .avatar {
  width: 178px;
  height: 178px;
  display: block;
}

.load{
  display: flex;
  flex-direction: column;
  text-align: center;
  justify-content: center;
}
p{
  margin-top: 10px;
}
</style>

<style>
.avatar-uploader .el-upload {
  border: 1px dashed var(--el-border-color);
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  transition: var(--el-transition-duration-fast);
}

.avatar-uploader .el-upload:hover {
  border-color: var(--el-color-primary);
}

.el-icon.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  text-align: center;
}
</style>
