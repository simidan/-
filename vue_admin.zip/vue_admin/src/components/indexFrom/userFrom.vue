<template>
  <el-form
    ref="form"
    style="max-width: 600px;width:50%"
    :model="sizeForm"
    label-width="auto"
    :label-position="labelPosition"
    :size="size"
    v-loading="loading"
    v-if="userStore.newUserId === 0"
  >
    <el-form-item label="用户名">
      <el-input v-model="sizeForm.username" />
    </el-form-item>
    <el-form-item label="姓名">
      <el-input v-model="sizeForm.full_name" />
    </el-form-item>
    <el-form-item label="密码" v-show="userStore.userInfo.user_id === 0">
      <el-input v-model="sizeForm.password" type="password" show-password/>
    </el-form-item>
    <el-form-item label="手机号">
      <el-input v-model="sizeForm.phone" />
    </el-form-item>
    <el-form-item label="邮箱">
      <el-input v-model="sizeForm.email" />
    </el-form-item>
    <el-form-item label="性别">
      <el-radio-group v-model="sizeForm.gender">
        <el-radio border value=0>男</el-radio>
        <el-radio border value=1>女</el-radio>
      </el-radio-group>
    </el-form-item>
    <el-form-item label="地址">
      <div v-if="changeorign === 1">
        {{ sizeForm.defaultAddress }}
        <el-button @click="changeOrign(0)">修改产地</el-button>
      </div>
      <div v-else>
        <elui-china-area-dht @change="onChange"></elui-china-area-dht>
        <el-button @click="changeOrign(1)">取消</el-button>
      </div>
      <!--带isall参数和leave参数示例-->
    </el-form-item>
    <el-form-item label="出生日期">
      <el-col :span="11">
        <el-date-picker
          v-model="sizeForm.birthday"
          type="date"
          label="Pick a date"
          placeholder="Pick a date"
          style="width: 100%"
        />
      </el-col>
    </el-form-item>
    <el-form-item class="button">
      <el-button type="primary" @click="userAdd" v-show="userStore.mark === 2">添加</el-button>
      <el-button type="primary" @click="userUpdate" v-show="userStore.mark === 4">确认</el-button>
      <el-button @click="changeMark(0)">取消</el-button>
    </el-form-item>
  </el-form>
  <userload v-else></userload>
</template>

<script lang="ts" setup>
import { onMounted, reactive, ref } from 'vue'
import indexUserPageStore from '@/store/idnex/userControl'
import { ElMessage, ElMessageBox } from 'element-plus'
import type { Action } from 'element-plus'
import { userMessageCheck } from '../../utils/messageCheck';
import dateChange from '../../utils/dateChange';
import { getData } from "@/api/lineCity";
import { EluiChinaAreaDht } from 'elui-china-area-dht'
import userload from './userload.vue'

const size = ref('large')
const labelPosition = ref('right')
const userStore = indexUserPageStore();

let loading = ref(false)

const sizeForm = reactive({
  username: '',
  password:'',
  phone:'',
  email:'',
  gender:'',
  birthday:'',
  defaultAddress:'',
  full_name:''
})
const user_id = ref(0)

function changeMark(num:number) {
  userStore.mark=num
}

async function userAdd() {
  sizeForm.birthday = dateChange(sizeForm.birthday)
  const addMessage = userMessageCheck(sizeForm)
  loading.value = true
  if(addMessage){
    loading.value = false
    return ElMessageBox.alert(addMessage.toString(), 'Title', {
      confirmButtonText: 'OK',
      callback: (action: Action) => {
        ElMessage({
          type: 'info',
          message: `action: ${action}`,
        });
      },
    });
  }else{
    const res = await userStore.userAdd(sizeForm)
    if(res.statusCode!== 200){
      loading.value = false
      return ElMessageBox.alert(res.message, 'Title', {
        confirmButtonText: 'OK',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `action: ${action}`,
          });
        },
      });
    }else{
      userStore.newUserId = res.data[0].user_id;
      ElMessageBox.alert(res.message, 'Title', {
        confirmButtonText: 'OK',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `action: ${action}`,
          });
        },
      });
      for (let key in sizeForm) {
        if (sizeForm.hasOwnProperty(key)) {
          // 通过类型断言绕过类型检查
          (sizeForm as any)[key] = '';
        }
      }
      loading.value = false
    }
    // console.log(sizeForm);
  }
}

async function userUpdate(){
  sizeForm.birthday = dateChange(sizeForm.birthday)
  const addMessage = userMessageCheck(sizeForm,0)
  
  loading.value = true
  if(addMessage){
    loading.value = false
    return ElMessageBox.alert(addMessage.toString(), 'Title', {
      confirmButtonText: 'OK',
      callback: (action: Action) => {
        ElMessage({
          type: 'info',
          message: `action: ${action}`,
        });
      },
    });
  }else{
    user_id.value = userStore.userInfo.user_id
    const res = await userStore.userUpdate(user_id.value,sizeForm)
    if(res === '您没有权限' || res==='请输入长度在6到15位之间的密码'|| res ==='请求失败'){
      loading.value = false
      return ElMessageBox.alert(res, 'Title', {
        confirmButtonText: 'OK',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `action: ${action}`,
          });
        },
      });
    }else{
      ElMessageBox.alert(res.message, 'Title', {
        confirmButtonText: 'OK',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `action: ${action}`,
          });
        },
      });
      setTimeout(()=>{
        userStore.mark = 0
      loading.value = false
      },100)
    }
    // console.log(sizeForm);
  }
}



const chinaData = new EluiChinaAreaDht.ChinaArea().chinaAreaflat
 
// 覆盖区县
const onChange = (e:any) => {
    const province = chinaData[e[0]]
    const city = chinaData[e[1]]
    const area = chinaData[e[2]]
    const adress =`${province.label}-${city.label}-${area.label}`
    sizeForm.defaultAddress = adress
}

const changeorign =ref(0)

const changeOrign=(num:number)=>{
  changeorign.value = num
}

onMounted(()=>{
  if(userStore.mark === 4){
    for (let key in sizeForm) {
        if (sizeForm.hasOwnProperty(key)) {
          // 通过类型断言绕过类型检查
          (sizeForm as any)[key] = (userStore.userInfo as any)[key]
        }
      }
      changeorign.value = 1
  }
})
</script>

<style>
.el-radio-group {
  margin-right: 12px;
}

.button{
  float: right;
}
</style>
