<template>
  <el-form
    ref="form"
    style="max-width: 600px;width:50%"
    :model="sizeForm"
    label-width="auto"
    :label-position="labelPosition"
    :size="size"
    v-loading="loading"
  >
    <el-form-item label="姓名">
      <el-input v-model="sizeForm.username" />
    </el-form-item>
    <el-form-item label="密码">
      <el-input v-model="sizeForm.password" type="password" show-password/>
    </el-form-item>
    <el-form-item label="手机号">
      <el-input v-model="sizeForm.phone" />
    </el-form-item>
    <el-form-item label="邮箱">
      <el-input v-model="sizeForm.email" />
    </el-form-item>
    <el-form-item label="性别">
      <el-radio-group v-model="sizeForm.gender">
        <el-radio border value=0>男</el-radio>
        <el-radio border value=1>女</el-radio>
      </el-radio-group>
    </el-form-item>
    <el-form-item label="权限">
      <el-select
        v-model="sizeForm.role"
        placeholder="请选择权限">
        <el-option
          v-for="item in options"
          :key="item.value"
          :label="item.label"
          :value="item.value"/>
      </el-select>
    </el-form-item>
    <el-form-item label="出生日期">
      <el-col :span="11">
        <el-date-picker
          v-model="sizeForm.birthday"
          type="date"
          label="Pick a date"
          placeholder="Pick a date"
          style="width: 100%"
        />
      </el-col>
    </el-form-item>
    <el-form-item class="button">
      <el-button type="primary" @click="adminAdd" v-show="roleStore.mark === 2">添加</el-button>
      <el-button type="primary" @click="adminUpdate" v-show="roleStore.mark === 4">确认</el-button>
      <el-button @click="changeMark(0)">取消</el-button>
    </el-form-item>
  </el-form>
</template>

<script lang="ts" setup>
import { onMounted, reactive, ref } from 'vue'
import indexRolePageStore from '@/store/idnex/adminControl';
import { ElMessage, ElMessageBox } from 'element-plus'
import type { Action } from 'element-plus'
import { adminMessageCheck } from '../../utils/messageCheck';
import dateChange from '../../utils/dateChange';

const size = ref('large')
const labelPosition = ref('right')
const roleStore = indexRolePageStore();

let loading = ref(false)

const sizeForm = reactive({
  username: '',
  password:'',
  phone:'',
  email:'',
  gender:'',
  role:'',
  birthday:''
})
const admin_id = ref(0)

const options = [
  {
    value: 'superAdmin',
    label: '超级管理员',
  },
  {
    value: 'userAdmin',
    label: '用户管理员',
  },
  {
    value: 'productAdmin',
    label: '产品管理员',
  },
  {
    value: 'businessAdmin',
    label: '商家管理员',
  },
  {
    value: 'orderAdmin',
    label: '订单管理员',
  },
]

function changeMark(num:number) {
  roleStore.mark=num
}

async function adminAdd() {
  sizeForm.birthday = dateChange(sizeForm.birthday)
  const addMessage = adminMessageCheck(sizeForm)
  loading.value = true
  if(addMessage){
    loading.value = false
    return ElMessageBox.alert(addMessage.toString(), 'Title', {
      confirmButtonText: 'OK',
      callback: (action: Action) => {
        ElMessage({
          type: 'info',
          message: `action: ${action}`,
        });
      },
    });
  }else{
    const res = await roleStore.roleAdd(sizeForm)
    if(res === '您没有权限' || res==='账号已存在'|| res ==='新管理员添加失败'){
      loading.value = false
      return ElMessageBox.alert(res, 'Title', {
        confirmButtonText: 'OK',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `action: ${action}`,
          });
        },
      });
    }else{
      ElMessageBox.alert(res.message, 'Title', {
        confirmButtonText: 'OK',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `action: ${action}`,
          });
        },
      });
      for (let key in sizeForm) {
        if (sizeForm.hasOwnProperty(key)) {
          // 通过类型断言绕过类型检查
          (sizeForm as any)[key] = '';
        }
      }
      loading.value = false
    }
    // console.log(sizeForm);
  }
}

async function adminUpdate(){
  sizeForm.birthday = dateChange(sizeForm.birthday)
  const addMessage = adminMessageCheck(sizeForm)
  loading.value = true
  if(addMessage){
    loading.value = false
    return ElMessageBox.alert(addMessage.toString(), 'Title', {
      confirmButtonText: 'OK',
      callback: (action: Action) => {
        ElMessage({
          type: 'info',
          message: `action: ${action}`,
        });
      },
    });
  }else{
    admin_id.value = roleStore.userInfo.admin_id
    const res = await roleStore.roleUpdate(admin_id.value,sizeForm)
    if(res === '您没有权限' || res==='请输入长度在6到15位之间的密码'|| res ==='请求失败'){
      loading.value = false
      return ElMessageBox.alert(res, 'Title', {
        confirmButtonText: 'OK',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `action: ${action}`,
          });
        },
      });
    }else{
      ElMessageBox.alert(res.message, 'Title', {
        confirmButtonText: 'OK',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `action: ${action}`,
          });
        },
      });
      roleStore.mark = 0
      loading.value = false
    }
    // console.log(sizeForm);
  }
}

onMounted(()=>{
  if(roleStore.mark === 4){
    for (let key in sizeForm) {
        if (sizeForm.hasOwnProperty(key)) {
          // 通过类型断言绕过类型检查
          (sizeForm as any)[key] = (roleStore.userInfo as any)[key]
        }
      }
  }
})
</script>

<style>
.el-radio-group {
  margin-right: 12px;
}

.button{
  float: right;
}
</style>
