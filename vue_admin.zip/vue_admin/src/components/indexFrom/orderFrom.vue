<template>
  <el-form
    ref="form"
    style="max-width: 600px;width:50%"
    :model="sizeForm"
    label-width="auto"
    :label-position="labelPosition"
    :size="size"
    v-loading="loading"
  >
    <el-form-item label="用户ID">
      <el-input v-model.number="sizeForm.user_id" />
    </el-form-item>
    <el-form-item label="商家ID"  v-if="orderStore.mark!==2">
      <el-input v-model.number="sizeForm.business_id" />
    </el-form-item>
    <el-form-item label="商品ID">
      <el-input v-model.number="sizeForm.product_id" />
    </el-form-item>
    <el-form-item label="数量">
      <el-input v-model.number="sizeForm.quantity" />
    </el-form-item>
    <el-form-item label="总金额" v-if="orderStore.mark!==2">
      <el-input v-model.number="sizeForm.total_amount" />
    </el-form-item>
    <el-form-item label="订单状态">
      <el-select
        v-model="sizeForm.status"
        placeholder="请选择订单状态">
        <el-option
          v-for="item in statusMap"
          :key="item.value"
          :label="item.label"
          :value="item.value"/>
      </el-select>
    </el-form-item>
    <el-form-item label="支付方式">
      <el-select
        v-model="sizeForm.payment_method"
        placeholder="请选择支付方式">
        <el-option
          v-for="item in paymentMethodMap"
          :key="item.value"
          :label="item.label"
          :value="item.value"/>
      </el-select>
    </el-form-item>
    <el-form-item label="支付状态">
      <el-select
        v-model="sizeForm.payment_status"
        placeholder="请选择支付状态">
        <el-option
          v-for="item in paymentStatusMap"
          :key="item.value"
          :label="item.label"
          :value="item.value"/>
      </el-select>
    </el-form-item>
    <el-form-item label="用户名" v-if="orderStore.mark!==2">
      <el-input v-model="sizeForm.shipping_name" />
    </el-form-item>
    <el-form-item label="电话" v-if="orderStore.mark!==2">
      <el-input v-model="sizeForm.shipping_phone" />
    </el-form-item>
    <el-form-item label="收货地址">
      <div v-if="changeorign === 1">
        {{ sizeForm.shipping_address }}
        <el-button @click="changeOrign(0)">修改收货地址</el-button>
      </div>
      <div v-else>
        <elui-china-area-dht @change="onChange"></elui-china-area-dht>
        <el-button @click="changeOrign(1)" v-show="orderStore.mark!==2">取消</el-button>
      </div>
      <!--带isall参数和leave参数示例-->
    </el-form-item>
    <el-form-item class="button">
      <el-button type="primary" @click="adminAdd" v-show="orderStore.mark === 2">添加</el-button>
      <el-button type="primary" @click="adminUpdate" v-show="orderStore.mark === 4">确认</el-button>
      <el-button @click="changeMark(0)">取消</el-button>
    </el-form-item>
  </el-form>
</template>

<script lang="ts" setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import type { Action } from 'element-plus'
import dateChange from '../../utils/dateChange';
import indexOrderPageStore from '@/store/idnex/orderStore'
import { EluiChinaAreaDht } from 'elui-china-area-dht'
import { orderMessage } from '@/utils/interface';
import { checkAddOrderFormData, checkUpdateOrderFormData } from '@/utils/messageCheck';

const size = ref('large')
const labelPosition = ref('right')
const orderStore = indexOrderPageStore();

let loading = ref(false)

const sizeForm = reactive({
  order_id:0,
  user_id: 0,
  business_id: 0,
  product_id: 0,
  quantity: 0,
  total_amount: 0,
  status: '',
  payment_method: '',
  payment_status: '',
  shipping_name: '',
  shipping_phone: '',
  shipping_address: ''
})
const order_id = ref(0)

const statusMap = [
  { value: 'pending', label: '待处理' },
  { value: 'paid', label: '已支付' },
  { value: 'shipped', label: '已发货' },
  { value: 'completed', label: '已完成' },
  { value: 'cancelled', label: '已取消' }
];

const paymentMethodMap = [
  { value: 'credit_card', label: '信用卡' },
  { value: 'alipay', label: '支付宝' },
  { value: 'wechat', label: '微信支付' },
  { value: 'paypal', label: 'PayPal' }
];

const paymentStatusMap = [
  { value: 'unpaid', label: '未支付' },
  { value: 'success', label: '成功' },
  { value: 'failed', label: '失败' }
];

function changeMark(num:number) {
  orderStore.mark=num
}
interface addOrderMessage extends Omit<orderMessage, 'total_amount' | 'shipping_name' | 'shipping_phone'> {}
async function adminAdd() {
  const formData: any = { ...sizeForm };
  delete formData.business_id
  delete formData.total_amount;
  delete formData.shipping_name;
  delete formData.shipping_phone;
  delete formData.order_id
  const addMessage = checkAddOrderFormData(formData)
  loading.value = true
  if(addMessage){
    loading.value = false
    return ElMessageBox.alert(addMessage.toString(), 'Title', {
      confirmButtonText: 'OK',
      callback: (action: Action) => {
        ElMessage({
          type: 'info',
          message: `action: ${action}`,
        });
      },
    });
  }
  else{
    const res = await orderStore.orderAdd(formData)
    if(res === '您没有权限' || res==='账号已存在'|| res ==='新管理员添加失败'){
      loading.value = false
      return ElMessageBox.alert(res, 'Title', {
        confirmButtonText: 'OK',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `action: ${action}`,
          });
        },
      });
    }else{
      ElMessageBox.alert(res.message, 'Title', {
        confirmButtonText: 'OK',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `action: ${action}`,
          });
        },
      });
      for (let key in sizeForm) {
        if (sizeForm.hasOwnProperty(key)) {
          // 通过类型断言绕过类型检查
          (sizeForm as any)[key] = '';
        }
      }
      orderStore.mark = 0
      loading.value = false
    }
  }
}

async function adminUpdate(){
  const addMessage = checkUpdateOrderFormData(sizeForm)
  loading.value = true
  if(addMessage){
    loading.value = false
    return ElMessageBox.alert(addMessage.toString(), 'Title', {
      confirmButtonText: 'OK',
      callback: (action: Action) => {
        ElMessage({
          type: 'info',
          message: `action: ${action}`,
        });
      },
    });
  }else{
    order_id.value = orderStore.orderInfo.order_id
    const res = await orderStore.orderUpdate(order_id.value,sizeForm)
    if(res === '您没有权限' || res==='请输入长度在6到15位之间的密码'|| res ==='请求失败'){
      loading.value = false
      return ElMessageBox.alert(res, 'Title', {
        confirmButtonText: 'OK',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `action: ${action}`,
          });
        },
      });
    }else{
      ElMessageBox.alert(res.message, 'Title', {
        confirmButtonText: 'OK',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `action: ${action}`,
          });
        },
      });
      orderStore.mark = 0
      loading.value = false
    }
    // console.log(sizeForm);
  }
}

const chinaData = new EluiChinaAreaDht.ChinaArea().chinaAreaflat

const onChange = (e:any) => {
    const province = chinaData[e[0]]
    const city = chinaData[e[1]]
    const area = chinaData[e[2]]
    const adress =`${province.label}-${city.label}-${area.label}`
    sizeForm.shipping_address = adress
}

const changeorign =ref(0)

const changeOrign=(num:number)=>{
  changeorign.value = num
}

onMounted(()=>{
  if(orderStore.mark === 4){
    for (let key in sizeForm) {
        if (sizeForm.hasOwnProperty(key)) {
          // 通过类型断言绕过类型检查
          (sizeForm as any)[key] = (orderStore.orderInfo as any)[key]
        }
      }
      changeorign.value = 1
  }
})
</script>

<style>
.el-radio-group {
  margin-right: 12px;
}

.button{
  float: right;
}
</style>

function indexOrderPageStore() {
  throw new Error('Function not implemented.');
}
