<template>
  <el-form
    ref="form"
    style="max-width: 800px;width:100%"
    :model="sizeForm"
    label-width="auto"
    :label-position="labelPosition"
    :size="size"
    v-loading="loading"
    v-if="productStore.newProductId === 0"
  >
    <el-form-item label="商品名">
      <el-input v-model="sizeForm.name" />
    </el-form-item>
    <el-form-item label="类别">
      <el-select v-model.number="sizeForm.sub_category_id" placeholder="please select your zone">
        <el-option label="蔬菜" value='1' />
        <el-option label="水果" value="2" />
        <el-option label="肉类" value='3' />
        <el-option label="谷物" value="4" />
        <el-option label="食用油" value='5' />
        <el-option label="冷冻肉类" value="6" />
        <el-option label="干果坚果" value="7" />
      </el-select>
    </el-form-item>
    <el-form-item label="商家ID">
      <el-input v-model.number="sizeForm.business_id" />
    </el-form-item>
    <el-form-item label="价格">
      <el-input v-model.number="sizeForm.price" />
    </el-form-item>
    <el-form-item label="库存">
      <el-input v-model.number="sizeForm.stock_quantity" />
    </el-form-item>
    <el-form-item label="单位">
      <el-input v-model="sizeForm.unit" />
    </el-form-item>
    <el-form-item label="描述">
      <el-input v-model="sizeForm.description" />
    </el-form-item>
    <el-form-item label="产地">
      <div v-if="changeorign === 1">
        {{ sizeForm.origin }}
        <el-button @click="changeOrign(0)">修改产地</el-button>
      </div>
      <div v-else>
        <elui-china-area-dht @change="onChange" v-model="sizeForm.origin"></elui-china-area-dht>
        <el-button @click="changeOrign(1)">取消</el-button>
      </div>
      <!--带isall参数和leave参数示例-->
    </el-form-item>
    <el-form-item label="采收日">
      <el-col :span="11">
        <el-date-picker
          v-model="sizeForm.harvest_date"
          type="date"
          placeholder="Pick a date"
          style="width: 100%"
        />
      </el-col>
    </el-form-item>
    <el-form-item label="保质期（单位：天）">
      <el-input v-model.number="sizeForm.shelf_life" />
    </el-form-item>
    <el-form-item label="认证">
      <el-input v-model="sizeForm.certification" />
    </el-form-item>
    <el-form-item label="适销季">
      <el-input v-model="sizeForm.season" />
    </el-form-item>
    <el-form-item label="安全标准">
      <el-input v-model="sizeForm.safety_standards" />
    </el-form-item>
    <el-form-item label="存储条件">
      <el-input v-model="sizeForm.storage_conditions" />
    </el-form-item>
    <el-form-item label="等级">
      <el-select v-model="sizeForm.grade" placeholder="please select your zone">
        <el-option label="特级" value='特级' />
        <el-option label="一级" value="一级" />
        <el-option label="二级" value='二级' />
        <el-option label="三级" value="三级" />
        <el-option label="未评定" value='未评定' />
      </el-select>
    </el-form-item>
    <el-form-item class="button">
      <el-button type="primary" @click="productAdd" v-show="productStore.mark === 2">添加</el-button>
      <el-button type="primary" @click="productUpdate" v-show="productStore.mark === 4">确认</el-button>
      <el-button @click="changeMark(0)">取消</el-button>
    </el-form-item>
  </el-form>
  <productload v-else></productload>
</template>

<script lang="ts" setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import type { Action } from 'element-plus'
import { businessMessageCheck, productMessageCheck, userMessageCheck } from '../../utils/messageCheck';
import dateChange from '../../utils/dateChange';
import { getData } from "@/api/lineCity";
import { EluiChinaAreaDht } from 'elui-china-area-dht'
import productload from './productload.vue'
import indexProductPageStore from '@/store/idnex/productControl'

const size = ref('large')
const labelPosition = ref('right')
const productStore = indexProductPageStore();

let loading = ref(false)

const sizeForm = reactive({
  sub_category_id: 0,
  business_id: 0,
  name: '',
  price: 0,
  unit: '',
  stock_quantity: 0,
  description: '',
  origin: '',
  harvest_date: '',
  shelf_life: 0,
  certification: '',
  season: '',
  safety_standards: '',
  storage_conditions: '',
  grade: ''
})

const product_id = ref(0)

function changeMark(num:number) {
  productStore.mark=num
}

async function productAdd() {
  sizeForm.harvest_date = dateChange(sizeForm.harvest_date)
  const addMessage = productMessageCheck(sizeForm)
  // loading.value = true
  if(addMessage){
    loading.value = false
    return ElMessageBox.alert(addMessage.toString(), 'Title', {
      confirmButtonText: 'OK',
      callback: (action: Action) => {
        ElMessage({
          type: 'info',
          message: `action: ${action}`,
        });
      },
    });
  }
  else{
    const res = await productStore.productAdd(sizeForm)
    if(res.statusCode!== 200){
      loading.value = false
      return ElMessageBox.alert(res.message, 'Title', {
        confirmButtonText: 'OK',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `action: ${action}`,
          });
        },
      });
    }else{
      productStore.newProductId = res.data
      ElMessageBox.alert(res.message, 'Title', {
        confirmButtonText: 'OK',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `action: ${action}`,
          });
        },
      });
      for (let key in sizeForm) {
        if (sizeForm.hasOwnProperty(key)) {
          // 通过类型断言绕过类型检查
          (sizeForm as any)[key] = '';
        }
      }
      loading.value = false
    }
    // console.log(sizeForm);
  }
}

async function productUpdate(){
  const addMessage = productMessageCheck(sizeForm)
  loading.value = true
  if(addMessage){
    loading.value = false
    return ElMessageBox.alert(addMessage.toString(), 'Title', {
      confirmButtonText: 'OK',
      callback: (action: Action) => {
        ElMessage({
          type: 'info',
          message: `action: ${action}`,
        });
      },
    });
  }else{
    product_id.value = productStore.productInfo.product_id
    const res = await productStore.productUpdate(product_id.value,sizeForm)
    if(res === '您没有权限' || res==='请输入长度在6到15位之间的密码'|| res ==='请求失败'){
      loading.value = false
      return ElMessageBox.alert(res, 'Title', {
        confirmButtonText: 'OK',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `action: ${action}`,
          });
        },
      });
    }else{
      ElMessageBox.alert(res.message, 'Title', {
        confirmButtonText: 'OK',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `action: ${action}`,
          });
        },
      });
      setTimeout(()=>{
        productStore.mark = 0
      loading.value = false
      },100)
    }
    // console.log(sizeForm);
  }
}

const chinaData = new EluiChinaAreaDht.ChinaArea().chinaAreaflat
 
// 覆盖区县

const onChange = (e:any) => {
    const province = chinaData[e[0]]
    console.log(e);
    
    const city = chinaData[e[1]]
    const area = chinaData[e[2]]
    const adress =`${province.label}-${city.label}-${area.label}`
    sizeForm.origin = adress
}

const changeorign =ref(0)

const changeOrign=(num:number)=>{
  changeorign.value = num
}

onMounted(()=>{
  if(productStore.mark === 4){
    for (let key in sizeForm) {
      if (sizeForm.hasOwnProperty(key)) {
        // 通过类型断言绕过类型检查
        (sizeForm as any)[key] = (productStore.productInfo as any)[key]
      }
    }
    changeorign.value = 1
  }
})
</script>

<style>
.el-radio-group {
  margin-right: 12px;
}

.button{
  float: right;
}
</style>
