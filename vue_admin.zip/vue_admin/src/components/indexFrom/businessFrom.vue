<template>
  <el-form
    ref="form"
    style="max-width: 600px;width:50%"
    :model="sizeForm"
    label-width="auto"
    :label-position="labelPosition"
    :size="size"
    v-loading="loading"
    v-if="businessStore.newBusinessId === 0"
  >
    <el-form-item label="商家名">
      <el-input v-model="sizeForm.businessName" />
    </el-form-item>
    <el-form-item label="密码" v-show="businessStore.businessInfo.business_id === 0">
      <el-input v-model="sizeForm.password" type="password" show-password/>
    </el-form-item>
    <el-form-item label="手机号">
      <el-input v-model="sizeForm.phone" />
    </el-form-item>
    <el-form-item label="邮箱">
      <el-input v-model="sizeForm.email" />
    </el-form-item>
    <el-form-item label="地址">
      <div v-if="changeorign === 1">
        {{ sizeForm.address }}
        <el-button @click="changeOrign(0)">修改产地</el-button>
      </div>
      <div v-else>
        <elui-china-area-dht @change="onChange"></elui-china-area-dht>
        <el-button @click="changeOrign(1)">取消</el-button>
      </div>
      <!--带isall参数和leave参数示例-->
    </el-form-item>
    <el-form-item class="button">
      <el-button type="primary" @click="businessAdd" v-show="businessStore.mark === 2">添加</el-button>
      <el-button type="primary" @click="businessUpdate" v-show="businessStore.mark === 4">确认</el-button>
      <el-button @click="changeMark(0)">取消</el-button>
    </el-form-item>
  </el-form>
  <businessload v-else></businessload>
</template>

<script lang="ts" setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import type { Action } from 'element-plus'
import { businessMessageCheck, userMessageCheck } from '../../utils/messageCheck';
import dateChange from '../../utils/dateChange';
import { getData } from "@/api/lineCity";
import { EluiChinaAreaDht } from 'elui-china-area-dht'
import businessload from './businessload.vue'
import indexBusinessPageStore from '@/store/idnex/businessControl';

const size = ref('large')
const labelPosition = ref('right')
const businessStore = indexBusinessPageStore();

let loading = ref(false)

const sizeForm = reactive({
  businessName:'',
  phone: '',
  email:'',
  address:'',
  password:'',
})
const business_id = ref(0)

function changeMark(num:number) {
  businessStore.mark=num
}

async function businessAdd() {
  console.log(sizeForm);
  const addMessage = businessMessageCheck(sizeForm,0)
  console.log(addMessage);
  
  loading.value = true
  if(addMessage){
    loading.value = false
    return ElMessageBox.alert(addMessage.toString(), 'Title', {
      confirmButtonText: 'OK',
      callback: (action: Action) => {
        ElMessage({
          type: 'info',
          message: `action: ${action}`,
        });
      },
    });
  }else{
    const res = await businessStore.businessAdd(sizeForm)
    businessStore.newBusinessId = res.data[0].user_id;
    if(res.statusCode!== 200){
      loading.value = false
      return ElMessageBox.alert(res.message, 'Title', {
        confirmButtonText: 'OK',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `action: ${action}`,
          });
        },
      });
    }else{
      businessStore.newBusinessId = res.data[0].business_id;
      ElMessageBox.alert(res.message, 'Title', {
        confirmButtonText: 'OK',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `action: ${action}`,
          });
        },
      });
      for (let key in sizeForm) {
        if (sizeForm.hasOwnProperty(key)) {
          (sizeForm as any)[key] = '';
        }
      }
      businessStore.mark = 0
      loading.value = false
    }
  }
}

async function businessUpdate(){
  const addMessage = businessMessageCheck(sizeForm,0)
  
  console.log(sizeForm);
  
  loading.value = true
  if(addMessage){
    loading.value = false
    return ElMessageBox.alert(addMessage.toString(), 'Title', {
      confirmButtonText: 'OK',
      callback: (action: Action) => {
        ElMessage({
          type: 'info',
          message: `action: ${action}`,
        });
      },
    });
  }else{
    business_id.value = businessStore.businessInfo.business_id
    const res = await businessStore.businessUpdate(business_id.value,sizeForm)
    if(res === '您没有权限' || res==='请输入长度在6到15位之间的密码'|| res ==='请求失败'){
      loading.value = false
      return ElMessageBox.alert(res, 'Title', {
        confirmButtonText: 'OK',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `action: ${action}`,
          });
        },
      });
    }else{
      ElMessageBox.alert(res.message, 'Title', {
        confirmButtonText: 'OK',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `action: ${action}`,
          });
        },
      });
      setTimeout(()=>{
        businessStore.mark = 0
      loading.value = false
      },100)
    }
    // console.log(sizeForm);
  }
}

const chinaData = new EluiChinaAreaDht.ChinaArea().chinaAreaflat
 
// 覆盖区县
const onChange = (e:any) => {
    const province = chinaData[e[0]]
    const city = chinaData[e[1]]
    const area = chinaData[e[2]]
    const adress =`${province.label}-${city.label}-${area.label}`
    sizeForm.address = adress   
}

const changeorign =ref(0)

const changeOrign=(num:number)=>{
  changeorign.value = num
}

onMounted(()=>{
  if(businessStore.mark === 4){
    for (let key in sizeForm) {
        if (sizeForm.hasOwnProperty(key)) {
          // 通过类型断言绕过类型检查
          (sizeForm as any)[key] = (businessStore.businessInfo as any)[key]
        }
      }
      changeorign.value = 1
  }
})
</script>

<style>
.el-radio-group {
  margin-right: 12px;
}

.button{
  float: right;
}
</style>
