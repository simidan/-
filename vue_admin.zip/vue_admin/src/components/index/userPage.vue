<template>
  <div class="common-layout page">
    <el-container class="ct">
      <el-header class="header">
        <div class="search">
          <el-input v-model="searchKey" style="width: 70%;height:75%" placeholder="Please input"/>
          <el-button plain size="large" @click="userSearch">搜索</el-button>
        </div>
        <div :class="userStore.mark === 0 || userStore.mark === 3? 'button':'buttonChange'">
          <el-button plain size="large" type="success" style="width: 100px;height:75%" @click="changeMark(2)">添加</el-button>
          <el-button plain size="large" type="success" style="width: 100px;height:75%" v-if="userStore.mark === 1||userStore.mark === 3 || userStore.mark === 2" @click="backShow">返回</el-button>
        </div>
      </el-header>
      <el-main class="main" v-loading="loading" v-if="userStore.mark ===0 || userStore.mark===1 ||userStore.mark===3">
        <el-scrollbar height="100%">
          <div v-for="item in userList" :key="item.admin_id" class="admin">
            <el-descriptions :column="3" border>
              <el-descriptions-item
                label="姓名"
                label-align="right"
                align="center"
                label-class-name="my-label"
                class-name="my-content"
                width="150px"
                >{{item.username}}</el-descriptions-item
              >
              <el-descriptions-item label="性别" label-align="right" align="center">
                {{ item.gender==='0'?'男':'女' }}
              </el-descriptions-item>
              <el-descriptions-item label="电话" label-align="right" align="center"
                >{{item.phone}}</el-descriptions-item
              >
              <el-descriptions-item label="真实姓名" label-align="right" align="center">
                {{item.full_name}}
              </el-descriptions-item>
              <el-descriptions-item label="出生日期" label-align="right" align="center">
                {{ item.birthday }}
              </el-descriptions-item>
              <el-descriptions-item label="邮件" label-align="right" align="center"
                >{{item.email}}
                </el-descriptions-item>
                <el-descriptions-item label="默认地址" label-align="right" align="center"
                >{{item.default_address}}
                </el-descriptions-item>
                <el-descriptions-item label="头像" label-align="right" align="center"
                >
                  <img crossorigin="anonymous" :src='item.avatar' alt="" class="image" v-if="item.avatar">
                </el-descriptions-item>
            </el-descriptions>
            <el-button plain size="large" type="primary" style="width: 10%;height:20%" class="buttonOne" @click="changeMark(4),userUpdate(item)">修改信息</el-button>
            <el-button plain size="large" type="primary" style="width: 10%;height:20%" class="buttonTwo" v-show="item.status ===1" @click="userStatus(item,0)">禁用</el-button>
            <el-button plain size="large" type="primary" style="width: 10%;height:20%" class="buttonTwo" v-show="item.status ===0" @click="userStatus(item,1)">解除禁用</el-button>
            <el-button plain size="large" type="primary" style="width: 10%; height:20%" class="buttonTwo" @click="userAvater(item.user_id)">修改头像</el-button>
            <el-button plain size="large" type="danger" style="width: 10%;height:20%" class="buttonTwo" @click="userDelete(item.user_id)">删除</el-button>
          </div>
        </el-scrollbar>
      </el-main>
      <div v-else class="from">
        <userFrom></userFrom>
      </div>
      <el-pagination
          small
          background
          @current-change="handleCurrentChange"
          :current-page="pagelimit.page"
          layout="prev, pager, next"
          :total="totalPages"
          class="mt-4"
          v-if="userStore.mark ===0 || userStore.mark===1 ||userStore.mark === 3"
        />
    </el-container>
  </div>
</template>

<script lang="ts" setup>
import { onBeforeMount, onMounted, reactive, ref } from 'vue';
import indexUserPageStore from '@/store/idnex/userControl'
import { ElMessage, ElMessageBox } from 'element-plus'
import type { Action } from 'element-plus'
import { userMessage } from '../../utils/interface';
import userFrom from '../indexFrom/userFrom.vue'
import { watch } from 'vue';

interface UserData {
  user_id: number;
  birthday: string;
  created_at: string;
  email: string;
  gender: string;
  password: string;
  phone: string;
  status: number;
  updated_at: string;
  username: string;
}

const userStore = indexUserPageStore()

const loading = ref(true)
const searchKey = ref<string>('');
const pagelimit = reactive({
  'limit': 10,
  'page': 1
}); // 当前页码
let totalPages = ref(10)

const userList = reactive<UserData[]>([]); // 声明为 UserData 类型的数组

const changeMark = (num:number)=>{
  userStore.newUserId = 0
  userStore.mark = num
}

const backShow = async () =>{
  userStore.mark = 0
  pagelimit.page = 1
  loading.value = true
  const res = await userStore.userShow(pagelimit); // 确保这里是数组
  totalPages.value = res.pagination.totalPages * 10
  const result: UserData[] = res.data
  userList.splice(0, userList.length, ...result); // 清空数组并插入新数据
  searchKey.value = ''
  loading.value = false
}

const handleCurrentChange = async(newPage:number) => {
  pagelimit.page = newPage
  loading.value = true
  
  if(userStore.mark === 0){
    const res = await userStore.userShow(pagelimit);
    const result: UserData[] = res.data
    totalPages.value = res.pagination.totalPages * 10
    userList.splice(0, userList.length, ...result);
    loading.value = false
  }
  else if(userStore.mark === 1){
    let combined = reactive({
      searchKey: searchKey.value,
      ...pagelimit
    });
    const res = await userStore.userSearch(combined)
    const result: UserData[] = res.data
    totalPages.value = res.pagination.totalPages * 10
    userList.splice(0, userList.length, ...result);
    loading.value = false
  }
};

const userSearch = async()=>{
  if(searchKey.value === ''){
    return ElMessageBox.alert('关键词不能为空', 'Title', {
            confirmButtonText: 'OK',
            callback: (action: Action) => {
              ElMessage({
                type: 'info',
                message: `action: ${action}`,
              });
            },
          });
  }
  pagelimit.page = 1
  let combined = reactive({
    searchKey: searchKey.value,
    ...pagelimit
  });
  loading.value = true
  const res = await userStore.userSearch(combined)
  if(res === '您没有权限' || res === '没有找到匹配的管理员' || res === '请求失败'){
    ElMessageBox.alert(res, 'Title', {
            confirmButtonText: 'OK',
            callback: (action: Action) => {
              ElMessage({
                type: 'info',
                message: `action: ${action}`,
              });
            },
          });
          loading.value = false
  }else{
    const result: UserData[] = res.data
    totalPages.value = res.pagination.totalPages * 10
    userList.splice(0, userList.length, ...result);
    userStore.mark = 1
    loading.value = false
  }
}
interface addUserMessage extends Omit<userMessage, 'avatar'>{
  user_id:number
}
const userUpdate = async(userInfo:addUserMessage)=>{
  userStore.newUserId = 0
  userStore.userInfo.user_id = userInfo.user_id;
  userStore.userInfo.username = userInfo.username;
  userStore.userInfo.email = userInfo.email;
  userStore.userInfo.phone = userInfo.phone;
  userStore.userInfo.full_name = userInfo.full_name;
  userStore.userInfo.gender = userInfo.gender;
  userStore.userInfo.birthday = userInfo.birthday;
  userStore.userInfo.defaultAddress = userInfo.defaultAddress;
}

const userStatus = async(info:addUserMessage,status:number)=>{
  loading.value = true
  const res = await userStore.userStatus(info.user_id, status)
  if(res === '您没有权限' || res === '审核通过失败' || res === '管理员禁用失败' || res === '请求失败'){
    ElMessageBox.alert(res, 'Title', {
            confirmButtonText: 'OK',
            callback: (action: Action) => {
              ElMessage({
                type: 'info',
                message: `action: ${action}`,
              });
            },
          });
          loading.value = false
  }else{
    ElMessageBox.alert(res.message, 'Title', {
            confirmButtonText: 'OK',
            callback: (action: Action) => {
              ElMessage({
                type: 'info',
                message: `action: ${action}`,
              });
            },
          });
    setTimeout(async() => {
    const res = await userStore.userShow(pagelimit); // 确保这里是数组
    totalPages.value = res.pagination.totalPages * 10
    const result: UserData[] = res.data
    userList.splice(0, userList.length, ...result); // 清空数组并插入新数据
    loading.value = false
  }, 1000);
  }
}

const userAvater = async(userId:number)=>{
  userStore.newUserId = userId
  userStore.mark = 2
}

const userDelete = async (id:number)=>{
  loading.value = true
  const res = await userStore.userDelete(id)
  if(res === '您没有权限' || res === '管理员删除失败' || res === '请求失败'){
    ElMessageBox.alert(res, 'Title', {
            confirmButtonText: 'OK',
            callback: (action: Action) => {
              ElMessage({
                type: 'info',
                message: `action: ${action}`,
              });
            },
          });
          loading.value = false
  }else{
    ElMessageBox.alert(res.message, 'Title', {
            confirmButtonText: 'OK',
            callback: (action: Action) => {
              ElMessage({
                type: 'info',
                message: `action: ${action}`,
              });
            },
          });
    setTimeout(async() => {
    const res = await userStore.userShow(pagelimit); // 确保这里是数组
    totalPages.value = res.pagination.totalPages * 10
    const result: UserData[] = res.data
    userList.splice(0, userList.length, ...result); // 清空数组并插入新数据
    loading.value = false
  }, 1000);
  }
}

watch(() => userStore.mark, async(newValue, oldValue) => {
  loading.value = true
  if(newValue === 0){
    userStore.userInfo.user_id = 0
  }
  setTimeout(async() => {
    const res = await userStore.userShow(pagelimit); // 确保这里是数组
    totalPages.value = res.pagination.totalPages * 10
    const result: UserData[] = res.data
    userList.splice(0, userList.length, ...result); // 清空数组并插入新数据
    loading.value = false
  }, 1000);
});

onMounted( () => {
  setTimeout(async() => {
    const res = await userStore.userShow(pagelimit); // 确保这里是数组
    totalPages.value = res.pagination.totalPages * 10
    const result: UserData[] = res.data
    userList.splice(0, userList.length, ...result); // 清空数组并插入新数据
    loading.value = false
  }, 1000);
});
</script>


<style scoped lang="scss">
.page{
  height: 98%;
  border-bottom: 2px solid var(--el-border-color);
  .ct{
    height: 100%;
    .header{
      height: 10%;
      display: flex;
      flex-wrap: wrap;
      align-content: center;
      border-bottom: 2px solid var(--el-border-color);

      .search{
        width: 40%;
        height: 90%;
        background-color: white;

        display: flex;
        flex-wrap: wrap;
        justify-content: space-around;
        align-content: center;

        border: 2px solid var(--el-border-color);
        border-radius: 10px;
      }

      .button{
        width: 30%;
        height: 90%;
        background-color: white;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-around;
        align-content: center;

        margin-left: 300px;

        border: 2px solid var(--el-border-color);
        border-radius: 10px;
      }
      .buttonChange{
        width: 40%;
        height: 90%;
        background-color: white;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-around;
        align-content: center;

        margin-left: 180px;

        border: 2px solid var(--el-border-color);
        border-radius: 10px;
      }
    }
    
    .main{
      height: 80%;
      padding-top: 0;
      padding-bottom: 0;
      border-bottom: 2px solid var(--el-border-color);
      margin-bottom: 5px;

      .admin{
        width: 98%;
        margin-bottom: 10px;
        border: 2px solid var(--el-border-color);
        border-radius: 10px;
        
        :deep(.my-label) {
          background: var(--el-color-success-light-9) !important;
        }
        :deep(.my-content) {
          background: var(--el-color-danger-light-9);
        }

        .image{
          width: 80px;
          height: 80px;
        }

        .buttonOne,
        .buttonTwo{
          margin: 10px
        }

        .buttonOne{
          margin-left: 52%;
        }
      }
    }

    .from{
      height: 90%;
      padding-top: 0;
      padding-bottom: 0;
      border-bottom: 2px solid var(--el-border-color);
      margin-bottom: 5px;
      margin-top: 10px;

      display: flex;
      flex-wrap: wrap;
      align-content: center;
      justify-content: center;
    }
  }
}
</style>