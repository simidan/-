<template>
  <div class="common-layout page">
    <el-container class="ct">
      <el-header class="header">
        <div class="search">
          <el-input v-model="searchKey" style="width: 70%;height:75%" placeholder="Please input"/>
          <el-button plain size="large" @click="adminSearch">搜索</el-button>
        </div>
        <div :class="roleStore.mark === 0 || roleStore.mark === 3? 'button':'buttonChange'">
          <el-button plain size="large" type="warning" style="width: 100px;height:75%" @click="changeMark(3),adminAudit()">待审核</el-button>
          <el-button plain size="large" type="success" style="width: 100px;height:75%" @click="changeMark(2)">添加</el-button>
          <el-button plain size="large" type="success" style="width: 100px;height:75%" v-if="roleStore.mark === 1||roleStore.mark === 3" @click="backShow">返回</el-button>
        </div>
      </el-header>
      <el-main class="main" v-loading="loading" v-if="roleStore.mark ===0 || roleStore.mark===1 ||roleStore.mark===3">
        <el-scrollbar height="100%">
          <div v-for="item in adminList" :key="item.admin_id" class="admin">
            <el-descriptions :column="3" border>
              <el-descriptions-item
                label="姓名"
                label-align="right"
                align="center"
                label-class-name="my-label"
                class-name="my-content"
                width="150px"
                >{{item.username}}</el-descriptions-item
              >
              <el-descriptions-item label="性别" label-align="right" align="center">
                {{ item.gender==='0'?'男':'女' }}
              </el-descriptions-item>
              <el-descriptions-item label="电话" label-align="right" align="center"
                >{{item.phone}}</el-descriptions-item
              >
              <el-descriptions-item label="权限" label-align="right" align="center">
                {{item.role}}
              </el-descriptions-item>
              <el-descriptions-item label="出生日期" label-align="right" align="center">
                {{ item.birthday }}
              </el-descriptions-item>
              <el-descriptions-item label="邮件" label-align="right" align="center"
                >{{item.email}}
                </el-descriptions-item>
            </el-descriptions>
            <el-button plain size="large" type="primary" style="width: 10%;height:20%" class="buttonOne" @click="changeMark(4),adminUpdate(item)">修改信息</el-button>
            <el-button plain size="large" type="primary" style="width: 10%;height:20%" class="buttonTwo" v-show="item.status ===2" @click="adminExamine(item,0)">禁用</el-button>
            <el-button plain size="large" type="primary" style="width: 10%;height:20%" class="buttonTwo" v-show="item.status ===1" @click="adminExamine(item,2)">通过</el-button>
            <el-button plain size="large" type="primary" style="width: 10%;height:20%" class="buttonTwo" v-show="item.status ===0" @click="adminExamine(item,2)">解除禁用</el-button>
            <el-button plain size="large" type="danger" style="width: 10%;height:20%" class="buttonTwo" @click="adminDelete(item.admin_id)">删除</el-button>
          </div>
        </el-scrollbar>
      </el-main>
      <div v-else class="from">
        <roleFrom></roleFrom>
      </div>
      <el-pagination
          small
          background
          @current-change="handleCurrentChange"
          :current-page="pagelimit.page"
          layout="prev, pager, next"
          :total="totalPages"
          class="mt-4"
          v-if="roleStore.mark ===0 || roleStore.mark===1 ||roleStore.mark === 3"
        />
    </el-container>
  </div>
</template>

<script lang="ts" setup>
import { onBeforeMount, onMounted, reactive, ref } from 'vue';
import indexRolePageStore from '../../store/idnex/adminControl';
import { ElMessage, ElMessageBox } from 'element-plus'
import type { Action } from 'element-plus'
import roleFrom from '../indexFrom/roleFrom.vue'
import { adminMessage } from '../../utils/interface';
import { watch } from 'vue';

interface UserData {
  admin_id: number;
  birthday: string;
  created_at: string;
  email: string;
  gender: string;
  password: string;
  phone: string;
  role: string;
  status: number;
  updated_at: string;
  username: string;
}

const roleStore = indexRolePageStore();

const loading = ref(true)
const searchKey = ref<string>('');
const pagelimit = reactive({
  'limit': 10,
  'page': 1
}); // 当前页码
let totalPages = ref(10)

const adminList = reactive<UserData[]>([]); // 声明为 UserData 类型的数组

const changeMark = (num:number)=>{
  roleStore.mark = num
}

const backShow = async () =>{
  roleStore.mark = 0
  pagelimit.page = 1
  loading.value = true
  const res = await roleStore.roleShow(pagelimit); // 确保这里是数组
  totalPages.value = res.pagination.totalPages * 10
  const result: UserData[] = res.data
  adminList.splice(0, adminList.length, ...result); // 清空数组并插入新数据
  loading.value = false
}

const handleCurrentChange = async(newPage:number) => {
  pagelimit.page = newPage
  loading.value = true
  console.log(pagelimit);
  
  if(roleStore.mark === 0){
    const res = await roleStore.roleShow(pagelimit); // 确保这里是数组
    const result: UserData[] = res.data
    totalPages.value = res.pagination.totalPages * 10
    adminList.splice(0, adminList.length, ...result); // 清空数组并插入新数据
    loading.value = false
  }
  else if(roleStore.mark === 1){
    let combined = reactive({
      searchKey: searchKey.value, // 由于 searchKey 是一个 ref, 使用 searchKey.value 来获取其值
      ...pagelimit  // 使用展开运算符来合并 pagelimit 对象
    });
    const res = await roleStore.roleSearch(combined)
    const result: UserData[] = res.data
    totalPages.value = res.pagination.totalPages * 10
    adminList.splice(0, adminList.length, ...result); // 清空数组并插入新数据
    loading.value = false
  }
  else if(roleStore.mark === 3){
    const res = await roleStore.roleAudit(pagelimit); // 确保这里是数组
    totalPages.value = res.pagination.totalPages * 10
    const result: UserData[] = res.data
    adminList.splice(0, adminList.length, ...result); // 清空数组并插入新数据
    loading.value = false
  }
};

const adminAudit = async()=>{
  pagelimit.page = 1
  loading.value =true
  const res = await roleStore.roleAudit(pagelimit); // 确保这里是数组
  if(res === '您没有权限' || res === '审核通过失败' || res === '管理员禁用失败' || res === '请求失败'){
    ElMessageBox.alert(res, 'Title', {
            confirmButtonText: 'OK',
            callback: (action: Action) => {
              ElMessage({
                type: 'info',
                message: `action: ${action}`,
              });
            },
          });
          loading.value = false
  }else{
    ElMessageBox.alert(res.message, 'Title', {
            confirmButtonText: 'OK',
            callback: (action: Action) => {
              ElMessage({
                type: 'info',
                message: `action: ${action}`,
              });
            },
          });
    setTimeout(async() => {
    totalPages.value = res.pagination.totalPages * 10
  const result: UserData[] = res.data
  adminList.splice(0, adminList.length, ...result); // 清空数组并插入新数据
  loading.value = false
  }, 1000);
  }
  
  
  // totalPages.value = res.pagination.totalPages * 10
  // const result: UserData[] = res.data
  // adminList.splice(0, adminList.length, ...result); // 清空数组并插入新数据
  // loading.value = false
}

const adminSearch = async()=>{
  if(searchKey.value === ''){
    return ElMessageBox.alert('关键词不能为空', 'Title', {
            confirmButtonText: 'OK',
            callback: (action: Action) => {
              ElMessage({
                type: 'info',
                message: `action: ${action}`,
              });
            },
          });
  }
  pagelimit.page = 1
  let combined = reactive({
    searchKey: searchKey.value, // 由于 searchKey 是一个 ref, 使用 searchKey.value 来获取其值
    ...pagelimit  // 使用展开运算符来合并 pagelimit 对象
  });
  loading.value = true
  const res = await roleStore.roleSearch(combined)
  if(res === '您没有权限' || res === '没有找到匹配的管理员' || res === '请求失败'){
    ElMessageBox.alert(res, 'Title', {
            confirmButtonText: 'OK',
            callback: (action: Action) => {
              ElMessage({
                type: 'info',
                message: `action: ${action}`,
              });
            },
          });
          loading.value = false
  }else{
    const result: UserData[] = res.data
    totalPages.value = res.pagination.totalPages * 10
    adminList.splice(0, adminList.length, ...result); // 清空数组并插入新数据
    roleStore.mark = 1
    loading.value = false
  }
}

interface newAdminMessage extends adminMessage {
  admin_id:number
}
const adminUpdate = async(userInfo:newAdminMessage)=>{
  roleStore.userInfo = userInfo
  // roleStore.admin_id = userInfo.admin_id
}

const adminExamine = async(info:newAdminMessage,status:number)=>{
  loading.value = true
  const res = await roleStore.roleExamine(info.admin_id, status)
  if(res === '您没有权限' || res === '审核通过失败' || res === '管理员禁用失败' || res === '请求失败'){
    ElMessageBox.alert(res, 'Title', {
            confirmButtonText: 'OK',
            callback: (action: Action) => {
              ElMessage({
                type: 'info',
                message: `action: ${action}`,
              });
            },
          });
          loading.value = false
  }else{
    ElMessageBox.alert(res.message, 'Title', {
            confirmButtonText: 'OK',
            callback: (action: Action) => {
              ElMessage({
                type: 'info',
                message: `action: ${action}`,
              });
            },
          });
    setTimeout(async() => {
    const res = await roleStore.roleShow(pagelimit); // 确保这里是数组
    totalPages.value = res.pagination.totalPages * 10
    const result: UserData[] = res.data
    adminList.splice(0, adminList.length, ...result); // 清空数组并插入新数据
    loading.value = false
  }, 1000);
  }
}

const adminDelete = async (id:number)=>{
  loading.value = true
  const res = await roleStore.roleDelete(id)
  if(res === '您没有权限' || res === '管理员删除失败' || res === '请求失败'){
    ElMessageBox.alert(res, 'Title', {
            confirmButtonText: 'OK',
            callback: (action: Action) => {
              ElMessage({
                type: 'info',
                message: `action: ${action}`,
              });
            },
          });
          loading.value = false
  }else{
    ElMessageBox.alert(res.message, 'Title', {
            confirmButtonText: 'OK',
            callback: (action: Action) => {
              ElMessage({
                type: 'info',
                message: `action: ${action}`,
              });
            },
          });
    setTimeout(async() => {
    const res = await roleStore.roleShow(pagelimit); // 确保这里是数组
    totalPages.value = res.pagination.totalPages * 10
    const result: UserData[] = res.data
    adminList.splice(0, adminList.length, ...result); // 清空数组并插入新数据
    loading.value = false
  }, 1000);
  }
}

watch(() => roleStore.mark, async(newValue, oldValue) => {
  loading.value = true
  if(newValue === 0){
    roleStore.userInfo.admin_id = 0
  }
  setTimeout(async() => {
    const res = await roleStore.roleShow(pagelimit); // 确保这里是数组
    totalPages.value = res.pagination.totalPages * 10
    const result: UserData[] = res.data
    adminList.splice(0, adminList.length, ...result); // 清空数组并插入新数据
    loading.value = false
  }, 500);
});

onMounted( () => {
  setTimeout(async() => {
    const res = await roleStore.roleShow(pagelimit); // 确保这里是数组
    totalPages.value = res.pagination.totalPages * 10
    const result: UserData[] = res.data
    adminList.splice(0, adminList.length, ...result); // 清空数组并插入新数据
    loading.value = false
  }, 1000);
});
</script>


<style scoped lang="scss">
.page{
  height: 98%;
  border-bottom: 2px solid var(--el-border-color);
  .ct{
    height: 100%;
    .header{
      height: 10%;
      display: flex;
      flex-wrap: wrap;
      align-content: center;
      border-bottom: 2px solid var(--el-border-color);

      .search{
        width: 40%;
        height: 90%;
        background-color: white;

        display: flex;
        flex-wrap: wrap;
        justify-content: space-around;
        align-content: center;

        border: 2px solid var(--el-border-color);
        border-radius: 10px;
      }

      .button{
        width: 30%;
        height: 90%;
        background-color: white;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-around;
        align-content: center;

        margin-left: 300px;

        border: 2px solid var(--el-border-color);
        border-radius: 10px;
      }
      .buttonChange{
        width: 40%;
        height: 90%;
        background-color: white;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-around;
        align-content: center;

        margin-left: 180px;

        border: 2px solid var(--el-border-color);
        border-radius: 10px;
      }
    }
    
    .main{
      height: 80%;
      padding-top: 0;
      padding-bottom: 0;
      border-bottom: 2px solid var(--el-border-color);
      margin-bottom: 5px;

      .admin{
        width: 98%;
        margin-bottom: 10px;
        border: 2px solid var(--el-border-color);
        border-radius: 10px;
        
        :deep(.my-label) {
          background: var(--el-color-success-light-9) !important;
        }
        :deep(.my-content) {
          background: var(--el-color-danger-light-9);
        }

        .buttonOne,
        .buttonTwo{
          margin: 10px
        }

        .buttonOne{
          margin-left: 65%;
        }
      }
    }

    .from{
      height: 80%;
      padding-top: 0;
      padding-bottom: 0;
      border-bottom: 2px solid var(--el-border-color);
      margin-bottom: 5px;
      margin-top: 10px;

      display: flex;
      flex-wrap: wrap;
      align-content: center;
      justify-content: center;
    }
  }
}
</style>