export interface userMessage{
    username: string,
    password:string,
    email: string,
    phone: string,
    avatar:string,
    full_name: string,
    gender: string,
    birthday: string,
    defaultAddress: string
}

export interface adminMessage{
  username: string,
  password:string,
  phone: string,
  email: string,
  role: string,
  gender: string,
  birthday: string
}

export interface businessMessage{
  businessName: string,
  password: string,
  address: string,
  phone: string,
  email: string,
  image:string
}

export interface productMessage{
  sub_category_id: number,
  business_id: number,
  name: string,
  price: number,
  unit: string,
  stock_quantity: number,
  description: string,
  image: string,
  origin: string,
  harvest_date: string,
  shelf_life: number,
  certification: string,
  season: string,
  safety_standards: string,
  storage_conditions: string,
  grade:string
}

export interface orderMessage{
  user_id:number,
  business_id:number,
  product_id:number,
  quantity:number
  total_amount: number,
  status: string,
  payment_method: string,
  payment_status: string,
  shipping_name:string
  shipping_phone:string,
  shipping_address:string
}