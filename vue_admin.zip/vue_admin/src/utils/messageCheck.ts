import { adminMessage, businessMessage, orderMessage, productMessage, userMessage } from "./interface";

interface adminMessageCheck extends Partial<adminMessage>{}

export function adminMessageCheck(info: adminMessageCheck) {
  const errorMessages: { [key: string]: string } = {
    'username': '用户名只能包含汉字或字母或数字',
    'password': '请输入6到15位不含汉字的密码',
    'phone': '请输入有效的手机号',
    'email': '请输入有效的邮箱地址',
    'gender': '请选择性别',
    'role': '请选择权限',
    'birthday': '请选择出生日期',
  };

  const fieldNames: { [key: string]: string } = {
    'username': '用户名',
    'password': '密码',
    'phone': '手机号',
    'email': '邮箱',
    'gender': '性别',
    'role': '权限',
    'birthday': '出生日期',
  };

  for (let key in info) {
    if (!info[key as keyof adminMessage]) {
      return `${fieldNames[key]} 不能为空`;
    }

    if (key === 'username') {
      const username = info[key] as string;
      const pattern = /^[\u4e00-\u9fa5a-zA-Z0-9]+$/;; // 匹配汉字或字母的正则表达式
      if (!pattern.test(username)) {
        return errorMessages['username'];
      }
    }
    if (key === 'password') {
      const password = info[key] as string;
      if (password.length < 6 || password.length > 15 || /[\u4e00-\u9fa5]/.test(password)) {
        return errorMessages['password'];
      }
      // 其他密码复杂性验证逻辑...
    }
    if (key === 'phone') {
      const phone = info[key] as string;
      const check = /^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\d{8}$/;
      if (!check.test(phone)) {
        return errorMessages['phone'];
      }
    }
    if (key === 'email') {
      const email = info[key] as string;
      const emailPattern = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/; // 邮箱格式正则表达式
      if (!emailPattern.test(email)) {
        return errorMessages['email'];
      }
    }
    if (key === 'gender') {
      const gender = info[key] as string;
      if (!gender) {
        return errorMessages['gender'];
      }
    }
    if (key === 'role') {
      const role = info[key] as string;
      if (!role) {
        return errorMessages['role'];
      }
    }
    if (key === 'birthday') {
      const birthday = info[key] as string;
      if (!birthday || birthday === 'NaN-aN-aN') {
        return errorMessages['birthday'];
      }
    }
  }

  // 如果所有字段通过验证
  return '';
}

interface userMessageCheck extends Partial<userMessage>{}

export function userMessageCheck(info: userMessageCheck ,update?:number) {
  const errorMessages: { [key: string]: string } = {
    'username': '用户名只能包含汉字或字母或数字',
    'password': '请输入6到15位不含汉字的密码',
    'phone': '请输入有效的手机号',
    'email': '请输入有效的邮箱地址',
    'gender': '请选择性别',
    'birthday': '请选择出生日期',
  };

  const fieldNames: { [key: string]: string } = {
    'username': '用户名',
    'password': '密码',
    'phone': '手机号',
    'email': '邮箱',
    'gender': '性别',
    'defaultAddress': '地址',
    'birthday': '出生日期',
  };

  for (let key in info) {
    if (key !== 'defaultAddress') {
      if (!info[key as keyof userMessage]) {
          if (key === 'password' && update === 0) {
              continue; // 如果 user_id 不为 0，则允许密码为空
          }
          return `${fieldNames[key]} 不能为空`;
      }
    }

    if (key === 'username') {
      const username = info[key] as string;
      const pattern = /^[\u4e00-\u9fa5a-zA-Z0-9]+$/;; // 匹配汉字或字母的正则表达式
      if (!pattern.test(username)) {
        return errorMessages['username'];
      }
    }
    if (key === 'password') {
      if(update !==0){
        const password = info[key] as string;
        if (password.length < 6 || password.length > 15 || /[\u4e00-\u9fa5]/.test(password)) {
        return errorMessages['password'];
      }
      }
      // 其他密码复杂性验证逻辑...
    }
    if (key === 'phone') {
      const phone = info[key] as string;
      const check = /^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\d{8}$/;
      if (!check.test(phone)) {
        return errorMessages['phone'];
      }
    }
    if (key === 'email') {
      const email = info[key] as string;
      const emailPattern = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/; // 邮箱格式正则表达式
      if (!emailPattern.test(email)) {
        return errorMessages['email'];
      }
    }
    if (key === 'gender') {
      const gender = info[key] as string;
      if (!gender) {
        return errorMessages['gender'];
      }
    }
    if (key === 'birthday') {
      const birthday = info[key] as string;
      if (!birthday || birthday === 'NaN-aN-aN') {
        return errorMessages['birthday'];
      }
    }
  }

  // 如果所有字段通过验证
  return '';
}

interface businessMessageCheck extends Partial<businessMessage>{}

export function businessMessageCheck(info: businessMessageCheck ,update?:number) {
  const errorMessages: { [key: string]: string } = {
    'businessName': '用户名只能包含汉字或字母或数字',
    'password': '请输入6到15位不含汉字的密码',
    'phone': '请输入有效的手机号',
    'email': '请输入有效的邮箱地址',
  };

  const fieldNames: { [key: string]: string } = {
    'businessName': '用户名',
    'password': '密码',
    'phone': '手机号',
    'email': '邮箱',
    'address': '地址',
  };

  for (let key in info) {
    if (key !== 'address') {
      if (!info[key as keyof businessMessage]) {
          if (key === 'password' && update === 0) {
              continue; // 如果 user_id 不为 0，则允许密码为空
          }
          return `${fieldNames[key]} 不能为空`;
      }
    }

    if (key === 'businessName') {
      const businessName = info[key] as string;
      const pattern = /^[\u4e00-\u9fa5a-zA-Z0-9]+$/;; // 匹配汉字或字母的正则表达式
      if (!pattern.test(businessName)) {
        return errorMessages['businessName'];
      }
    }
    if (key === 'password') {
      if(update !==0){
        const password = info[key] as string;
        if (password.length < 6 || password.length > 15 || /[\u4e00-\u9fa5]/.test(password)) {
        return errorMessages['password'];
      }
      }
      // 其他密码复杂性验证逻辑...
    }
    if (key === 'phone') {
      const phone = info[key] as string;
      const check = /^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\d{8}$/;
      if (!check.test(phone)) {
        return errorMessages['phone'];
      }
    }
    if (key === 'email') {
      const email = info[key] as string;
      const emailPattern = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/; // 邮箱格式正则表达式
      if (!emailPattern.test(email)) {
        return errorMessages['email'];
      }
    }
  }

  // 如果所有字段通过验证
  return '';
}

interface productMessageCheck extends Partial<productMessage>{
  [key: string]: any;
}
export function productMessageCheck(info: productMessageCheck) {
  const errorMessages: { [key: string]: string } = {
      'sub_category_id': '子分类ID必须大于0',
      'business_id': '商家ID必须大于0',
      'name': '产品名称不能为空',
      'price': '产品价格必须大于0',
      'unit': '产品单位不能为空',
      'stock_quantity': '库存数量必须为非负整数',
      'description': '产品描述不能为空',
      'origin': '产品产地不能为空',
      'harvest_date': '收获日期格式应为YYYY-MM-DD',
      'shelf_life': '保质期必须为正整数',
      'certification': '认证信息不能为空',
      'season': '季节必须是春季、夏季、秋季、冬季或全年之一',
      'safety_standards': '安全标准不能为空',
      'storage_conditions': '储存条件不能为空',
      'grade': '产品等级不能为空',
  };

  const validSeasons = ['春季', '夏季', '秋季', '冬季', '全年'];

  for (let key in info) {
      const value = info[key];
      // 通用非空检查
      if (value === undefined || value === null || value === '') {
          return `${errorMessages[key]}`;
      }

      // 特定字段的额外验证
      switch(key) {
          case 'product_id':
          case 'sub_category_id':
          case 'business_id':
              if (value <= 0) {
                  return errorMessages[key];
              }
              break;
          case 'price':
              if (value <= 0) {
                  return errorMessages[key];
              }
              break;
          case 'stock_quantity':
              if (value < 0 || !Number.isInteger(value)) {
                  return errorMessages[key];
              }
              break;
          case 'shelf_life':
              if (value <= 0 || !Number.isInteger(value)) {
                  return errorMessages[key];
              }
              break;
          case 'season':
              if (!validSeasons.includes(value)) {
                  return errorMessages[key];
              }
              break;
          // 可以继续为其他字段添加额外的验证规则
      }
  }

  // 如果所有字段通过验证
  return '';
}

// 添加数据时的检查函数
export function checkAddOrderFormData(form: any): string {
  const errorMessages: { [key: string]: string } = {
    'user_id': '用户ID不能为空',
    'business_id': '商家ID不能为空',
    'product_id': '产品ID不能为空',
    'quantity': '数量不能为空',
    'status': '状态不能为空',
    'payment_method': '支付方式不能为空',
    'payment_status': '支付状态不能为空',
    'shipping_address': '送货地址不能为空',
  };

  const fieldNames: { [key: string]: string } = {
    'user_id': '用户ID',
    'business_id': '商家ID',
    'product_id': '产品ID',
    'quantity': '数量',
    'status': '状态',
    'payment_method': '支付方式',
    'payment_status': '支付状态',
    'shipping_address': '送货地址',
  };

  for (const key in form) {
    if (Object.prototype.hasOwnProperty.call(fieldNames, key)) {
      if (!form[key]) {
        return `${fieldNames[key]} 不能为空`;
      }
    }
  }

  return ''; // 如果所有字段通过验证
}

export function checkUpdateOrderFormData(form: any): string {
  // 更新数据时，所有字段都需要进行检查，所以我们复用相同的结构
  return checkAddOrderFormData(form); // 在这个例子中，更新数据和添加数据使用相同的字段检查
}

