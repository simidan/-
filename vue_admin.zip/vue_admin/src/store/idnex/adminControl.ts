import { defineStore } from "pinia";
import { reactive, ref } from "vue";
import { adminShow, adminSearch, adminAdd, adminAudit, adminUpdate, adminExamine, adminDelete, } from "@/api";
import { adminMessage } from "@/utils/interface";

interface pageLimit {
  limit: number,
  page: number
}

interface adminSearch extends pageLimit {
  searchKey: string | number;
}

const indexRolePageStore = defineStore('rolePage',()=>{
  const mark = 0

  const userInfo = reactive({
    admin_id: 0,
    username: '',
    password:'',
    phone:'',
    email:'',
    gender:'',
    role:'',
    birthday:''
  })

  const roleShow = async (pageLimit: pageLimit) => {
    try {
        const res = await adminShow(pageLimit); // 等待 promise 解决
        const result = res.data; // 从响应中获取数据
        
        // 检查状态码
        if (result.statusCode === 200) {
            return result; // 返回结果
        } else if(result.statusCode === 405){
          
          return '您没有权限'
        }
        else {
            return result; // 即使状态码不是200也返回结果
        }
    } catch (error) {
        console.error('请求失败:', error); // 如果请求失败记录错误
        return '请求失败'; // 返回 null 或任何错误处理对象
    }
  };

  const roleSearch = async (info:adminSearch)=>{
    try {
      const res = await adminSearch(info) // 等待 promise 解决
      const result = res.data; // 从响应中获取数据
      
      // 检查状态码
      if (result.statusCode === 200) {
          return result; // 返回结果
      } 
      else if(result.statusCode === 405){
        return result.message
      }
      else if(result.statusCode === 404){
        return result.message
      }else{
        return '请求失败'
      }
    } catch (error) {
        console.error('请求失败:', error); // 如果请求失败记录错误
        return '请求失败'; // 返回 null 或任何错误处理对象
    }
  }

  const roleAdd = async (info:adminMessage)=>{
    try{
      const res = await adminAdd(info)
      const result = res.data; // 从响应中获取数据
      if (result.statusCode === 200) {
        return result; // 返回结果
    } 
    else if(result.statusCode === 405){
      return result.message
    }
    else if(result.statusCode === 409){
      return result.message
    }else{
      return '请求失败'
    }
    } catch(error){
      console.error('请求失败:', error); // 如果请求失败记录错误
      return '请求失败'; // 返回 null 或任何错误处理对象
    }
  }

  const roleAudit = async (pageLimit: pageLimit)=>{
    try {
      const res = await adminAudit(pageLimit); // 等待 promise 解决
      const result = res.data; // 从响应中获取数据
      
      // 检查状态码
      if (result.statusCode === 200) {
          return result; // 返回结果
      } else if(result.statusCode === 405){
        
        return '您没有权限'
      }
      else {
          return result; // 即使状态码不是200也返回结果
      }
    } catch (error) {
        console.error('请求失败:', error); // 如果请求失败记录错误
        return '请求失败'; // 返回 null 或任何错误处理对象
    }
  }

  const roleUpdate = async (id:number, userinfo:adminMessage)=>{
    try{
      const res = await adminUpdate(id,userinfo)
      const result = res.data; // 从响应中获取数据
      if (result.statusCode === 200) {
        return result; // 返回结果
      } 
      else if(result.statusCode === 405){
        return result.message
      }
      else if(result.statusCode === 400){
        return result.message
      }else{
        return '请求失败'
      }
    } catch(error){
      console.error('请求失败:', error); // 如果请求失败记录错误
      return '请求失败'; // 返回 null 或任何错误处理对象
    }
  }

  const roleExamine = async (id:number, status:number)=>{
    const info = {'status':status}
    try{
      const res = await adminExamine(id,info)
      const result = res.data; // 从响应中获取数据
      console.log(result);
      
      if (result.statusCode === 200) {
        return result; // 返回结果
      } 
      else if(result.statusCode === 405){
        return result.message
      }
      else if(result.statusCode === 401){
        return result.message
      }else{
        return '请求失败'
      }
    } catch(error){
      console.error('请求失败:', error); // 如果请求失败记录错误
      return '请求失败'; // 返回 null 或任何错误处理对象
    }
  }

  const roleDelete = async(id:number)=>{
    try{
      const res = await adminDelete(id)
      const result = res.data; // 从响应中获取数据
      console.log(result);
      
      if (result.statusCode === 200) {
        return result; // 返回结果
      } 
      else if(result.statusCode === 405){
        return result.message
      }
      else if(result.statusCode === 500){
        return result.message
      }else{
        return '请求失败'
      }
    } catch(error){
      console.error('请求失败:', error); // 如果请求失败记录错误
      return '请求失败'; // 返回 null 或任何错误处理对象
    }
  }
  
  return {roleShow, roleSearch, mark, roleAdd, roleAudit, userInfo, roleUpdate, roleExamine, roleDelete}
})

export default indexRolePageStore