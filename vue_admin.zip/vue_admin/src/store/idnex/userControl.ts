import { defineStore } from "pinia";
import { reactive, ref } from "vue";
import { usersAdd, usersDelete, usersSearch, usersShow, usersStatus, usersUpdate } from "@/api";
import { userMessage } from "@/utils/interface";

interface pageLimit {
  limit: number,
  page: number
}

interface userSearch extends pageLimit {
  searchKey: string | number;
}

const indexUserPageStore = defineStore('userPage',()=>{
  let mark = ref(0)
  let newUserId = ref(0)
  const userInfo = reactive({
    user_id: 0,
    username: '',
    email: '',
    phone: '',
    full_name: '',
    gender: '',
    birthday: '',
    defaultAddress: ''
  })
  let userIdGroup = reactive([])

  const userShow = async (pageLimit: pageLimit) => {
    try {
        const res = await usersShow(pageLimit); // 等待 promise 解决
        const result = res.data; // 从响应中获取数据
        
        // 检查状态码
        if (result.statusCode === 200) {
            return result; // 返回结果
        } else if(result.statusCode === 405){
          
          return '您没有权限'
        }
        else {
            return result; // 即使状态码不是200也返回结果
        }
    } catch (error) {
        console.error('请求失败:', error); // 如果请求失败记录错误
        return '请求失败'; // 返回 null 或任何错误处理对象
    }
  };

  const userSearch = async (info:userSearch)=>{
    try {
      const res = await usersSearch(info) // 等待 promise 解决
      const result = res.data; // 从响应中获取数据
      
      // 检查状态码
      if (result.statusCode === 200) {
          return result; // 返回结果
      } 
      else if(result.statusCode === 405){
        return result.message
      }
      else if(result.statusCode === 404){
        return result.message
      }else{
        return '请求失败'
      }
    } catch (error) {
        console.error('请求失败:', error); // 如果请求失败记录错误
        return '请求失败'; // 返回 null 或任何错误处理对象
    }
  }
  interface addUserMessage extends Omit<userMessage, 'avatar'>{}
  const userAdd = async (info:addUserMessage)=>{
    try{
      const res = await usersAdd(info)
      const result = res.data; // 从响应中获取数据
      if (result.statusCode === 200) {
        return result; // 返回结果
    } 
    else if(result.statusCode === 405){
      return result.message
    }
    else if(result.statusCode === 409){
      return result.message
    }else{
      return '请求失败'
    }
    } catch(error){
      console.error('请求失败:', error); // 如果请求失败记录错误
      return '请求失败'; // 返回 null 或任何错误处理对象
    }
  }

  const userUpdate = async (id:number, userinfo:addUserMessage)=>{
    try{
      const res = await usersUpdate(id,userinfo)
      const result = res.data; // 从响应中获取数据
      
      if (result.statusCode === 200) {
        return result; // 返回结果
      } 
      else if(result.statusCode === 405){
        return result.message
      }
      else if(result.statusCode === 400){
        return result.message
      }else{
        return '请求失败'
      }
    } catch(error){
      console.error('请求失败:', error); // 如果请求失败记录错误
      return '请求失败'; // 返回 null 或任何错误处理对象
    }
  }

  const userStatus = async (id:number, status:number)=>{
    const info = {'status':status}
    try{
      const res = await usersStatus(id,info)
      const result = res.data; // 从响应中获取数据
      console.log(result);
      
      if (result.statusCode === 200) {
        return result; // 返回结果
      } 
      else if(result.statusCode === 405){
        return result.message
      }
      else if(result.statusCode === 401){
        return result.message
      }else{
        return '请求失败'
      }
    } catch(error){
      console.error('请求失败:', error); // 如果请求失败记录错误
      return '请求失败'; // 返回 null 或任何错误处理对象
    }
  }

  const userDelete = async(id:number)=>{
    try{
      const res = await usersDelete(id)
      const result = res.data; // 从响应中获取数据
      if (result.statusCode === 200) {
        return result; // 返回结果
      } 
      else if(result.statusCode === 405){
        return result.message
      }
      else if(result.statusCode === 500){
        return result.message
      }else{
        return '请求失败'
      }
    } catch(error){
      console.error('请求失败:', error); // 如果请求失败记录错误
      return '请求失败'; // 返回 null 或任何错误处理对象
    }
  }
  
  return { userAdd,userSearch,userStatus,userUpdate,userShow,userDelete, mark,userInfo,newUserId,userIdGroup }
})

export default indexUserPageStore