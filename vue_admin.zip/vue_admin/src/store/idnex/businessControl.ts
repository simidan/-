import { defineStore } from "pinia";
import { reactive, ref } from "vue";
import { businessesAdd, businessesAudit, businessesDelete, businessesExamine, businessesSearch, businessesShow, businessesUpdate } from "@/api";
import { businessMessage } from "@/utils/interface";

interface pageLimit {
  limit: number,
  page: number
}

interface businessSearch extends pageLimit {
  searchKey: string | number;
}

const indexBusinessPageStore = defineStore('businessPage',()=>{
  const mark = 0
  let newBusinessId = ref(0)
const businessInfo = reactive({
  business_id:0,
  businessName: '',
  password: '',
  address: '',
  phone: '',
  email: '',
  image:''
  })
  let businessIdGroup = reactive([])

  const businessShow = async (pageLimit: pageLimit) => {
    try {
        const res = await businessesShow(pageLimit); // 等待 promise 解决
        const result = res.data; // 从响应中获取数据
        
        // 检查状态码
        if (result.statusCode === 200) {
            return result; // 返回结果
        } else if(result.statusCode === 405){
          
          return '您没有权限'
        }
        else {
            return result; // 即使状态码不是200也返回结果
        }
    } catch (error) {
        console.error('请求失败:', error); // 如果请求失败记录错误
        return '请求失败'; // 返回 null 或任何错误处理对象
    }
  };

  const businessSearch = async (info:businessSearch)=>{
    try {
      const res = await businessesSearch(info) // 等待 promise 解决
      const result = res.data; // 从响应中获取数据
      
      // 检查状态码
      if (result.statusCode === 200) {
          return result; // 返回结果
      } 
      else if(result.statusCode === 405){
        return result.message
      }
      else if(result.statusCode === 404){
        return result.message
      }else{
        return '请求失败'
      }
    } catch (error) {
        console.error('请求失败:', error); // 如果请求失败记录错误
        return '请求失败'; // 返回 null 或任何错误处理对象
    }
  }
  interface addBusinessMessage extends Omit<businessMessage, 'image'>{}
  const businessAdd = async (info:addBusinessMessage)=>{
    try{
      const res = await businessesAdd(info)
      const result = res.data; // 从响应中获取数据
      if (result.statusCode === 200) {
        return result; // 返回结果
    } 
    else if(result.statusCode === 405){
      return result.message
    }
    else if(result.statusCode === 409){
      return result.message
    }else{
      return '请求失败'
    }
    } catch(error){
      console.error('请求失败:', error); // 如果请求失败记录错误
      return '请求失败'; // 返回 null 或任何错误处理对象
    }
  }

  const businessAudit = async (pageLimit: pageLimit)=>{
    try {
      const res = await businessesAudit(pageLimit); // 等待 promise 解决
      const result = res.data; // 从响应中获取数据
      
      // 检查状态码
      if (result.statusCode === 200) {
          return result; // 返回结果
      } else if(result.statusCode === 405){
        
        return '您没有权限'
      }
      else {
          return result; // 即使状态码不是200也返回结果
      }
    } catch (error) {
        console.error('请求失败:', error); // 如果请求失败记录错误
        return '请求失败'; // 返回 null 或任何错误处理对象
    }
  }

  const businessUpdate = async (id:number, businessinfo:addBusinessMessage)=>{
    try{
      const res = await businessesUpdate(id,businessinfo)
      const result = res.data; // 从响应中获取数据
      if (result.statusCode === 200) {
        return result; // 返回结果
      } 
      else if(result.statusCode === 405){
        return result.message
      }
      else if(result.statusCode === 400){
        return result.message
      }else{
        return '请求失败'
      }
    } catch(error){
      console.error('请求失败:', error); // 如果请求失败记录错误
      return '请求失败'; // 返回 null 或任何错误处理对象
    }
  }

  const businessExamine = async (id:number, status:number)=>{
    const info = {'status':status}
    try{
      const res = await businessesExamine(id,info)
      const result = res.data; // 从响应中获取数据
      console.log(result);
      
      if (result.statusCode === 200) {
        return result; // 返回结果
      } 
      else if(result.statusCode === 405){
        return result.message
      }
      else if(result.statusCode === 401){
        return result.message
      }else{
        return '请求失败'
      }
    } catch(error){
      console.error('请求失败:', error); // 如果请求失败记录错误
      return '请求失败'; // 返回 null 或任何错误处理对象
    }
  }

  const businessDelete = async(id:number)=>{
    try{
      const res = await businessesDelete(id)
      const result = res.data; // 从响应中获取数据
      console.log(result);
      
      if (result.statusCode === 200) {
        return result; // 返回结果
      } 
      else if(result.statusCode === 405){
        return result.message
      }
      else if(result.statusCode === 500){
        return result.message
      }else{
        return '请求失败'
      }
    } catch(error){
      console.error('请求失败:', error); // 如果请求失败记录错误
      return '请求失败'; // 返回 null 或任何错误处理对象
    }
  }
  
  return {businessShow, businessSearch, mark, businessAdd, businessAudit, businessInfo, businessUpdate, businessExamine, businessDelete,newBusinessId,businessIdGroup}
})

export default indexBusinessPageStore