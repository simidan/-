import { defineStore } from "pinia";
import { reactive, ref } from "vue";
import { productsAdd, productsAudit, productsDelete, productsExamine, productsSearch, productsShow, productsUpdate } from "@/api";
import { productMessage } from "@/utils/interface";

interface pageLimit {
  limit: number,
  page: number
}

interface productSearch extends pageLimit {
  searchKey: string | number;
}

const indexProductPageStore = defineStore('productPage',()=>{
  let mark = ref(0)
  let newProductId = ref(0)
  const productInfo = reactive({
    product_id: 0,
    sub_category_id: 0,
    business_id: 0,
    name: '',
    price: 0,
    unit: '',
    stock_quantity: 0,
    description: '',
    image: '',
    origin: '',
    harvest_date: '',
    shelf_life: 0,
    certification: '',
    season: '',
    safety_standards: '',
    storage_conditions: '',
    grade: ''
  })
  let productIdGroup = reactive([])

  const productShow = async (pageLimit: pageLimit) => {
    try {
        const res = await productsShow(pageLimit); // 等待 promise 解决
        const result = res.data; // 从响应中获取数据
        
        // 检查状态码
        if (result.statusCode === 200) {
            return result; // 返回结果
        } else if(result.statusCode === 405){
          
          return '您没有权限'
        }
        else {
            return result; // 即使状态码不是200也返回结果
        }
    } catch (error) {
        console.error('请求失败:', error); // 如果请求失败记录错误
        return '请求失败'; // 返回 null 或任何错误处理对象
    }
  };

  const productSearch = async (info:productSearch)=>{
    try {
      const res = await productsSearch(info) // 等待 promise 解决
      const result = res.data; // 从响应中获取数据
      
      // 检查状态码
      if (result.statusCode === 200) {
          return result; // 返回结果
      } 
      else if(result.statusCode === 405){
        return result.message
      }
      else if(result.statusCode === 404){
        return result.message
      }else{
        return '请求失败'
      }
    } catch (error) {
        console.error('请求失败:', error); // 如果请求失败记录错误
        return '请求失败'; // 返回 null 或任何错误处理对象
    }
  }
  interface addProductMessage extends Omit<productMessage, 'image'>{}
  const productAdd = async (info:addProductMessage)=>{
    try{
      const res = await productsAdd(info)
      const result = res.data; // 从响应中获取数据
      if (result.statusCode === 200) {
        return result; // 返回结果
    } 
    else if(result.statusCode === 405){
      return result.message
    }
    else if(result.statusCode === 409){
      return result.message
    }else{
      return '请求失败'
    }
    } catch(error){
      console.error('请求失败:', error); // 如果请求失败记录错误
      return '请求失败'; // 返回 null 或任何错误处理对象
    }
  }

  const productAudit = async (pageLimit: pageLimit)=>{
    try {
      const res = await productsAudit(pageLimit); // 等待 promise 解决
      const result = res.data; // 从响应中获取数据
      
      // 检查状态码
      if (result.statusCode === 200) {
          return result; // 返回结果
      } else if(result.statusCode === 405){
        
        return '您没有权限'
      }
      else {
          return result; // 即使状态码不是200也返回结果
      }
    } catch (error) {
        console.error('请求失败:', error); // 如果请求失败记录错误
        return '请求失败'; // 返回 null 或任何错误处理对象
    }
  }

  const productUpdate = async (id:number, productinfo:addProductMessage)=>{
    try{
      const res = await productsUpdate(id,productinfo)
      const result = res.data; // 从响应中获取数据
      
      if (result.statusCode === 200) {
        return result; // 返回结果
      } 
      else if(result.statusCode === 405){
        return result.message
      }
      else if(result.statusCode === 400){
        return result.message
      }else{
        return '请求失败'
      }
    } catch(error){
      console.error('请求失败:', error); // 如果请求失败记录错误
      return '请求失败'; // 返回 null 或任何错误处理对象
    }
  }

  const productExamine = async (id:number, status:number)=>{
    const info = {'status':status}
    try{
      const res = await productsExamine(id,info)
      const result = res.data; // 从响应中获取数据
      console.log(result);
      
      if (result.statusCode === 200) {
        return result; // 返回结果
      } 
      else if(result.statusCode === 405){
        return result.message
      }
      else if(result.statusCode === 401){
        return result.message
      }else{
        return '请求失败'
      }
    } catch(error){
      console.error('请求失败:', error); // 如果请求失败记录错误
      return '请求失败'; // 返回 null 或任何错误处理对象
    }
  }


  const productDelete = async(id:number)=>{
    try{
      const res = await productsDelete(id)
      const result = res.data; // 从响应中获取数据
      if (result.statusCode === 200) {
        return result; // 返回结果
      } 
      else if(result.statusCode === 405){
        return result.message
      }
      else if(result.statusCode === 500){
        return result.message
      }else{
        return '请求失败'
      }
    } catch(error){
      console.error('请求失败:', error); // 如果请求失败记录错误
      return '请求失败'; // 返回 null 或任何错误处理对象
    }
  }
  
  return { productAdd,productSearch,productExamine,productAudit,productUpdate,productShow,productDelete, mark,productInfo,newProductId,productIdGroup }
})

export default indexProductPageStore