import { defineStore } from "pinia";
import { ref } from "vue";

const indexMainPageStore = defineStore('indexPage',()=>{
  let mainChangeStatus = ref('')

  function mainChange(selection:string){
    mainChangeStatus.value = selection
  }

  return {mainChange, mainChangeStatus}
})

export default indexMainPageStore