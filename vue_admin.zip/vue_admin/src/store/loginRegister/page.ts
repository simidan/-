import { defineStore } from "pinia";
import { ref } from "vue";

const loginPageStore = defineStore('loginPage',()=>{
  let fromChangeStatus = ref('Login')

  function fromChange(){
    if(fromChangeStatus.value === 'Login'){
      fromChangeStatus.value = 'Register'
    }else{
      fromChangeStatus.value = 'Login'
    }
  }

  return {fromChange, fromChangeStatus}
})

export default loginPageStore