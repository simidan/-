import { defineStore } from "pinia";
import {registerApi} from '@/api/index';
import { adminMessage } from "@/utils/interface";

interface registerInfo extends adminMessage{}

const userRegisterStore = defineStore('register',()=>{
  async function register(registerInfo:registerInfo) {
    try {
      const userInfo = await registerApi(registerInfo);
      return userInfo.data
    } catch (error) {
      console.error('Login failed:', error);
    }
  }
  return {register}
})

export default userRegisterStore