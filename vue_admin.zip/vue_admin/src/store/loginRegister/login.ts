// 假设在 types.ts 中定义了 LoginInfoType 和 UserInfoType
import { defineStore } from 'pinia';
import { loginApi } from '@/api/index';
import { ref } from 'vue';// 假设这是你定义类型的地方

// 定义初始登录信息的类型，这取决于你的具体需求
// 例如，这里我们假设登录信息只包含用户名和密码
interface InitialLoginInfo {
  username: string;
  password: string;
}

// types.ts
interface LoginInfoType {
  username: string;
  password: string;
}

const useLoginStore = defineStore('login', () => {
  // 由于传入的 loginInfo 是动态的，我们这里直接使用 ref 来声明
  // 如果有初始登录信息，应当确保它符合 InitialLoginInfo 类型
  async function login(loginInfo:LoginInfoType) {
    try {
      const userInfo = await loginApi(loginInfo);
      
      const result = userInfo.data      
      
      if(result.statusCode === '200'){
        return result
      }else{
        return result
      }
      
    } catch (error) {
      console.error('Login failed:', error);
    }
  }

  return {  login };
});

export default useLoginStore;
