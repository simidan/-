import request from "@/api/request";
import { adminMessage, userMessage, businessMessage, productMessage, orderMessage } from "@/utils/interface";

// 定义登录参数的接口
interface LoginParams {
    username: string;
    password: string;
}

interface pageLimit {
    limit: number,
    page: number
}

interface RegisterParams extends adminMessage {}

interface token{
    "token":string
}

// 使用上面定义的接口来指定 `user` 参数的类型
export const loginApi = (loginInfo: LoginParams) => {
    return request.post('GAPshop/admin/login', loginInfo);
};

export const registerApi = (registerInfo:RegisterParams) =>{
    return request.post('GAPshop/admin/register',registerInfo)
}

export const checkTokenApi = (token:token) => {
    return request.post('GAPshop/admin/checkToken',token)
}

//adminControl
//====================================================================================================================================
//====================================================================================================================================
export const adminShow = (info:pageLimit)=>{
    return request.get('GAPshop/admin/adminControl/adminShow',{
            params: info,
        }
    )
}

interface adminSearch extends pageLimit {
    searchKey: string | number;
}
export const adminSearch = (info:adminSearch)=>{
    return request.get('GAPshop/admin/adminControl/adminSearch',{
            params: info,
        }
    )
}

export const adminAdd = (info:adminMessage)=>{
    return request.post('GAPshop/admin/adminControl/adminAdd',info)
}

export const adminUpdate = (id:number,info:adminMessage)=>{
    return request.put(`GAPshop/admin/adminControl/adminUpdate/${id}`,info)
}

export const adminAudit = (info:pageLimit)=>{
    return request.get('GAPshop/admin/adminControl/adminAudit',{
            params: info,
        }
    )
}

interface status {
    'status':number,
}
export const adminExamine = (id:number,status:status)=>{
    return request.put(`GAPshop/admin/adminControl/adminExamine/${id}`,status)
}

export const adminDelete = (id:number)=>{
    return request.delete(`GAPshop/admin/adminControl/adminDelete/${id}`)
}

//userControl
//====================================================================================================================================
//====================================================================================================================================
export const usersShow = (info:pageLimit)=>{
    return request.get('GAPshop/admin/userControl/userShow',{
            params: info,
        }
    )
}
interface userSearch extends pageLimit {
    searchKey: string | number;
}
export const usersSearch = (info:userSearch)=>{
    return request.get('GAPshop/admin/userControl/userSearch',{
            params: info,
        }
    )
}

interface addUserMessage extends Omit<userMessage, 'avatar'>{}
export const usersAdd = (info:addUserMessage)=>{
    return request.post('GAPshop/admin/userControl/userAdd',info)
}
export const usersUpdate = (id:number,info:addUserMessage)=>{
    return request.put(`GAPshop/admin/userControl/userUpdate/${id}`,info)
}
interface status {
    'status':number,
}
export const usersStatus = (id:number,status:status)=>{
    return request.put(`GAPshop/admin/userControl/userStatus/${id}`,status)
}
export const usersDelete = (id:number)=>{
    return request.delete(`GAPshop/admin/userControl/userDelete/${id}`)
}


//businessControl
//====================================================================================================================================
//====================================================================================================================================
export const businessesShow = (info:pageLimit)=>{
    return request.get('GAPshop/admin/businessControl/businessShow',{
            params: info,
        }
    )
}
interface businessSearch extends pageLimit {
    searchKey: string | number;
}
export const businessesSearch = (info:businessSearch)=>{
    return request.get('GAPshop/admin/businessControl/businessSearch',{
            params: info,
        }
    )
}

interface addBusinessMessage extends Omit<businessMessage, 'image'>{}
export const businessesAdd = (info:addBusinessMessage)=>{
    return request.post('GAPshop/admin/businessControl/businessAdd',info)
}
export const businessesUpdate = (id:number,info:addBusinessMessage)=>{
    return request.put(`GAPshop/admin/businessControl/businessUpdate/${id}`,info)
}
export const businessesAudit = (info:pageLimit)=>{
    return request.get('GAPshop/admin/businessControl/businessAudit',{
            params: info,
        }
    )
}
interface status {
    'status':number,
}
export const businessesExamine = (id:number,status:status)=>{
    return request.put(`GAPshop/admin/businessControl/businessExamine/${id}`,status)
}
export const businessesDelete = (id:number)=>{
    return request.delete(`GAPshop/admin/businessControl/businessDelete/${id}`)
}

// productControl
//====================================================================================================================================
//====================================================================================================================================
export const productsShow = (info:pageLimit)=>{
    return request.get('GAPshop/admin/productControl/productShow',{
            params: info,
        }
    )
}
interface productSearch extends pageLimit {
    searchKey: string | number;
}
export const productsSearch = (info:productSearch)=>{
    return request.get('GAPshop/admin/productControl/productSearch',{
            params: info,
        }
    )
}

interface addProductMessage extends Omit<productMessage, 'image'>{}
export const productsAdd = (info:addProductMessage)=>{
    return request.post('GAPshop/admin/productControl/productAdd',info)
}
export const productsUpdate = (id:number,info:addProductMessage)=>{
    return request.put(`GAPshop/admin/productControl/productUpdate/${id}`,info)
}
export const productsAudit = (info:pageLimit)=>{
    return request.get('GAPshop/admin/productControl/productAudit',{
            params: info,
        }
    )
}
interface status {
    'status':number,
}
export const productsExamine = (id:number,status:status)=>{
    return request.put(`GAPshop/admin/productControl/productExamine/${id}`,status)
}
export const productsDelete = (id:number)=>{
    return request.delete(`GAPshop/admin/productControl/productDelete/${id}`)
}

//orderControl
//====================================================================================================================================
//====================================================================================================================================
export const ordersShow = (info:pageLimit)=>{
    return request.get('GAPshop/admin/orderControl/orderShow',{
            params: info,
        }
    )
}
interface orderSearch extends pageLimit {
    searchKey: string | number;
}
export const ordersSearch = (info:orderSearch)=>{
    return request.get('GAPshop/admin/orderControl/orderSearch',{
            params: info,
        }
    )
}

interface addOrderMessage extends Omit<orderMessage, 'total_amount' | 'shipping_name' | 'shipping_phone'> {}
export const ordersAdd = (info:addOrderMessage)=>{
    return request.post('GAPshop/admin/orderControl/orderAdd',info)
}
export const ordersUpdate = (id:number,info:orderMessage)=>{
    return request.put(`GAPshop/admin/orderControl/orderUpdate/${id}`,info)
}
export const ordersDelete = (id:number)=>{
    return request.delete(`GAPshop/admin/orderControl/orderDelete/${id}`)
}