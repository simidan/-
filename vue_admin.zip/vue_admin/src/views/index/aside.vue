<template>
  <div class="aside">
    <div class="logo">
      <img src="../../../public/image/logo2.png" alt="">
    </div>
    <div v-for="(item, index) in roleGroup" :key="index" :class="activeIndex === index ? 'roleGroup-select' : 'roleGroup'" @click="changeBackground(index); IndexPageStore.mainChange(item)" >
      <p>{{item}}</p>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { onBeforeMount, reactive, ref } from "vue";
import indexMainPageStore from '../../store/idnex/pageAside'
import indexRolePageStore from "@/store/idnex/adminControl";
import indexUserPageStore from "@/store/idnex/userControl";
import indexBusinessPageStore from "@/store/idnex/businessControl";
import indexProductPageStore from "@/store/idnex/productControl";
import indexOrderPageStore from '@/store/idnex/orderStore'

const IndexPageStore = indexMainPageStore()
const roleStore = indexRolePageStore()
const userStore = indexUserPageStore()
const businessStore = indexBusinessPageStore()
const productStore = indexProductPageStore()
const orderStore = indexOrderPageStore()

const roleGroup = reactive([
  '权限管理',
  '用户管理',
  '商家管理',
  '产品管理',
  '订单管理'
])

const activeIndex = ref(0);

function changeBackground(index: number) {
  activeIndex.value = index;
  roleStore.mark = 0
  userStore.mark = 0
  businessStore.mark = 0
  productStore.mark = 0
  orderStore.mark = 0
}

onBeforeMount(()=>{
  IndexPageStore.mainChange('权限管理')
})
</script>

<style scoped lang="scss">
.aside{
  width: 99%;
  height: 100%;
  background-color: white;
  border-right: 2px solid rgba(128, 128, 128, 0.5);

  .logo{
    width: 100%;
    height: 100px;
    border-bottom: 2px solid var(--el-border-color);

    img{
      height: 100%;
    }
  }

  .roleGroup{
    width: 100%;
    height: 60px;
    display: flex;
    flex-wrap: wrap;
    align-content: center;
    border-bottom: 2px solid var(--el-border-color);
    
    p{
      text-align: center;
      font-size: 1.5rem;
      margin-left: 20px;
    }

    &:hover{
      background-color: #c1c1c1;
      transition: all 0.5s ease;
    }
  }

  .roleGroup-select{
    width: 100%;
    height: 60px;
    display: flex;
    flex-wrap: wrap;
    background-color: #c1c1c1;
    align-content: center;
    
    p{
      text-align: center;
      font-size: 1.5rem;
      margin-left: 20px;
    }
  }
  
}
</style>
