<template>
  <div class="header_component">
    <div class="name">
      <p>管理员名字:</p>
      <div class="message">{{ userInfo.username }}</div>
    </div>
    
    <div class="role">
      <p>管理员权限:</p>
      <div class="message">{{ userInfo.role }}</div>
    </div>

    <el-button plain size="large" type="danger" style="width: 10%;height:50%" @click="loginOut">退出登录</el-button>
  </div>
</template>

<script lang="ts" setup>
import router from '@/router';
import { ref } from 'vue';
import { onBeforeMount, reactive } from 'vue';

let userInfo = reactive({
    "username": '',
    "role": '',
})

const loginOut = ()=>{
  localStorage.removeItem('token')
  localStorage.removeItem('user')
  router.replace('/')
}

onBeforeMount(() => {
  const userString = localStorage.getItem('user');
  if (userString) {
    const userObject = JSON.parse(userString);
    userInfo.username = userObject.userName || '';
    userInfo.role = userObject.role || '';
    switch(userInfo.role){
      case 'superAdmin':
        // 如果用户是管理员，执行的代码
        userInfo.role = '超级管理员'
        break;
      case 'userAdmin':
          // 如果用户是编辑者，执行的代码
          userInfo.role = '用户管理员'
          break;
      case 'businessAdmin':
          // 如果用户是编辑者，执行的代码
          userInfo.role = '商家管理员'
          break;
      case 'productAdmin':
          // 如果用户是编辑者，执行的代码
          userInfo.role = '商品管理员'
          break;
      case 'orderAdmin':
          // 如果用户是编辑者，执行的代码
          userInfo.role = '订单管理员'
          break;
      default:
          // 如果用户角色不是上述任何一个，执行的代码
          userInfo.role = '无权限'
    }
  }
})
</script>

<style scoped lang="scss">
.header_component{
  display: flex;
  flex-wrap: wrap;
  align-content: center;
  justify-content: end;

  height: 100px;
  width: 100%;

  .role,
  .name{
    width: 300px;
    height: 50%;
    border-radius: 5px;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
    align-content: center;
    border: 2px solid var(--el-border-color);
    margin-right: 20px;

    .message{
      width: 50%;
      border-left: 2px solid var(--el-border-color);
      padding-left: 20px;
      height: 50%;
    }
  }
}
</style>
