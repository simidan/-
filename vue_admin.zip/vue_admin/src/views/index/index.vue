<template>
  <div class="page">
    <el-container class="page_main">
      <el-aside>
        <asideVue></asideVue>
      </el-aside>
      <el-container>
        <el-header class="header">
          <headerVue></headerVue>
        </el-header>
        <el-main class="main">
          <roleVue v-if="pageStore.mainChangeStatus === '权限管理'"></roleVue>
          <userVue v-if="pageStore.mainChangeStatus === '用户管理'"></userVue>
          <bussinessVue v-if="pageStore.mainChangeStatus === '商家管理'"></bussinessVue>
          <productVue v-if="pageStore.mainChangeStatus === '产品管理'"></productVue>
          <orderVue v-if="pageStore.mainChangeStatus === '订单管理'"></orderVue>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script lang="ts" setup>
import asideVue from './aside.vue';
import headerVue from './header.vue';
import roleVue from '../../components/index/rolePage';
import userVue from '../../components/index/userPage';
import bussinessVue from '../../components/index/bussinessPage';
import productVue from '../../components/index/productPage';
import orderVue from '../../components/index/orderPage.vue';
import indexMainPageStore from '../../store/idnex/pageAside';

const pageStore = indexMainPageStore()

</script>

<style scoped lang="scss">
.page{
  min-width: 1000px;
  min-height: 600px;
}
.page_main{
  height:725px;

  .header{
    height: 100px;
    border-bottom: 2px solid rgba(128, 128, 128, 0.5);
  }
  
  .main{
    flex-grow: 1;
    border-bottom: 2px solid rgba(128, 128, 128, 0.5);
  }
  
  .el-main{
    padding: 0;
  }
}
</style>
