<template>
  <div class="common-layout page">
    <el-container>
      <el-header style="height:100px">
        <div class="header">
          <img src="../../../public/image/logo2.png" mode="" class="logo"/>
        </div>
      </el-header>
      <el-main class="login_main">
        <div class="main_item">
          <LoginVue v-if="PageStore.fromChangeStatus === 'Login'"></LoginVue>
          <RegisterVue v-else></RegisterVue>
        </div>
      </el-main>
    </el-container>
  </div>
</template>

<script setup>
import { onBeforeMount, ref } from "vue";
import LoginVue from "./loginFrom.vue";
import RegisterVue from './registerFrom.vue'
import loginPageStore from '@/store/loginRegister/page'
import router from "@/router";

const PageStore = loginPageStore()

</script>

<style lang="scss" scoped>
@import '@/../public/icon/iconfont.css';

.page{
  min-width: 1000px;
  min-height: 600px;
}

.header{
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
  height: 95%;
  border-bottom: 10px solid black;

  .logo{
    display: block;
    width: 5.5rem;
    object-fit: contain; /* 保持长宽比例 */
    margin-right: 50%;
    margin-bottom: 10px;
  }
}

.login_main {
  position: relative;
  background-color: #dfdddd;

  .main_item{
    display: flex;
    justify-content: center;
    align-items: center;
    width: 80%;
    
    height: 31.25rem;
  }
}
</style>