<template>
  <div class="main_from">
    <p>密码登录</p>
    <el-input v-model="username" style="width: 80%;height:30px" placeholder="请输入姓名" class="username"/>
    <el-input v-model="password" style="width: 80%;height:30px" type="password" placeholder="请输入密码" show-password class="password"
    />
    <div class="main_from_button">
      <el-button type="primary" size="large" @click="handleLogin" >登录</el-button>
      <el-button size="large" @click="pageStore.fromChange()">前往注册</el-button>
      <!-- <button @click="pageStore.fromChange()">注册</button> -->
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref } from 'vue';
import useLoginStore from '../../store/loginRegister/login';
import loginPageStore from '../../store/loginRegister/page';
import { useRouter } from 'vue-router';
import { adminMessageCheck } from '../../utils/messageCheck';
import { ElMessage, ElMessageBox } from 'element-plus'
import type { Action } from 'element-plus'

const router = useRouter()

const loginStore = useLoginStore();
const pageStore = loginPageStore()

const username = ref('adminUser1')
const password = ref('adminUser1')

// 定义处理登录的方法
const handleLogin = async () => {
  try {
    const loginInfo = { 'username': username.value, 'password': password.value }
    const errorMessage = adminMessageCheck(loginInfo);
    if (errorMessage) {
      ElMessageBox.alert(errorMessage.toString(), 'Title', {
        confirmButtonText: 'OK',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `action: ${action}`,
          });
        },
      });
    }else{
      await loginStore.login(loginInfo).then((res)=>{
        if(res.statusCode === 200){
          localStorage.setItem('token', res.data.token)
          localStorage.setItem('user', JSON.stringify(res.data.userInfo))
          
          router.push('/index');
        }else{
          ElMessageBox.alert(res.message, 'Title', {
            confirmButtonText: 'OK',
            callback: (action: Action) => {
              ElMessage({
                type: 'info',
                message: `action: ${action}`,
              });
            },
          });
        }
      })
    }  
  } catch (error) {
    // 处理登录失败的情况，例如显示错误消息
    console.error(error);
  }
};

</script>

<style scoped lang="scss">
.main_from{
  display: flex;
  flex-direction: column;
  flex-wrap: wrap;
  align-content: center;

  width: 400px;
  height: 350px;
  background-color: white;

  margin-left: 300px;

  border-radius: 2%;
  border: 1px solid rgb(194, 194, 194);
  box-shadow: 0px 4px 8px rgba(64, 158, 255, 0.2);

  &:focus-within {
    border: 1px solid;
    border-color: rgb(64, 158, 255); /* 当子元素聚焦时，父元素边框变蓝 */
  }

  p{
    margin-top: 2rem;
    font-size: 2rem;
    text-align: center;
    padding-bottom: 10px;
    font-weight: 800;

    border-bottom: 2px solid rgb(194, 194, 194);
  }

  .username{
    margin-top: 2rem;
  }

  .password{
    margin-top: 2rem;
  }
  
  .main_from_button{
    display: flex;
    justify-content: space-around;
    margin-top: 2rem;
  }
}

</style>
