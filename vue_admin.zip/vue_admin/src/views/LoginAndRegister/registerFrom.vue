<template>
  <div class="main_from">
    <p>管理员注册</p>
    <div class="total">
      <div class="left">
        <el-input v-model="username" style="width: 80%;height:30px" placeholder="请输入姓名" class="username"/>
        <el-input v-model="passwordA" style="width: 80%;height:30px" type="password" placeholder="请输入密码" show-password class="password" maxlength="15"/>
        <el-input v-model="passwordB" style="width: 80%;height:30px" placeholder="再次输入密码" show-password class="password" maxlength="15"/>
        <el-input v-model="phone" style="width: 80%;height:30px" placeholder="请输入手机号" class="password"/>
        <el-input v-model="email" style="width: 80%;height:30px" placeholder="请输入邮箱" class="password"/>
      </div>
      <div class="right">
        <el-radio-group v-model="gender" class="gender">
          <el-radio value="0" size="large">男</el-radio>
          <el-radio value="1" size="large">女</el-radio>
        </el-radio-group>
        <el-select
          v-model="role"
          placeholder="请选择身份"
          style="width: 80%;height:30px"
          class="password">
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value"/>
        </el-select>
        <div class="demo-datetime-picker">
          <div class="block">
            <span class="demonstration">生日</span>
            <el-date-picker
              v-model="birthday"
              type="datetime"
              placeholder="Select date and time"
              style="width: 80%;height:30px;margin-right: 80px;"
              :default-time="defaultTime"
            />
          </div>
        </div>
      </div>
    </div>
    <div class="main_from_button">
      <el-button size="large" @click="pageStore.fromChange()">返回登录</el-button>
      <el-button type="primary" size="large" @click="show">确认</el-button>
      <!-- <button @click="pageStore.fromChange()">注册</button> -->
    </div>
  </div>
</template>

<script lang="ts" setup>
import loginPageStore from '../../store/loginRegister/page';
import { ref } from 'vue';
import dateChange from '../../utils/dateChange';
import userRegisterStore from '../../store/loginRegister/register';
import { adminMessage } from '../../utils/interface';
import { ElMessage, ElMessageBox } from 'element-plus'
import type { Action } from 'element-plus'
import { adminMessageCheck } from '../../utils/messageCheck';

const pageStore = loginPageStore()
const registerStore = userRegisterStore()

const username = ref('')
const passwordA = ref('')
const passwordB = ref('')
const phone = ref('')
const email = ref('')
const gender = ref('')
const role = ref('')
const birthday = ref('')

const options = [
  {
    value: 'superAdmin',
    label: '超级管理员',
  },
  {
    value: 'userAdmin',
    label: '用户管理员',
  },
  {
    value: 'productAdmin',
    label: '产品管理员',
  },
  {
    value: 'businessAdmin',
    label: '商家管理员',
  },
  {
    value: 'orderAdmin',
    label: '订单管理员',
  },
]

const defaultTime = new Date(2000, 1, 1, 12, 0, 0)

const handleRegister= async()=>{
  birthday.value = dateChange(birthday.value)
  if(passwordA.value !== passwordB.value){
    return ElMessageBox.alert('密码不一致', 'Title', {
            confirmButtonText: 'OK',
            callback: (action: Action) => {
              ElMessage({
                type: 'info',
                message: `action: ${action}`,
              });
            },
          });
  }else{
    const registerInfo = {
    'username':username.value,
    'password':passwordB.value,
    'phone':phone.value,
    'email':email.value,
    'gender':gender.value,
    'role':role.value,
    'birthday':birthday.value,
  }
  
  const errorMessage = adminMessageCheck(registerInfo);
  if (errorMessage) {
    ElMessageBox.alert(errorMessage.toString(), 'Title', {
      confirmButtonText: 'OK',
      callback: (action: Action) => {
        ElMessage({
          type: 'info',
          message: `action: ${action}`,
        });
      },
    });
  }else{
    await registerStore.register(registerInfo).then((res)=>{
      if(res.statusCode === 201){
        ElMessageBox.alert(`注册成功，请耐心等待审核`, 'Title', {
        // if you want to disable its autofocus
        // autofocus: false,
        confirmButtonText: 'OK',
        callback: (action: Action) => {
          ElMessage({
            type: 'info',
            message: `action: ${action}`,
          })
        },
       })
       pageStore.fromChange()
      }
    })
  }
  }
}

const show = ()=>{
  handleRegister()
}
</script>

<style scoped lang="scss">
.main_from{
  display: flex;
  flex-direction: column;
  flex-wrap: wrap;
  align-content: center;

  width: 800px;
  height: 500px;
  background-color: white;

  margin-left: 300px;

  border-radius: 2%;
  border: 1px solid rgb(194, 194, 194);
  box-shadow: 0px 4px 8px rgba(64, 158, 255, 0.2);

  &:focus-within {
    border: 1px solid;
    border-color: rgb(64, 158, 255); /* 当子元素聚焦时，父元素边框变蓝 */
  }

  p{
    margin-top: 2rem;
    font-size: 2rem;
    text-align: center;
    padding-bottom: 10px;
    font-weight: 800;

    border-bottom: 2px solid rgb(194, 194, 194);
  }

  .total{
    display: flex;
    width: 100%;
    height: 60%;
    
    .left{
      display: flex;
      flex-direction: column;
      flex-wrap: wrap;
      align-content: center;
      width: 50%;

      .username{
        margin-top: 1.5rem;
      }
    
      .password{
        margin-top: 1.5rem;
      }
    
      .password_woring:focus{
        margin-top: 1.5rem;
        border: 1px solid;
        border-color: rgb(255, 0, 0);
        border-radius: 2%;
      }
    }

    .right{
      display: flex;
      flex-direction: column;
      flex-wrap: wrap;
      align-content: center;

      width: 50%;

      .gender{
        margin-top: .8rem;
      }

      .password{
        margin-top: 1.5rem;
      }
    
      .password_woring:focus{
        margin-top: 1.5rem;
        border: 1px solid;
        border-color: rgb(255, 0, 0);
        border-radius: 2%;
      }

      .demo-datetime-picker {
        display: flex;
        width: 100%;
        padding: 0;
        flex-wrap: wrap;

        .block {
          padding: 30px 0;
          border-right: solid 1px var(--el-border-color);
          flex: 1;

          .demonstration {
            display: block;
            color: var(--el-text-color-secondary);
            font-size: 14px;
            margin-bottom: 30px;
          }
        }
      }
      
    }
  }
  
  .main_from_button{
    display: flex;
    justify-content: space-around;
    margin-top: 2rem;
  }
}
</style>
